#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTimer>
#include <QString>
#include <QMap>
#include <QList>
#include <QListWidgetItem>
#include <QJsonObject>
#include "dbhelper.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // 私聊相关
    void on_userListWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item);

    // 登录/注册
    void on_loginButton_clicked();
    void on_registerButton_clicked();
    void on_Register_clicked();
    void on_returnButton_clicked();

    // 分组页
    void on_Return_clicked();
    void on_AddGroup_clicked();
    void on_Addcontact_clicked();
    void onGroupSelected(const QString &groupName);
    void onUserDoubleClicked(QListWidgetItem *item);

    // 群聊页
    void on_sayBtn_clicked();
    void on_logoutBtn_clicked();
    void on_contacts_clicked();

    // 私聊页
    void on_sayBtn_2_clicked();
    void on_logoutBtn_2_clicked();
    void on_contacts_2_clicked();

    // 网络事件
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onSocketError(QAbstractSocket::SocketError error);
    void sendHeartbeat();
    void handleServerResponse(const QJsonObject &response);

private:
    // 核心函数
    void switchToPage(int pageIndex);
    void connectToServer(const QString &serverIp);
    void sendJsonToServer(const QJsonObject &json);
    void clearChatInput();
    void updateOnlineUserList(const QJsonArray &userArray);

    // 数据库函数
    void loadChatHistory();
    void loadGroupContactHistory();
    void loadPrivateChat(const QString &target);

private:
    Ui::MainWindow *ui;
    QTcpSocket *m_tcpSocket;
    QTimer *m_heartbeatTimer;
    bool m_isConnected;
    QString m_currentUsername;
    QString m_privateChatTarget;
    QString m_currentSelectedGroup;
    QMap<QString, QList<QString>> m_groupContactMap;
    DBHelper *m_dbHelper;

    // 页面索引常量
    static const int PAGE_PUBLIC_CHAT = 0;
    static const int PAGE_PRIVATE_CHAT = 1;
    static const int PAGE_GROUP = 2;
    static const int PAGE_LOGIN = 3;
    static const int PAGE_REGISTER = 4;
};

#endif // MAINWINDOW_H
