// dbhelper.h
#ifndef DBHELPER_H
#define DBHELPER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QList>
#include <QString>

// 聊天记录结构体（需和mainwindow中一致）
struct ChatRecord {
    QString username;
    QString type;       // public/private
    QString sender;
    QString receiver;
    QString content;
    QString time;
};

class DBHelper : public QObject
{
    Q_OBJECT
public:
    explicit DBHelper(QObject *parent = nullptr);
    ~DBHelper() override; // 析构函数声明（必须有实现）

    // 核心方法声明
    bool initDB(); // 初始化数据库
    bool insertChatRecord(const ChatRecord &record); // 插入聊天记录
    QList<ChatRecord> queryAllChatRecords(const QString &username); // 查询所有群聊记录
    QList<ChatRecord> queryPrivateChat(const QString &username, const QString &target); // 查询私聊记录
    bool insertGroup(const QString &groupName); // 插入分组
    QMap<QString, QList<QString>> queryAllGroupContacts(); // 查询所有分组和联系人
    bool insertGroupContact(const QString &groupName, const QString &contact); // 插入分组联系人

private:
    QSqlDatabase m_db; // 数据库对象
};

#endif // DBHELPER_H
