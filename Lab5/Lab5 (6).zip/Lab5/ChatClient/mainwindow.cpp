#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QMessageBox>
#include <QInputDialog>
#include <QDateTime>
#include <QStringLiteral>
#include <QListWidget>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_tcpSocket(new QTcpSocket(this))
    , m_heartbeatTimer(new QTimer(this))
    , m_isConnected(false)
    , m_currentUsername(QString())  // 修复：用QString()代替""
    , m_privateChatTarget(QString()) // 修复：用QString()代替""
    , m_currentSelectedGroup(QString()) // 修复：用QString()代替""
    , m_groupContactMap(QMap<QString, QList<QString>>())
    , m_dbHelper(new DBHelper(this))
{
    ui->setupUi(this);

    // 信号槽绑定
    // 登录/注册
    connect(ui->loginButton, &QPushButton::clicked, this, &MainWindow::on_loginButton_clicked);
    connect(ui->registerButton, &QPushButton::clicked, this, &MainWindow::on_registerButton_clicked);
    connect(ui->Register, &QPushButton::clicked, this, &MainWindow::on_Register_clicked);
    connect(ui->returnButton, &QPushButton::clicked, this, &MainWindow::on_returnButton_clicked);

    // 分组页
    connect(ui->Return, &QPushButton::clicked, this, &MainWindow::on_Return_clicked);
    connect(ui->AddGroup, &QPushButton::clicked, this, &MainWindow::on_AddGroup_clicked);
    connect(ui->Addcontact, &QPushButton::clicked, this, &MainWindow::on_Addcontact_clicked);

    // 群聊页
    connect(ui->sayBtn, &QPushButton::clicked, this, &MainWindow::on_sayBtn_clicked);
    connect(ui->logoutBtn, &QPushButton::clicked, this, &MainWindow::on_logoutBtn_clicked);
    connect(ui->contacts, &QPushButton::clicked, this, &MainWindow::on_contacts_clicked);

    // 私聊页
    connect(ui->sayBtn_2, &QPushButton::clicked, this, &MainWindow::on_sayBtn_2_clicked);
    connect(ui->logoutBtn_2, &QPushButton::clicked, this, &MainWindow::on_logoutBtn_2_clicked);
    connect(ui->contacts_2, &QPushButton::clicked, this, &MainWindow::on_contacts_2_clicked);

    // 私聊对象选择
    connect(ui->userListWidget, &QListWidget::itemDoubleClicked, this, &MainWindow::on_userListWidget_itemDoubleClicked);
    connect(ui->userListWidget_2, &QListWidget::itemDoubleClicked, this, &MainWindow::on_userListWidget_2_itemDoubleClicked);

    // 分组选中
    connect(ui->Grouping, &QListWidget::currentTextChanged, this, &MainWindow::onGroupSelected);
    connect(ui->userListWidget_4, &QListWidget::itemDoubleClicked, this, &MainWindow::onUserDoubleClicked);

    // 数据库初始化
    if (!m_dbHelper->initDB()) {
        QMessageBox::warning(this, QStringLiteral("警告"), QStringLiteral("数据库初始化失败！"));
    }

    // 网络绑定
    connect(m_tcpSocket, &QTcpSocket::connected, this, &MainWindow::onConnected);
    connect(m_tcpSocket, &QTcpSocket::disconnected, this, &MainWindow::onDisconnected);
    connect(m_tcpSocket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);
    connect(m_tcpSocket, &QTcpSocket::errorOccurred, this, &MainWindow::onSocketError);

    // 心跳包
    m_heartbeatTimer->setInterval(30000);
    connect(m_heartbeatTimer, &QTimer::timeout, this, &MainWindow::sendHeartbeat);

    // UI初始化
    switchToPage(PAGE_LOGIN);
    clearChatInput();
    ui->roomTextEdit->setReadOnly(true);
    ui->privateTextEdit->setReadOnly(true);

    qInfo() << QStringLiteral("客户端初始化完成");
}

MainWindow::~MainWindow()
{
    if (m_tcpSocket->state() == QTcpSocket::ConnectedState) {
        m_tcpSocket->disconnectFromHost();
    }
    delete ui;
}

// 页面跳转
void MainWindow::switchToPage(int pageIndex)
{
    qDebug() << QStringLiteral("跳转页面：") << pageIndex;
    ui->stackedWidget->setCurrentIndex(pageIndex);
    if (pageIndex == PAGE_PRIVATE_CHAT) {
        ui->privateTextEdit->clear();
    }
}

// 连接服务器（端口1967）
void MainWindow::connectToServer(const QString &serverIp)
{
    m_tcpSocket->abort();
    m_tcpSocket->connectToHost(serverIp, 1967);
    qInfo() << QStringLiteral("连接服务器：") << serverIp << QStringLiteral(":1967");
}

// 发送JSON数据
void MainWindow::sendJsonToServer(const QJsonObject &json)
{
    if (!m_isConnected) {
        QMessageBox::warning(this, QStringLiteral("错误"), QStringLiteral("未连接服务器！"));
        return;
    }

    QJsonDocument doc(json);
    QByteArray data = doc.toJson(QJsonDocument::Compact) + "\n";
    qint64 len = m_tcpSocket->write(data);
    if (len == -1) {
        qCritical() << QStringLiteral("发送失败：") << m_tcpSocket->errorString();
    } else {
        qDebug() << QStringLiteral("发送数据：") << data.trimmed();
    }
}

// 清空输入框
void MainWindow::clearChatInput()
{
    ui->sayLineEdit->clear();
    ui->sayLineEdit_2->clear();
    ui->sayLineEdit->setFocus();
}

// 更新在线用户列表
void MainWindow::updateOnlineUserList(const QJsonArray &userArray)
{
    ui->userListWidget->clear();
    ui->userListWidget_2->clear();

    for (const QJsonValue &v : userArray) {
        QString u = v.toString();
        if (u != m_currentUsername) {
            ui->userListWidget->addItem(u);
            ui->userListWidget_2->addItem(u);
        }
    }
    qInfo() << QStringLiteral("在线用户数：") << userArray.size() - 1;
}

// 加载群聊历史
void MainWindow::loadChatHistory()
{
    if (m_currentUsername.isEmpty() || !m_dbHelper) return;

    ui->roomTextEdit->clear();
    QList<ChatRecord> list = m_dbHelper->queryAllChatRecords(m_currentUsername);
    for (const ChatRecord &r : list) {
        if (r.sender == m_currentUsername) {
            ui->roomTextEdit->append(QStringLiteral("[%1][我]：%2").arg(r.time).arg(r.content));
        } else {
            ui->roomTextEdit->append(QStringLiteral("[%1][%2]：%3").arg(r.time).arg(r.sender).arg(r.content));
        }
    }
    qInfo() << QStringLiteral("加载群聊记录：") << list.size() << QStringLiteral("条");
}

// 加载分组/联系人
void MainWindow::loadGroupContactHistory()
{
    if (!m_dbHelper) return;

    ui->Grouping->clear();
    m_groupContactMap = m_dbHelper->queryAllGroupContacts();

    QString defGroup = QStringLiteral("默认分组");
    if (m_groupContactMap.isEmpty()) {
        m_dbHelper->insertGroup(defGroup);
        m_groupContactMap[defGroup] = QList<QString>();
    }

    for (const QString &g : m_groupContactMap.keys()) {
        ui->Grouping->addItem(g);
    }

    m_currentSelectedGroup = ui->Grouping->count() > 0 ? ui->Grouping->item(0)->text() : defGroup;

    ui->userListWidget_4->clear();
    QList<QString> contacts = m_groupContactMap[m_currentSelectedGroup];
    for (const QString &c : contacts) {
        ui->userListWidget_4->addItem(c);
    }
}

// 加载私聊历史
void MainWindow::loadPrivateChat(const QString &target)
{
    if (m_currentUsername.isEmpty() || target.isEmpty() || !m_dbHelper) return;

    ui->privateTextEdit->clear();
    ui->privateTextEdit->append(QStringLiteral("=== 与 %1 的私聊历史 ===").arg(target));

    QList<ChatRecord> list = m_dbHelper->queryPrivateChat(m_currentUsername, target);
    for (const ChatRecord &r : list) {
        if (r.sender == m_currentUsername) {
            ui->privateTextEdit->append(QStringLiteral("[%1][我→%2]：%3").arg(r.time).arg(target).arg(r.content));
        } else {
            ui->privateTextEdit->append(QStringLiteral("[%1][%2→我]：%3").arg(r.time).arg(target).arg(r.content));
        }
    }
    qInfo() << QStringLiteral("加载私聊记录：") << list.size() << QStringLiteral("条");
}

// ========== 私聊对象选择 ==========
void MainWindow::on_userListWidget_itemDoubleClicked(QListWidgetItem *item)
{
    if (!item || !m_isConnected) return;

    m_privateChatTarget = item->text();
    switchToPage(PAGE_PRIVATE_CHAT);
    loadPrivateChat(m_privateChatTarget);
    QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("已选择与【%1】私聊").arg(m_privateChatTarget));
    ui->sayLineEdit_2->setFocus();
}

void MainWindow::on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item)
{
    if (!item || !m_isConnected) return;

    m_privateChatTarget = item->text();
    loadPrivateChat(m_privateChatTarget);
    QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("已切换到与【%1】私聊").arg(m_privateChatTarget));
    ui->sayLineEdit_2->setFocus();
}

// ========== 登录页 ==========
void MainWindow::on_loginButton_clicked()
{
    QString ip = ui->ServerEdit->text().trimmed();
    QString user = ui->UserNameEdit->text().trimmed();
    QString pwd = ui->UserPasswordEdit->text().trimmed();

    if (ip.isEmpty() || user.isEmpty() || pwd.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("错误"), QStringLiteral("信息不能为空！"));
        return;
    }

    if (m_tcpSocket->state() != QTcpSocket::ConnectedState) {
        connect(m_tcpSocket, &QTcpSocket::connected, this, [=]() {
            QJsonObject json;
            json[QStringLiteral("type")] = QStringLiteral("login");
            json[QStringLiteral("username")] = user;
            json[QStringLiteral("password")] = pwd;
            sendJsonToServer(json);
            m_currentUsername = user;
            disconnect(m_tcpSocket, &QTcpSocket::connected, this, nullptr);
        });
        connectToServer(ip);
    } else {
        QJsonObject json;
        json[QStringLiteral("type")] = QStringLiteral("login");
        json[QStringLiteral("username")] = user;
        json[QStringLiteral("password")] = pwd;
        sendJsonToServer(json);
        m_currentUsername = user;
    }
}

void MainWindow::on_registerButton_clicked()
{
    switchToPage(PAGE_REGISTER);
}

// ========== 注册页 ==========
void MainWindow::on_Register_clicked()
{
    QString ip = ui->ServerEdit_2->text().trimmed();
    QString user = ui->UserNameEdit_2->text().trimmed();
    QString pwd = ui->UserPasswordEdit_2->text().trimmed();
    QString name = ui->AddressNameEdit->text().trimmed();
    QString phone = ui->TelephonenumberEdit->text().trimmed();

    if (ip.isEmpty() || user.isEmpty() || pwd.isEmpty() || name.isEmpty() || phone.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("错误"), QStringLiteral("信息不能为空！"));
        return;
    }

    if (m_tcpSocket->state() != QTcpSocket::ConnectedState) {
        connect(m_tcpSocket, &QTcpSocket::connected, this, [=]() {
            QJsonObject json;
            json[QStringLiteral("type")] = QStringLiteral("register");
            json[QStringLiteral("username")] = user;
            json[QStringLiteral("password")] = pwd;
            json[QStringLiteral("realname")] = name;
            json[QStringLiteral("phone")] = phone;
            sendJsonToServer(json);
            disconnect(m_tcpSocket, &QTcpSocket::connected, this, nullptr);
        });
        connectToServer(ip);
    } else {
        QJsonObject json;
        json[QStringLiteral("type")] = QStringLiteral("register");
        json[QStringLiteral("username")] = user;
        json[QStringLiteral("password")] = pwd;
        json[QStringLiteral("realname")] = name;
        json[QStringLiteral("phone")] = phone;
        sendJsonToServer(json);
    }
}

void MainWindow::on_returnButton_clicked()
{
    switchToPage(PAGE_LOGIN);
}

// ========== 分组页 ==========
void MainWindow::on_Return_clicked()
{
    switchToPage(PAGE_PUBLIC_CHAT);
}

void MainWindow::on_AddGroup_clicked()
{
    QString name = QInputDialog::getText(this, QStringLiteral("添加分组"), QStringLiteral("分组名："));
    if (name.isEmpty()) return;

    if (m_groupContactMap.contains(name)) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("分组已存在！"));
        return;
    }

    m_dbHelper->insertGroup(name);
    m_groupContactMap[name] = QList<QString>();
    ui->Grouping->addItem(name);
    QMessageBox::information(this, QStringLiteral("成功"), QStringLiteral("分组创建成功！"));
}

void MainWindow::on_Addcontact_clicked()
{
    if (m_currentSelectedGroup.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请选择分组！"));
        return;
    }

    QString contact = QInputDialog::getText(this, QStringLiteral("添加联系人"), QStringLiteral("用户名："));
    if (contact.isEmpty()) return;

    QList<QString> list = m_groupContactMap[m_currentSelectedGroup];
    if (list.contains(contact)) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("联系人已存在！"));
        return;
    }

    m_dbHelper->insertGroupContact(m_currentSelectedGroup, contact);
    m_groupContactMap[m_currentSelectedGroup].append(contact);
    ui->userListWidget_4->addItem(contact);
    QMessageBox::information(this, QStringLiteral("成功"), QStringLiteral("添加成功！"));
}

void MainWindow::onGroupSelected(const QString &groupName)
{
    if (groupName.isEmpty()) return;

    m_currentSelectedGroup = groupName;
    ui->userListWidget_4->clear();
    QList<QString> list = m_groupContactMap[groupName];
    for (const QString &c : list) {
        ui->userListWidget_4->addItem(c);
    }
}

void MainWindow::onUserDoubleClicked(QListWidgetItem *item)
{
    if (!item) return;

    m_privateChatTarget = item->text();
    switchToPage(PAGE_PRIVATE_CHAT);
    loadPrivateChat(m_privateChatTarget);
}

// ========== 群聊页 ==========
void MainWindow::on_sayBtn_clicked()
{
    QString msg = ui->sayLineEdit->text().trimmed();
    if (msg.isEmpty() || !m_isConnected) return;

    QJsonObject json;
    json[QStringLiteral("type")] = QStringLiteral("public_chat");
    json[QStringLiteral("sender")] = m_currentUsername;
    json[QStringLiteral("receiver")] = QStringLiteral("all");
    json[QStringLiteral("text")] = msg;
    sendJsonToServer(json);

    QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"));
    ui->roomTextEdit->append(QStringLiteral("[%1][我]：%2").arg(time).arg(msg));
    clearChatInput();

    // 缓存到数据库
    ChatRecord r;
    r.username = m_currentUsername;
    r.type = QStringLiteral("public");
    r.sender = m_currentUsername;
    r.receiver = QStringLiteral("all");
    r.content = msg;
    r.time = time;
    m_dbHelper->insertChatRecord(r);
}

void MainWindow::on_logoutBtn_clicked()
{
    if (m_tcpSocket->state() == QTcpSocket::ConnectedState) {
        m_tcpSocket->disconnectFromHost();
    }
    switchToPage(PAGE_LOGIN);
}

void MainWindow::on_contacts_clicked()
{
    switchToPage(PAGE_GROUP);
    loadGroupContactHistory();
}

// ========== 私聊页 ==========
void MainWindow::on_sayBtn_2_clicked()
{
    QString msg = ui->sayLineEdit_2->text().trimmed();

    if (!m_isConnected) {
        QMessageBox::warning(this, QStringLiteral("错误"), QStringLiteral("未连接服务器！"));
        return;
    }
    if (msg.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("错误"), QStringLiteral("消息不能为空！"));
        return;
    }
    if (m_privateChatTarget.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请选择私聊对象！"));
        return;
    }
    if (m_privateChatTarget == m_currentUsername) {
        QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("不能和自己私聊！"));
        return;
    }

    QJsonObject json;
    json[QStringLiteral("type")] = QStringLiteral("private_chat");
    json[QStringLiteral("sender")] = m_currentUsername;
    json[QStringLiteral("receiver")] = m_privateChatTarget;
    json[QStringLiteral("text")] = msg;
    sendJsonToServer(json);

    QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"));
    ui->privateTextEdit->append(QStringLiteral("[%1][我→%2]：%3").arg(time).arg(m_privateChatTarget).arg(msg));
    clearChatInput();

    // 缓存到数据库
    ChatRecord r;
    r.username = m_currentUsername;
    r.type = QStringLiteral("private");
    r.sender = m_currentUsername;
    r.receiver = m_privateChatTarget;
    r.content = msg;
    r.time = time;
    m_dbHelper->insertChatRecord(r);
}

void MainWindow::on_logoutBtn_2_clicked()
{
    if (m_tcpSocket->state() == QTcpSocket::ConnectedState) {
        m_tcpSocket->disconnectFromHost();
    }
    switchToPage(PAGE_LOGIN);
}

void MainWindow::on_contacts_2_clicked()
{
    switchToPage(PAGE_GROUP);
    loadGroupContactHistory();
}

// ========== 网络事件 ==========
void MainWindow::onConnected()
{
    m_isConnected = true;
    m_heartbeatTimer->start();
    qInfo() << QStringLiteral("连接成功，启动心跳包");
}

void MainWindow::onDisconnected()
{
    m_isConnected = false;
    m_heartbeatTimer->stop();
    QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("连接断开！"));
    switchToPage(PAGE_LOGIN);
}

void MainWindow::onReadyRead()
{
    QByteArray data = m_tcpSocket->readAll();
    QStringList msgs = QString::fromUtf8(data).split(QStringLiteral("\n"), Qt::SkipEmptyParts);

    for (const QString &msg : msgs) {
        QJsonParseError err;
        QJsonDocument doc = QJsonDocument::fromJson(msg.toUtf8(), &err);
        if (err.error != QJsonParseError::NoError) {
            qWarning() << QStringLiteral("JSON解析错误：") << err.errorString();
            continue;
        }
        handleServerResponse(doc.object());
    }
}

void MainWindow::onSocketError(QAbstractSocket::SocketError error)
{
    Q_UNUSED(error);
    QMessageBox::critical(this, QStringLiteral("错误"), QStringLiteral("连接失败：%1").arg(m_tcpSocket->errorString()));
    m_isConnected = false;
}

void MainWindow::sendHeartbeat()
{
    if (!m_isConnected || m_currentUsername.isEmpty()) return;

    QJsonObject json;
    json[QStringLiteral("type")] = QStringLiteral("heartbeat");
    json[QStringLiteral("username")] = m_currentUsername;
    sendJsonToServer(json);
    qDebug() << QStringLiteral("发送心跳包");
}

void MainWindow::handleServerResponse(const QJsonObject &response)
{
    QString type = response[QStringLiteral("type")].toString();

    if (type == QStringLiteral("login_success")) {
        QMessageBox::information(this, QStringLiteral("成功"), QStringLiteral("登录成功！"));
        switchToPage(PAGE_PUBLIC_CHAT);
        loadChatHistory();
        loadGroupContactHistory();
    } else if (type == QStringLiteral("login_failed")) {
        QMessageBox::warning(this, QStringLiteral("失败"), response[QStringLiteral("reason")].toString());
    } else if (type == QStringLiteral("register_success")) {
        QMessageBox::information(this, QStringLiteral("成功"), QStringLiteral("注册成功！"));
        switchToPage(PAGE_LOGIN);
    } else if (type == QStringLiteral("register_failed")) {
        QMessageBox::warning(this, QStringLiteral("失败"), response[QStringLiteral("reason")].toString());
    } else if (type == QStringLiteral("public_chat")) {
        QString sender = response[QStringLiteral("sender")].toString();
        QString text = response[QStringLiteral("text")].toString();
        if (sender != m_currentUsername) {
            QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"));
            ui->roomTextEdit->append(QStringLiteral("[%1][%2]：%3").arg(time).arg(sender).arg(text));

            // 缓存
            ChatRecord r;
            r.username = m_currentUsername;
            r.type = QStringLiteral("public");
            r.sender = sender;
            r.receiver = QStringLiteral("all");
            r.content = text;
            r.time = time;
            m_dbHelper->insertChatRecord(r);
        }
    } else if (type == QStringLiteral("private_chat")) {
        QString sender = response[QStringLiteral("sender")].toString();
        QString text = response[QStringLiteral("text")].toString();

        // ========== 核心修改：过滤自己发送的私聊消息 ==========
        if (sender == m_currentUsername) {
            qDebug() << QStringLiteral("过滤自己发送的私聊消息，避免重复显示");
            return; // 直接返回，不处理自己发送的消息
        }

        QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"));
        ui->privateTextEdit->append(QStringLiteral("[%1][%2→我]：%3").arg(time).arg(sender).arg(text));
        qDebug() << QStringLiteral("收到私聊：") << sender << QStringLiteral("：") << text;

        // 缓存
        ChatRecord r;
        r.username = m_currentUsername;
        r.type = QStringLiteral("private");
        r.sender = sender;
        r.receiver = m_currentUsername;
        r.content = text;
        r.time = time;
        m_dbHelper->insertChatRecord(r);

        switchToPage(PAGE_PRIVATE_CHAT);
        m_privateChatTarget = sender;
    } else if (type == QStringLiteral("userlist")) {
        QJsonArray arr = response[QStringLiteral("userlist")].toArray();
        updateOnlineUserList(arr);
    } else if (type == QStringLiteral("heartbeat_ack")) {
        qDebug() << QStringLiteral("收到心跳回应");
    } else {
        qWarning() << QStringLiteral("未知响应类型：") << type;
    }
}
