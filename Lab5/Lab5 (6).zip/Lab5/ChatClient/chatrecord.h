#ifndef CHATRECORD_H
#define CHATRECORD_H

#include <QString> // 必须包含QString头文件

/**
 * @brief 聊天记录结构体
 * 存储单条聊天记录的所有信息，用于本地数据库缓存
 */
struct ChatRecord {
    QString username;  // 所属用户（当前登录用户）
    QString type;      // 消息类型：public(公聊)/private(私聊)
    QString sender;    // 发送者用户名
    QString receiver;  // 接收者（all=公聊，具体用户名=私聊）
    QString content;   // 消息内容
    QString time;      // 发送时间（格式：HH:mm:ss）
};

#endif // CHATRECORD_H
