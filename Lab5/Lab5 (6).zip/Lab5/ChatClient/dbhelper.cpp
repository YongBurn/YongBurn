// dbhelper.cpp
#include "dbhelper.h"
#include <QDebug>
#include <QStandardPaths>
#include <QDir>

// 构造函数实现
DBHelper::DBHelper(QObject *parent)
    : QObject(parent)
{
    // 构造函数空实现（或初始化逻辑）
}

// ========== 核心：析构函数必须有实现 ==========
DBHelper::~DBHelper()
{
    // 关闭数据库连接（可选，Qt会自动处理，但显式关闭更规范）
    if (m_db.isOpen()) {
        m_db.close();
    }
    qDebug() << QStringLiteral("DBHelper析构，数据库连接已关闭");
}

// 初始化数据库（SQLite）
bool DBHelper::initDB()
{
    // 获取本地数据库路径（避免权限问题）
    QString dbPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + QStringLiteral("/chat.db");
    QDir().mkpath(QStandardPaths::writableLocation(QStandardPaths::AppDataLocation));

    // 初始化SQLite数据库（修复：QStringLiteral包裹驱动名）
    m_db = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"));
    m_db.setDatabaseName(dbPath);

    // 打开数据库
    if (!m_db.open()) {
        qCritical() << QStringLiteral("数据库打开失败：") << m_db.lastError().text();
        return false;
    }

    // 创建聊天记录表（修复：SQL语句用QStringLiteral，避免中文乱码）
    QSqlQuery query;
    QString createChatTable = QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS chat_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            type TEXT NOT NULL,
            sender TEXT NOT NULL,
            receiver TEXT NOT NULL,
            content TEXT NOT NULL,
            time TEXT NOT NULL
        )
    )");
    if (!query.exec(createChatTable)) {
        qCritical() << QStringLiteral("创建聊天表失败：") << query.lastError().text();
        return false;
    }

    // 创建分组表
    QString createGroupTable = QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT UNIQUE NOT NULL
        )
    )");
    if (!query.exec(createGroupTable)) {
        qCritical() << QStringLiteral("创建分组表失败：") << query.lastError().text();
        return false;
    }

    // 创建分组-联系人关联表
    QString createGroupContactTable = QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS group_contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT NOT NULL,
            contact TEXT NOT NULL,
            UNIQUE(group_name, contact)
        )
    )");
    if (!query.exec(createGroupContactTable)) {
        qCritical() << QStringLiteral("创建分组联系人表失败：") << query.lastError().text();
        return false;
    }

    qDebug() << QStringLiteral("数据库初始化成功，路径：") << dbPath;
    return true;
}

// 插入聊天记录（修复：所有bindValue的键名用QStringLiteral）
bool DBHelper::insertChatRecord(const ChatRecord &record)
{
    if (!m_db.isOpen()) {
        qCritical() << QStringLiteral("数据库未打开，插入记录失败");
        return false;
    }

    QSqlQuery query;
    query.prepare(QStringLiteral(R"(
        INSERT INTO chat_records (username, type, sender, receiver, content, time)
        VALUES (:username, :type, :sender, :receiver, :content, :time)
    )"));
    query.bindValue(QStringLiteral(":username"), record.username);
    query.bindValue(QStringLiteral(":type"), record.type);
    query.bindValue(QStringLiteral(":sender"), record.sender);
    query.bindValue(QStringLiteral(":receiver"), record.receiver);
    query.bindValue(QStringLiteral(":content"), record.content);
    query.bindValue(QStringLiteral(":time"), record.time);

    if (!query.exec()) {
        qCritical() << QStringLiteral("插入聊天记录失败：") << query.lastError().text();
        return false;
    }
    return true;
}

// 查询所有群聊记录（修复：bindValue键名+SQL里的字符串）
QList<ChatRecord> DBHelper::queryAllChatRecords(const QString &username)
{
    QList<ChatRecord> records;
    if (!m_db.isOpen()) {
        qCritical() << QStringLiteral("数据库未打开，查询记录失败");
        return records;
    }

    QSqlQuery query;
    query.prepare(QStringLiteral(R"(
        SELECT type, sender, receiver, content, time
        FROM chat_records
        WHERE username = :username AND type = 'public'
        ORDER BY time ASC
    )"));
    query.bindValue(QStringLiteral(":username"), username);

    if (!query.exec()) {
        qCritical() << QStringLiteral("查询群聊记录失败：") << query.lastError().text();
        return records;
    }

    while (query.next()) {
        ChatRecord r;
        r.username = username;
        r.type = query.value(0).toString();
        r.sender = query.value(1).toString();
        r.receiver = query.value(2).toString();
        r.content = query.value(3).toString();
        r.time = query.value(4).toString();
        records.append(r);
    }
    return records;
}

// 查询私聊记录（修复：bindValue键名）
QList<ChatRecord> DBHelper::queryPrivateChat(const QString &username, const QString &target)
{
    QList<ChatRecord> records;
    if (!m_db.isOpen()) {
        qCritical() << QStringLiteral("数据库未打开，查询私聊记录失败");
        return records;
    }

    QSqlQuery query;
    query.prepare(QStringLiteral(R"(
        SELECT type, sender, receiver, content, time
        FROM chat_records
        WHERE username = :username
        AND type = 'private'
        AND (
            (sender = :username AND receiver = :target)
            OR (sender = :target AND receiver = :username)
        )
        ORDER BY time ASC
    )"));
    query.bindValue(QStringLiteral(":username"), username);
    query.bindValue(QStringLiteral(":target"), target);

    if (!query.exec()) {
        qCritical() << QStringLiteral("查询私聊记录失败：") << query.lastError().text();
        return records;
    }

    while (query.next()) {
        ChatRecord r;
        r.username = username;
        r.type = query.value(0).toString();
        r.sender = query.value(1).toString();
        r.receiver = query.value(2).toString();
        r.content = query.value(3).toString();
        r.time = query.value(4).toString();
        records.append(r);
    }
    return records;
}

// 插入分组（修复：bindValue键名）
bool DBHelper::insertGroup(const QString &groupName)
{
    if (!m_db.isOpen()) {
        qCritical() << QStringLiteral("数据库未打开，插入分组失败");
        return false;
    }

    QSqlQuery query;
    query.prepare(QStringLiteral(R"(
        INSERT OR IGNORE INTO groups (group_name)
        VALUES (:group_name)
    )"));
    query.bindValue(QStringLiteral(":group_name"), groupName);

    if (!query.exec()) {
        qCritical() << QStringLiteral("插入分组失败：") << query.lastError().text();
        return false;
    }
    return true;
}

// 查询所有分组和联系人（修复：SQL语句+bindValue键名）
QMap<QString, QList<QString>> DBHelper::queryAllGroupContacts()
{
    QMap<QString, QList<QString>> groupMap;
    if (!m_db.isOpen()) {
        qCritical() << QStringLiteral("数据库未打开，查询分组失败");
        return groupMap;
    }

    // 先查所有分组
    QSqlQuery groupQuery;
    if (!groupQuery.exec(QStringLiteral("SELECT group_name FROM groups ORDER BY id ASC"))) {
        qCritical() << QStringLiteral("查询分组失败：") << groupQuery.lastError().text();
        return groupMap;
    }

    // 遍历分组，查询每个分组的联系人
    while (groupQuery.next()) {
        QString groupName = groupQuery.value(0).toString();
        QList<QString> contacts;

        QSqlQuery contactQuery;
        contactQuery.prepare(QStringLiteral(R"(
            SELECT contact FROM group_contacts WHERE group_name = :group_name ORDER BY id ASC
        )"));
        contactQuery.bindValue(QStringLiteral(":group_name"), groupName);

        if (contactQuery.exec()) {
            while (contactQuery.next()) {
                contacts.append(contactQuery.value(0).toString());
            }
        } else {
            qCritical() << QStringLiteral("查询分组[%1]联系人失败：").arg(groupName) << contactQuery.lastError().text();
        }

        groupMap[groupName] = contacts;
    }
    return groupMap;
}

// 插入分组联系人（修复：bindValue键名）
bool DBHelper::insertGroupContact(const QString &groupName, const QString &contact)
{
    if (!m_db.isOpen()) {
        qCritical() << QStringLiteral("数据库未打开，插入分组联系人失败");
        return false;
    }

    // 先确保分组存在
    insertGroup(groupName);

    QSqlQuery query;
    query.prepare(QStringLiteral(R"(
        INSERT OR IGNORE INTO group_contacts (group_name, contact)
        VALUES (:group_name, :contact)
    )"));
    query.bindValue(QStringLiteral(":group_name"), groupName);
    query.bindValue(QStringLiteral(":contact"), contact);

    if (!query.exec()) {
        qCritical() << QStringLiteral("插入分组[%1]联系人[%2]失败：").arg(groupName).arg(contact) << query.lastError().text();
        return false;
    }
    return true;
}
