#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "chatserver.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_startStopButton_clicked();      // 启动/停止服务器
    void onServerStarted();                 // 服务器启动成功
    void onServerStopped();                 // 服务器停止
    void onClientConnected(const QString &ip, quint16 port); // 客户端连接
    void onClientDisconnected(const QString &ip, quint16 port); // 客户端断开
    void onMessageReceived(const QString &sender, const QString &receiver, const QString &msg); // 收到消息
    void onErrorOccurred(const QString &error); // 错误发生

private:
    void log(const QString &msg);           // 日志输出

    Ui::MainWindow *ui;
    ChatServer *m_chatServer;               // 聊天服务器核心
};

#endif // MAINWINDOW_H
