#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_tcpSocket(new QTcpSocket(this))
    , m_heartbeatTimer(new QTimer(this))
    , m_isConnected(false)
// 注释掉 DBHelper 实例化（无实际实现）
// , m_dbHelper(new DBHelper(this))
{
    ui->setupUi(this);

    // 注释掉数据库初始化（无 DBHelper 实现）
    // if (!m_dbHelper->initDB()) {
    //     QMessageBox::warning(this, "数据库错误",
    //                          "无法打开地址数据库，请检查路径是否正确！");
    // }

    // 初始化UI状态
    switchToPage(3); // 初始显示登录页（索引3）
    clearChatInput();
    ui->roomTextEdit->setReadOnly(true);
    ui->privateTextEdit->setReadOnly(true);

    // 绑定网络信号
    connect(m_tcpSocket, &QTcpSocket::connected, this, &MainWindow::onConnected);
    connect(m_tcpSocket, &QTcpSocket::disconnected, this, &MainWindow::onDisconnected);
    connect(m_tcpSocket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);
    connect(m_tcpSocket, &QTcpSocket::errorOccurred, this, &MainWindow::onSocketError);

    // 初始化心跳包（30秒一次）
    m_heartbeatTimer->setInterval(30000);
    connect(m_heartbeatTimer, &QTimer::timeout, this, &MainWindow::sendHeartbeat);

    // 初始化联系人分组
    QString defaultGroup = "默认分组";
    ui->Grouping->addItem(defaultGroup);
    m_groupContactMap[defaultGroup] = QList<QString>();
    m_currentSelectedGroup = defaultGroup;
    // 绑定分组选中事件
    connect(ui->Grouping, &QListWidget::currentItemChanged,
            this, &MainWindow::on_Grouping_currentItemChanged);

    qInfo() << "客户端初始化完成";
}

MainWindow::~MainWindow()
{
    // 退出登录并清理资源
    logout();
    delete ui;
}

// ===================== 登录页核心功能 =====================
void MainWindow::on_loginButton_clicked()
{
    // 获取登录表单数据
    QString serverIp = ui->ServerEdit->text().trimmed();
    QString username = ui->UserNameEdit->text().trimmed();
    QString password = ui->UserPasswordEdit->text().trimmed();

    // 输入校验
    if (serverIp.isEmpty() || username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "服务器地址/用户名/密码不能为空！");
        return;
    }

    // 连接服务器并发送登录请求
    if (m_tcpSocket->state() != QTcpSocket::ConnectedState) {
        // 未连接：先连接再发送
        connect(m_tcpSocket, &QTcpSocket::connected, this, [=]() {
            QJsonObject loginJson;
            loginJson["type"] = "login";
            loginJson["username"] = username;
            loginJson["password"] = password;
            sendJsonToServer(loginJson);
            m_currentUsername = username;
            // 断开临时信号，避免重复触发
            disconnect(m_tcpSocket, &QTcpSocket::connected, this, nullptr);
        });
        connectToServer(serverIp);
    } else {
        // 已连接：直接发送
        QJsonObject loginJson;
        loginJson["type"] = "login";
        loginJson["username"] = username;
        loginJson["password"] = password;
        sendJsonToServer(loginJson);
        m_currentUsername = username;
    }
}

void MainWindow::on_registerButton_clicked()
{
    // 切换到注册页（索引4）
    switchToPage(4);
}

// ===================== 注册页核心功能 =====================
void MainWindow::on_returnButton_clicked()
{
    // 注册页返回登录页
    switchToPage(3);
}

void MainWindow::on_Register_clicked()
{
    // 获取注册表单数据
    QString serverIp = ui->ServerEdit_2->text().trimmed();
    QString username = ui->UserNameEdit_2->text().trimmed();
    QString password = ui->UserPasswordEdit_2->text().trimmed();
    QString name = ui->AddressNameEdit->text().trimmed();
    QString phone = ui->TelephonenumberEdit->text().trimmed();

    // 输入校验
    if (serverIp.isEmpty() || username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "服务器地址/用户名/密码不能为空！");
        return;
    }

    // 连接服务器并发送注册请求
    if (m_tcpSocket->state() != QTcpSocket::ConnectedState) {
        connect(m_tcpSocket, &QTcpSocket::connected, this, [=]() {
            // 发送注册请求到服务器
            QJsonObject regJson;
            regJson["type"] = "register";
            regJson["username"] = username;
            regJson["password"] = password;
            regJson["name"] = name;
            regJson["phone"] = phone;
            sendJsonToServer(regJson);

            // 注释掉数据库存储（无 DBHelper 实现）
            // AddressData addr;
            // addr.username = username;
            // addr.address = address;
            // addr.phone = phone;
            // m_dbHelper->addAddress(addr);

            disconnect(m_tcpSocket, &QTcpSocket::connected, this, nullptr);
        });
        connectToServer(serverIp);
    } else {
        // 已连接：直接发送
        QJsonObject regJson;
        regJson["type"] = "register";
        regJson["username"] = username;
        regJson["password"] = password;
        regJson["name"] = name;
        regJson["phone"] = phone;
        sendJsonToServer(regJson);

        // 注释掉数据库存储（无 DBHelper 实现）
        // AddressData addr;
        // addr.username = username;
        // addr.address = address;
        // addr.phone = phone;
        // m_dbHelper->addAddress(addr);
    }
}

// ===================== 群聊页核心功能 =====================
void MainWindow::on_sayBtn_clicked()
{
    QString message = ui->sayLineEdit->text().trimmed();
    if (message.isEmpty() || !m_isConnected) return;

    // 发送公聊消息
    QJsonObject chatJson;
    chatJson["type"] = "public_chat";
    chatJson["sender"] = m_currentUsername;
    chatJson["receiver"] = "all";
    chatJson["text"] = message;
    sendJsonToServer(chatJson);

    // 本地显示自己发送的消息
    ui->roomTextEdit->append(QString("[%1][我]：%2")
                                 .arg(QDateTime::currentDateTime().toString("HH:mm:ss"))
                                 .arg(message));
    clearChatInput();
}

void MainWindow::on_logoutBtn_clicked()
{
    logout();
}

void MainWindow::on_contacts_clicked()
{
    // 切换到联系人页（索引2）
    switchToPage(2);
}

// ===================== 私聊页核心功能 =====================
void MainWindow::on_sayBtn_2_clicked()
{
    QString message = ui->sayLineEdit_2->text().trimmed();
    if (message.isEmpty() || !m_isConnected || m_privateChatTarget.isEmpty()) return;

    // 禁止和自己私聊
    if (m_privateChatTarget == m_currentUsername) {
        QMessageBox::information(this, "提示", "不能和自己私聊！");
        return;
    }

    // 发送私聊消息
    QJsonObject chatJson;
    chatJson["type"] = "private_chat";
    chatJson["sender"] = m_currentUsername;
    chatJson["receiver"] = m_privateChatTarget;
    chatJson["text"] = message;
    sendJsonToServer(chatJson);

    // 本地显示私聊消息
    ui->privateTextEdit->append(QString("[%1][我->%2]：%3")
                                    .arg(QDateTime::currentDateTime().toString("HH:mm:ss"))
                                    .arg(m_privateChatTarget)
                                    .arg(message));
    clearChatInput();
}

void MainWindow::on_logoutBtn_2_clicked()
{
    // 仅返回群聊页，不退出登录
    m_privateChatTarget.clear();
    ui->privateTextEdit->append("=== 已退出私聊，返回群聊 ===");
    switchToPage(0); // 切换到群聊页（索引0）
    clearChatInput();
}

void MainWindow::on_contacts_2_clicked()
{
    switchToPage(2);
}

// ===================== 联系人页核心功能 =====================
void MainWindow::on_Return_clicked()
{
    // 联系人页返回群聊页（索引0）
    switchToPage(0);
}

void MainWindow::on_AddGroup_clicked()
{
    QString groupName = QInputDialog::getText(this, "添加分组", "请输入分组名称：");
    if (groupName.isEmpty()) {
        return;
    }
    // 检查分组是否已存在
    if (m_groupContactMap.contains(groupName)) {
        QMessageBox::information(this, "提示", QString("分组「%1」已存在！").arg(groupName));
        return;
    }
    // 添加分组到UI和数据结构
    ui->Grouping->addItem(groupName);
    m_groupContactMap[groupName] = QList<QString>();
    QMessageBox::information(this, "成功", QString("分组「%1」创建成功！").arg(groupName));
}

void MainWindow::on_Addcontact_clicked()
{
    // 检查是否选中分组
    if (m_currentSelectedGroup.isEmpty()) {
        QMessageBox::warning(this, "提示", "请先选中一个分组！");
        return;
    }
    // 获取联系人用户名
    QString contactName = QInputDialog::getText(this, "添加联系人", "请输入联系人用户名：");
    if (contactName.isEmpty()) {
        return;
    }
    // 检查该分组下是否已存在该联系人
    QList<QString> contacts = m_groupContactMap[m_currentSelectedGroup];
    if (contacts.contains(contactName)) {
        QMessageBox::information(this, "提示",
                                 QString("分组「%1」中已存在联系人「%2」！").arg(m_currentSelectedGroup, contactName));
        return;
    }
    // 添加到数据结构和UI
    contacts.append(contactName);
    m_groupContactMap[m_currentSelectedGroup] = contacts;
    ui->userListWidget_4->addItem(contactName);
    QMessageBox::information(this, "成功",
                             QString("联系人「%1」已添加到分组「%2」！").arg(contactName, m_currentSelectedGroup));
}

// 分组选中事件（刷新对应联系人）
void MainWindow::on_Grouping_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous)
{
    Q_UNUSED(previous);
    if (!current) {
        m_currentSelectedGroup = "";
        ui->userListWidget_4->clear();
        return;
    }
    // 更新当前选中分组
    m_currentSelectedGroup = current->text();
    // 刷新联系人列表
    ui->userListWidget_4->clear();
    QList<QString> contacts = m_groupContactMap[m_currentSelectedGroup];
    for (const QString &contact : contacts) {
        ui->userListWidget_4->addItem(contact);
    }
    ui->userListWidget_4->setToolTip(QString("当前分组：%1").arg(m_currentSelectedGroup));
}

// ===================== 列表双击事件 =====================
void MainWindow::on_userListWidget_itemDoubleClicked(QListWidgetItem *item)
{
    QString targetUsername = item->text();
    // 阻止和自己发起私聊
    if (targetUsername == m_currentUsername) {
        QMessageBox::information(this, "提示", "不能和自己发起私聊！");
        return;
    }
    m_privateChatTarget = targetUsername;
    switchToPage(1); // 切换到私聊页（索引1）
    ui->privateTextEdit->append(QString("=== 开始和 %1 私聊 ===").arg(m_privateChatTarget));
}

void MainWindow::on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item)
{
    QString targetUsername = item->text();
    // 阻止和自己切换私聊对象
    if (targetUsername == m_currentUsername) {
        QMessageBox::information(this, "提示", "不能和自己私聊！");
        return;
    }
    m_privateChatTarget = targetUsername;
    ui->privateTextEdit->append(QString("=== 切换私聊对象为 %1 ===").arg(m_privateChatTarget));
}

// ===================== 网络核心功能 =====================
void MainWindow::connectToServer(const QString &serverIp)
{
    // 断开已有连接
    if (m_tcpSocket->state() == QTcpSocket::ConnectedState) {
        m_tcpSocket->disconnectFromHost();
    }
    // 连接服务器（固定端口1967）
    m_tcpSocket->connectToHost(serverIp, 1967);
    qInfo() << "正在连接服务器：" << serverIp << ":1967";
}

void MainWindow::sendJsonToServer(const QJsonObject &json)
{
    if (!m_isConnected) return;

    // 序列化JSON并发送
    QJsonDocument doc(json);
    QByteArray data = doc.toJson(QJsonDocument::Compact) + "\n";
    m_tcpSocket->write(data);
}

void MainWindow::onConnected()
{
    m_isConnected = true;
    m_heartbeatTimer->start();
    qInfo() << "已成功连接到服务器";
}

void MainWindow::onDisconnected()
{
    m_isConnected = false;
    m_heartbeatTimer->stop();
    QMessageBox::warning(this, "连接断开", "与服务器的连接已断开！");
    switchToPage(3); // 回到登录页
}

void MainWindow::onReadyRead()
{
    QByteArray data = m_tcpSocket->readAll();
    QStringList messages = QString(data).split("\n", Qt::SkipEmptyParts);

    // 解析每条消息
    for (const QString &msg : messages) {
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(msg.toUtf8(), &error);
        if (error.error != QJsonParseError::NoError) {
            qWarning() << "JSON解析错误：" << error.errorString();
            continue;
        }
        handleServerResponse(doc.object());
    }
}

void MainWindow::handleServerResponse(const QJsonObject &response)
{
    QString type = response["type"].toString();

    // 登录成功
    if (type == "login_success") {
        QMessageBox::information(this, "登录成功", "欢迎使用聊天系统！");
        switchToPage(0); // 跳转到群聊页（索引0）
        clearChatInput();
        ui->roomTextEdit->clear();

        // 注释掉地址展示（依赖 DBHelper）
        // showUserAddress();

        qInfo() << "登录成功，当前用户：" << m_currentUsername;
    }
    // 登录失败
    else if (type == "login_failed") {
        QMessageBox::warning(this, "登录失败", response["reason"].toString());
    }
    // 注册成功
    else if (type == "register_success") {
        QMessageBox::information(this, "注册成功", "注册成功，请返回登录页登录！");
        switchToPage(3); // 回到登录页
    }
    // 注册失败
    else if (type == "register_failed") {
        QMessageBox::warning(this, "注册失败", response["reason"].toString());
    }
    // 公聊消息
    else if (type == "public_chat") {
        QString sender = response["sender"].toString();
        QString text = response["text"].toString();
        if (sender != m_currentUsername) { // 避免重复显示自己的消息
            ui->roomTextEdit->append(QString("[%1][%2]：%3")
                                         .arg(QDateTime::currentDateTime().toString("HH:mm:ss"))
                                         .arg(sender)
                                         .arg(text));
        }
    }
    // 私聊消息
    else if (type == "private_chat") {
        QString sender = response["sender"].toString();
        QString text = response["text"].toString();
        ui->privateTextEdit->append(QString("[%1][%2->我]：%3")
                                        .arg(QDateTime::currentDateTime().toString("HH:mm:ss"))
                                        .arg(sender)
                                        .arg(text));
        // 自动切换到私聊页
        switchToPage(1);
        m_privateChatTarget = sender;
    }
    // 在线用户列表更新
    else if (type == "userlist") {
        QJsonArray userArray = response["userlist"].toArray();
        updateOnlineUserList(userArray);
    }
    // 心跳包确认
    else if (type == "heartbeat_ack") {
        qDebug() << "收到心跳包确认";
    }
}

void MainWindow::onSocketError(QAbstractSocket::SocketError error)
{
    Q_UNUSED(error);
    QMessageBox::critical(this, "网络错误",
                          QString("连接服务器失败：\n%1").arg(m_tcpSocket->errorString()));
    m_isConnected = false;
}

void MainWindow::sendHeartbeat()
{
    // 发送心跳包保活
    QJsonObject heartbeatJson;
    heartbeatJson["type"] = "heartbeat";
    heartbeatJson["username"] = m_currentUsername;
    sendJsonToServer(heartbeatJson);
}

// 注释掉 showUserAddress（依赖 DBHelper）
// void MainWindow::showUserAddress()
// {
//     if (m_currentUsername.isEmpty()) return;

//     AddressData addr = m_dbHelper->getAddressByUsername(m_currentUsername);
//     if (addr.id != -1) {
//         qInfo() << "【当前用户地址】：" << addr.address << "（联系电话：" << addr.phone << "）";
//     } else {
//         qInfo() << "【当前用户地址】：暂无地址信息";
//     }
// }

// ===================== 辅助工具函数 =====================
void MainWindow::updateOnlineUserList(const QJsonArray &userArray)
{
    // 清空并更新在线用户列表
    ui->userListWidget->clear();
    ui->userListWidget_2->clear();

    for (const QJsonValue &val : userArray) {
        QString username = val.toString();
        ui->userListWidget->addItem(username);
        ui->userListWidget_2->addItem(username);
    }
}

void MainWindow::switchToPage(int index)
{
    // 切换StackedWidget页面
    ui->stackedWidget->setCurrentIndex(index);
    qInfo() << "切换到页面索引：" << index;
}

void MainWindow::clearChatInput()
{
    // 清空所有聊天输入框
    ui->sayLineEdit->clear();
    ui->sayLineEdit_2->clear();
}

void MainWindow::logout()
{
    // 退出登录逻辑
    if (m_isConnected) {
        // 发送退出请求
        QJsonObject logoutJson;
        logoutJson["type"] = "logout";
        logoutJson["username"] = m_currentUsername;
        sendJsonToServer(logoutJson);

        // 断开连接
        m_tcpSocket->disconnectFromHost();
    }

    // 重置状态
    m_currentUsername.clear();
    m_privateChatTarget.clear();
    ui->roomTextEdit->clear();
    ui->privateTextEdit->clear();
    switchToPage(3); // 回到登录页

    qInfo() << "已退出登录";
}
