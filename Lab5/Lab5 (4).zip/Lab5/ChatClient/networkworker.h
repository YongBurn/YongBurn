#ifndef NETWORKWORKER_H
#define NETWORKWORKER_H

#include <QObject>
#include <QTcpSocket>
#include <QMutex>
#include <QTimer>

class NetworkWorker : public QObject
{
    Q_OBJECT

public:
    explicit NetworkWorker(QObject *parent = nullptr);
    ~NetworkWorker();

    bool isConnected() const;
    QString lastError() const;

public slots:
    void connectToServer(const QString &address, quint16 port);
    void sendData(const QByteArray &data);
    void disconnectFromHost();
    void setAutoReconnect(bool enabled, int interval = 5000, int maxAttempts = 10);

signals:
    void connected();
    void disconnected();
    void dataReceived(const QByteArray &data);
    void errorOccurred(const QString &error);
    void connectionStatusChanged(bool connected);
    void reconnectAttempt(int attempt, int maxAttempts);
    void reconnectFailed();

private slots:
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onErrorOccurred(QAbstractSocket::SocketError socketError);
    void onReconnectTimeout();

private:
    QTcpSocket *m_socket;
    QMutex m_socketMutex;
    QTimer *m_reconnectTimer;
    QString m_serverAddress;
    quint16 m_serverPort;
    int m_reconnectAttempts;
    int m_maxReconnectAttempts;
    bool m_autoReconnect;
    QString m_lastError;
    bool m_manualDisconnect;

    void setupSocket();
    void cleanupSocket();
    void startReconnectTimer();
    void stopReconnectTimer();
};

#endif // NETWORKWORKER_H
