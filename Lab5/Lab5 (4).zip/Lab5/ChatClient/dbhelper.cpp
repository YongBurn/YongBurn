#include "dbhelper.h"

DBHelper::DBHelper(QObject *parent)
    : QObject(parent)
{
    // 初始化SQLite驱动
    m_db = QSqlDatabase::addDatabase("QSQLITE");

    // 修复：硬编码数据库路径（二选一，均支持）
    // 格式1：正斜杠（推荐，无需转义，Qt自动识别Windows路径）
    m_db.setDatabaseName("D:/qt/task/Lab5/Lab5/Lab4a/Lab4a.db");

    // 格式2：双反斜杠（正确转义，兼容所有场景）
    // m_db.setDatabaseName("D:\\qt\\task\\Lab5\\Lab5\\Lab4a\\Lab4a.db");
}

DBHelper::~DBHelper()
{
    // 析构时关闭数据库连接
    if (m_db.isOpen()) {
        m_db.close();
        qDebug() << "数据库连接已关闭";
    }
}

bool DBHelper::initDB()
{
    // 打开数据库
    if (!m_db.open()) {
        qCritical() << "数据库打开失败：" << m_db.lastError().text();
        return false;
    }

    // 创建地址表（不存在则创建）
    QSqlQuery query;
    QString createTableSql = R"(
        CREATE TABLE IF NOT EXISTS address (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            address TEXT NOT NULL,
            phone TEXT
        )
    )";

    if (!query.exec(createTableSql)) {
        qCritical() << "创建地址表失败：" << query.lastError().text();
        return false;
    }

    qInfo() << "数据库初始化成功，路径：" << m_db.databaseName();
    return true;
}

// 其余函数（addAddress/updateAddress等）保持不变，无需修改
bool DBHelper::addAddress(const AddressData &addr)
{
    // 确保数据库已打开
    if (!m_db.isOpen() && !initDB()) {
        return false;
    }

    QSqlQuery query;
    // 预处理SQL（防止注入）
    query.prepare("INSERT INTO address (username, address, phone) VALUES (:username, :address, :phone)");
    query.bindValue(":username", addr.username);
    query.bindValue(":address", addr.address);
    query.bindValue(":phone", addr.phone);

    if (!query.exec()) {
        qWarning() << "添加地址失败：" << query.lastError().text();
        return false;
    }

    qInfo() << "地址添加成功，用户名：" << addr.username;
    return true;
}

bool DBHelper::updateAddress(const AddressData &addr)
{
    if (!m_db.isOpen() && !initDB()) {
        return false;
    }

    QSqlQuery query;
    query.prepare("UPDATE address SET address=:address, phone=:phone WHERE username=:username");
    query.bindValue(":username", addr.username);
    query.bindValue(":address", addr.address);
    query.bindValue(":phone", addr.phone);

    if (!query.exec()) {
        qWarning() << "更新地址失败：" << query.lastError().text();
        return false;
    }

    qInfo() << "地址更新成功，用户名：" << addr.username;
    return true;
}

bool DBHelper::deleteAddress(int id)
{
    if (!m_db.isOpen() && !initDB()) {
        return false;
    }

    QSqlQuery query;
    query.prepare("DELETE FROM address WHERE id=:id");
    query.bindValue(":id", id);

    if (!query.exec()) {
        qWarning() << "删除地址失败：" << query.lastError().text();
        return false;
    }

    qInfo() << "地址删除成功，ID：" << id;
    return true;
}

AddressData DBHelper::getAddressByUsername(const QString &username)
{
    AddressData addr;
    addr.id = -1; // 初始化为无效ID

    if (!m_db.isOpen() && !initDB()) {
        return addr;
    }

    QSqlQuery query;
    query.prepare("SELECT id, username, address, phone FROM address WHERE username=:username");
    query.bindValue(":username", username);

    if (query.exec() && query.next()) {
        // 读取查询结果
        addr.id = query.value(0).toInt();
        addr.username = query.value(1).toString();
        addr.address = query.value(2).toString();
        addr.phone = query.value(3).toString();
        qInfo() << "查询地址成功，用户名：" << username;
    } else {
        qWarning() << "查询地址失败（用户无地址）：" << username;
    }

    return addr;
}

QList<AddressData> DBHelper::getAllAddresses()
{
    QList<AddressData> addrList;

    if (!m_db.isOpen() && !initDB()) {
        return addrList;
    }

    QSqlQuery query;
    if (query.exec("SELECT id, username, address, phone FROM address")) {
        while (query.next()) {
            AddressData addr;
            addr.id = query.value(0).toInt();
            addr.username = query.value(1).toString();
            addr.address = query.value(2).toString();
            addr.phone = query.value(3).toString();
            addrList.append(addr);
        }
        qInfo() << "查询所有地址成功，总数：" << addrList.size();
    } else {
        qWarning() << "查询所有地址失败：" << query.lastError().text();
    }

    return addrList;
}
