#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.setWindowTitle("聊天室客户端（带地址管理）");
    w.resize(800, 600); // 设置默认窗口大小
    w.show();
    return a.exec();
}
