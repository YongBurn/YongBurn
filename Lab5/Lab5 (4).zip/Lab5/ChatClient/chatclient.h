#ifndef CHATCLIENT_H
#define CHATCLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <QTimer>
#include <QJsonObject>
#include <QJsonDocument>
#include <QHostAddress>

class ChatClient : public QObject
{
    Q_OBJECT

public:
    explicit ChatClient(QObject *parent = nullptr);
    ~ChatClient();

    void sendPrivateMessage(const QString &receiver, const QString &text);
    void sendMessage(const QString &text, const QString &type = "message");

    void setUserName(const QString &name) { m_userName = name; }
    QString userName() const { return m_userName; }

    void connectToServer(const QHostAddress &address, quint16 port);
    void disconnectFromHost();
    bool isConnected() const;

signals:
    void connected();
    void disconnected();
    void jsonReceived(const QJsonObject &docObj);
    void connectionError(const QString &error);

private slots:
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onSocketError(QAbstractSocket::SocketError socketError);
    void sendHeartbeat();

private:
    QTcpSocket *m_clientSocket;
    QString m_userName;
    QTimer *m_heartbeatTimer;
    QByteArray m_buffer;
};

#endif // CHATCLIENT_H
