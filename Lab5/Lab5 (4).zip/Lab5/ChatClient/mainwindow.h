#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTimer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMessageBox>
#include <QDateTime>
#include <QListWidgetItem>
#include <QInputDialog>
#include <QMap>
#include <QList>

// 注释掉 DBHelper 相关前置声明（无实际实现）
// class DBHelper;
struct AddressData {
    int id = -1;
    QString username;
    QString address;
    QString phone;
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // 登录页槽函数
    void on_loginButton_clicked();
    void on_registerButton_clicked();

    // 注册页槽函数
    void on_returnButton_clicked();
    void on_Register_clicked();

    // 群聊页槽函数
    void on_sayBtn_clicked();
    void on_logoutBtn_clicked();
    void on_contacts_clicked();

    // 私聊页槽函数
    void on_sayBtn_2_clicked();
    void on_logoutBtn_2_clicked();
    void on_contacts_2_clicked();

    // 联系人页槽函数
    void on_Return_clicked();
    void on_AddGroup_clicked();
    void on_Addcontact_clicked();
    void on_Grouping_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous);

    // 列表双击事件槽函数
    void on_userListWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item);

    // 网络相关槽函数
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onSocketError(QAbstractSocket::SocketError error);

private:
    // UI对象
    Ui::MainWindow *ui;

    // 网络相关
    QTcpSocket *m_tcpSocket;
    QTimer *m_heartbeatTimer;
    bool m_isConnected;

    // 用户状态
    QString m_currentUsername;
    QString m_privateChatTarget; // 私聊目标用户名

    // 注释掉 DBHelper 相关成员（无实际实现）
    // DBHelper *m_dbHelper;

    // 分组-联系人关联
    QMap<QString, QList<QString>> m_groupContactMap; // 分组名 -> 联系人列表
    QString m_currentSelectedGroup; // 当前选中的分组名

    // 核心函数
    void connectToServer(const QString &serverIp);
    void sendJsonToServer(const QJsonObject &json);
    void handleServerResponse(const QJsonObject &response);
    void sendHeartbeat();
    void logout();
    void switchToPage(int index);
    void clearChatInput();
    void updateOnlineUserList(const QJsonArray &userArray);
    // 注释掉 showUserAddress（依赖 DBHelper）
    // void showUserAddress();
};

#endif // MAINWINDOW_H
