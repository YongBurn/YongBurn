#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "chatserver.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // 启动/停止按钮点击
    void on_startStopButton_clicked();
    // 接收服务器日志
    void onLogMessage(const QString &msg);
    // 接收服务器错误
    void onServerError(const QString &errorMsg);

private:
    Ui::MainWindow *ui;
    ChatServer *m_server; // 服务器实例
    quint16 m_fixedPort;  // 监听端口
};

#endif // MAINWINDOW_H
