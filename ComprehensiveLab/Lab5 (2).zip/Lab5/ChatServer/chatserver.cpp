#include "chatserver.h"

ChatServer::ChatServer(QObject *parent)
    : QTcpServer(parent)
{
}

ChatServer::~ChatServer()
{
    stop();
}

bool ChatServer::start(quint16 port)
{
    if (m_isRunning) {
        emit logMessage("服务器已运行，端口：" + QString::number(port));
        return true;
    }

    if (this->listen(QHostAddress::Any, port)) {
        m_isRunning = true;
        QString msg = QString("[%1] 服务器启动成功，监听端口：%2")
                          .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                          .arg(port);
        emit logMessage(msg);
        emit onlineUserCountChanged(0);
        return true;
    } else {
        QString errorMsg = QString("[%1] 服务器启动失败：%2")
                               .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                               .arg(this->errorString());
        emit errorOccurred(errorMsg);
        emit logMessage(errorMsg);
        return false;
    }
}

void ChatServer::stop()
{
    if (!m_isRunning) {
        emit logMessage("服务器已停止");
        return;
    }

    this->close();
    for (QTcpSocket *socket : m_onlineClients) {
        socket->disconnectFromHost();
        socket->deleteLater();
    }
    m_onlineClients.clear();
    m_isRunning = false;

    emit logMessage(QString("[%1] 服务器已停止，在线人数清零").arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss")));
    emit onlineUserCountChanged(0);
}

void ChatServer::incomingConnection(qintptr socketDescriptor)
{
    QTcpSocket *clientSocket = new QTcpSocket(this);
    if (!clientSocket->setSocketDescriptor(socketDescriptor)) {
        emit errorOccurred("客户端Socket创建失败：" + clientSocket->errorString());
        clientSocket->deleteLater();
        return;
    }

    connect(clientSocket, &QTcpSocket::readyRead, this, &ChatServer::onReadyRead);
    connect(clientSocket, &QTcpSocket::disconnected, this, &ChatServer::onDisconnected);
    connect(clientSocket, QOverload<QAbstractSocket::SocketError>::of(&QTcpSocket::errorOccurred),
            this, &ChatServer::onSocketError);

    m_onlineClients.append(clientSocket);
    QString clientInfo = QString("%1:%2").arg(clientSocket->peerAddress().toString()).arg(clientSocket->peerPort());
    QString logMsg = QString("[%1] 客户端连接：%2，当前在线：%3")
                         .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                         .arg(clientInfo)
                         .arg(m_onlineClients.size());
    emit logMessage(logMsg);
    emit onlineUserCountChanged(m_onlineClients.size());
}

void ChatServer::onReadyRead()
{
    QTcpSocket *senderSocket = qobject_cast<QTcpSocket*>(sender());
    if (!senderSocket) return;

    QByteArray recvData = senderSocket->readAll();
    if (recvData.isEmpty()) {
        emit logMessage("收到空数据，忽略");
        return;
    }

    // 清理无效字符（解决garbage at the end问题）
    QByteArray cleanData = recvData.trimmed();
    QJsonObject jsonMsg = parseJsonMessage(cleanData);
    QString msgType = jsonMsg["type"].toString().trimmed();

    if (msgType == "public_chat") {
        QString logMsg = QString("[%1] 收到群聊消息，发送者：%2，内容：%3")
                             .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                             .arg(jsonMsg["sender"].toString())
                             .arg(jsonMsg["content"].toString());
        emit logMessage(logMsg);
        // 广播（保留原始分隔符，排除发送者）
        broadcastPublicChat(recvData, senderSocket);
    } else {
        emit logMessage(QString("[%1] 非群聊消息，类型：%2，原始数据：%3")
                            .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                            .arg(msgType)
                            .arg(QString(cleanData)));
    }
}

void ChatServer::onDisconnected()
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket*>(sender());
    if (!clientSocket) return;

    QString clientInfo = QString("%1:%2").arg(clientSocket->peerAddress().toString()).arg(clientSocket->peerPort());
    m_onlineClients.removeOne(clientSocket);

    QString logMsg = QString("[%1] 客户端断开：%2，当前在线：%3")
                         .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                         .arg(clientInfo)
                         .arg(m_onlineClients.size());
    emit logMessage(logMsg);
    emit onlineUserCountChanged(m_onlineClients.size());

    clientSocket->deleteLater();
}

void ChatServer::onSocketError(QAbstractSocket::SocketError socketError)
{
    QTcpSocket *clientSocket = qobject_cast<QTcpSocket*>(sender());
    if (!clientSocket) return;

    QString errorMsg = QString("[%1] 客户端错误：%2（错误码：%3），客户端：%4:%5")
                           .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                           .arg(clientSocket->errorString())
                           .arg(socketError)
                           .arg(clientSocket->peerAddress().toString())
                           .arg(clientSocket->peerPort());
    emit errorOccurred(errorMsg);
    emit logMessage(errorMsg);

    if (clientSocket->isOpen()) {
        clientSocket->disconnectFromHost();
    }
}

QJsonObject ChatServer::parseJsonMessage(const QByteArray &data)
{
    QJsonParseError jsonError;
    QJsonDocument doc = QJsonDocument::fromJson(data, &jsonError);

    if (jsonError.error != QJsonParseError::NoError) {
        QString errorMsg = QString("[%1] JSON解析错误：%2，原始数据：%3")
                               .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                               .arg(jsonError.errorString())
                               .arg(QString(data));
        emit errorOccurred(errorMsg);
        emit logMessage(errorMsg);
        return QJsonObject();
    }

    if (!doc.isObject()) {
        emit errorOccurred("JSON不是对象类型，原始数据：" + QString(data));
        return QJsonObject();
    }

    return doc.object();
}

void ChatServer::broadcastPublicChat(const QByteArray &data, QTcpSocket *excludeSocket)
{
    int successCount = 0;
    QString logMsg = QString("[%1] 开始广播群聊消息，在线客户端数：%2")
                         .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                         .arg(m_onlineClients.size());
    emit logMessage(logMsg);

    for (QTcpSocket *client : m_onlineClients) {
        if (client == excludeSocket) {
            emit logMessage("跳过发送者：" + QString("%1:%2").arg(client->peerAddress().toString()).arg(client->peerPort()));
            continue;
        }

        if (!client->isValid() || !client->isWritable()) {
            emit errorOccurred("客户端不可写：" + QString("%1:%2").arg(client->peerAddress().toString()).arg(client->peerPort()));
            continue;
        }

        qint64 bytes = client->write(data);
        client->flush();
        if (bytes > 0) {
            successCount++;
            emit logMessage("成功广播给：" + QString("%1:%2").arg(client->peerAddress().toString()).arg(client->peerPort()));
        } else {
            emit errorOccurred("广播失败给：" + QString("%1:%2").arg(client->peerAddress().toString()).arg(client->peerPort()));
        }
    }

    emit logMessage(QString("[%1] 广播完成，成功发送给%2个客户端").arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss")).arg(successCount));
}
