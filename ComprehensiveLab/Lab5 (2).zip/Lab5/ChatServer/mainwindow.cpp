#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "chatserver.h"
#include <QMessageBox>
#include <QDateTime>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_server(new ChatServer(this)) // 服务器实例
    , m_fixedPort(1967) // 固定端口（和客户端一致）
{
    ui->setupUi(this);

    // ========== 仅绑定存在的信号（移除onlineUserCountChanged） ==========
    connect(m_server, &ChatServer::logMessage, this, &MainWindow::onLogMessage);
    connect(m_server, &ChatServer::errorOccurred, this, &MainWindow::onServerError);

    // ========== 初始化UI状态（移除onlineCountLabel相关） ==========
    ui->startStopButton->setText("启动服务器");
    // 日志框设为只读
    ui->logEditer->setReadOnly(true);
}

MainWindow::~MainWindow()
{
    // 停止服务器
    if (m_server) {
        m_server->stop();
    }
    delete ui;
}

// ========== 启动/停止按钮点击事件（适配UI） ==========
void MainWindow::on_startStopButton_clicked()
{
    // 判断服务器是否正在监听
    if (!m_server->isListening()) {
        // 未运行 → 启动服务器
        if (m_server->start(m_fixedPort)) {
            ui->startStopButton->setText("停止服务器");
            QMessageBox::information(this, "成功", "服务器启动成功！");
        } else {
            QMessageBox::critical(this, "失败", "服务器启动失败！");
        }
    } else {
        // 运行中 → 停止服务器
        m_server->stop();
        ui->startStopButton->setText("启动服务器");
        QMessageBox::information(this, "成功", "服务器已停止！");
    }
}

// ========== 接收服务器日志消息（适配logEditer控件） ==========
void MainWindow::onLogMessage(const QString &msg)
{
    // 格式化日志：[时间] 内容
    QString logStr = QString("[%1] %2")
                         .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                         .arg(msg);
    // 追加到日志框（UI里的控件名称是logEditer）
    ui->logEditer->appendPlainText(logStr);
}

// ========== 接收服务器错误消息（适配logEditer控件） ==========
void MainWindow::onServerError(const QString &errorMsg)
{
    // 错误日志标红显示（QPlainTextEdit支持HTML）
    QString errorLog = QString("[%1] <font color='red'>[错误] %2</font>")
                           .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"))
                           .arg(errorMsg);
    ui->logEditer->appendHtml(errorLog);
}
