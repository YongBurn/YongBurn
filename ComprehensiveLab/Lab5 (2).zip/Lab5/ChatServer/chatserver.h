#ifndef CHATSERVER_H
#define CHATSERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QList>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QDebug>
#include <QDateTime>

class ChatServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit ChatServer(QObject *parent = nullptr);
    ~ChatServer() override;

    bool start(quint16 port = 1967);
    void stop();
    int onlineUserCount() const { return m_onlineClients.size(); }

signals:
    void logMessage(const QString &msg);
    void errorOccurred(const QString &errorMsg);
    void onlineUserCountChanged(int count);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

private slots:
    void onReadyRead();
    void onDisconnected();
    void onSocketError(QAbstractSocket::SocketError socketError);

private:
    QJsonObject parseJsonMessage(const QByteArray &data);
    void broadcastPublicChat(const QByteArray &data, QTcpSocket *excludeSocket = nullptr);

    QList<QTcpSocket*> m_onlineClients;
    bool m_isRunning = false;
};

#endif // CHATSERVER_H
