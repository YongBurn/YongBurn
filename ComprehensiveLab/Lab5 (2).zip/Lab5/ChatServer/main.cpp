#include <QCoreApplication>
#include "chatserver.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    ChatServer server;
    // 启动服务器（监听1967端口）
    server.start(1967);

    return a.exec();
}
