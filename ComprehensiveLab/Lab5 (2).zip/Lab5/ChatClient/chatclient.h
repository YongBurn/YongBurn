#ifndef CHATCLIENT_H
#define CHATCLIENT_H

#include <QObject>
#include <QTcpSocket>
#include <QJsonObject>
#include <QJsonParseError>
#include <QDateTime>
#include <QString>

class ChatClient : public QObject
{
    Q_OBJECT
public:
    explicit ChatClient(QObject *parent = nullptr);
    ~ChatClient() override;

    // 修正：支持重试次数+错误信息输出（匹配mainwindow的调用）
    bool connectToServer(const QString &host, quint16 port,
                         int timeout = 5000, int retryCount = 1,
                         QString *errorMsg = nullptr);
    void disconnectFromServer();
    bool isConnected() const { return m_socket && m_socket->state() == QTcpSocket::ConnectedState; }

    // 群聊消息（原有）
    bool sendPublicChat(const QString &sender, const QString &content);
    // 新增：登录消息
    bool sendLoginMessage(const QString &username);
    // 新增：私聊消息
    bool sendPrivateChat(const QString &sender, const QString &receiver, const QString &content);

signals:
    // 新增：连接状态变化信号
    void connectionStatusChanged(bool isConnected);
    void connected();
    void disconnected();
    void errorOccurred(const QString &errorMsg);
    void jsonMessageReceived(const QJsonObject &json);

private slots:
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onSocketError(QAbstractSocket::SocketError socketError);

private:
    // 通用发送JSON消息（内部复用）
    bool sendJsonMessage(const QJsonObject &json);
    // 获取当前时间字符串（统一格式）
    QString getCurrentTimeString() {
        return QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    }

    QTcpSocket *m_socket = nullptr;
    QByteArray m_recvBuffer; // 接收缓存（解决拆包/粘包）
    QString m_currentUsername; // 登录的用户名
};

#endif // CHATCLIENT_H
