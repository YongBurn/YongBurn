#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dbmanager.h"
#include "messageitem.h"
#include <QMessageBox>
#include <QDebug>
#include <QDateTime>
#include <QHostAddress>
#include <QRegularExpression>
#include <QInputDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_chatClient(new ChatClient(this))
{
    ui->setupUi(this);
    initPageIndex();
    initUI();
    initConnections();
    DBManager::getInstance()->initDB();
    switchToLoginPage();
}

MainWindow::~MainWindow()
{
    if (m_isLoggedIn) {
        m_chatClient->disconnectFromServer();
    }
    DBManager::destroyInstance();
    delete ui;
}

void MainWindow::initUI()
{
    this->setWindowTitle("多人即时通讯系统");

    ui->ServerEdit->setText("127.0.0.1:1967");
    ui->ServerEdit_2->setText("127.0.0.1:1967");
    ui->UserPasswordEdit->setEchoMode(QLineEdit::Password);
    ui->UserPasswordEdit_2->setEchoMode(QLineEdit::Password);

    setWidgetEnabled(false, ui->sayLineEdit);
    setWidgetEnabled(false, ui->sayBtn);
    setWidgetEnabled(false, ui->logoutBtn);
    setWidgetEnabled(false, ui->contacts);

    setWidgetEnabled(false, ui->sayLineEdit_2);
    setWidgetEnabled(false, ui->sayBtn_2);
    setWidgetEnabled(false, ui->logoutBtn_2);
    setWidgetEnabled(false, ui->contacts_2);

    ui->roomTextEdit->setReadOnly(true);
    ui->privateTextEdit->setReadOnly(true);

    ui->Grouping->addItem("默认分组");
    ui->Grouping->setCurrentRow(0);
}

void MainWindow::initConnections()
{
    connect(m_chatClient.data(), &ChatClient::jsonMessageReceived, this, &MainWindow::onJsonMessageReceived);
    connect(m_chatClient.data(), &ChatClient::connectionStatusChanged, this, &MainWindow::onConnectionStatusChanged);
    connect(m_chatClient.data(), &ChatClient::errorOccurred, this, &MainWindow::onClientErrorOccurred);
}

void MainWindow::initPageIndex()
{
    PAGE_CHAT = 0;
    PAGE_PRIVATE_CHAT = 1;
    PAGE_CONTACTS = 2;
    PAGE_LOGIN = 3;
    PAGE_REGISTER = 4;
}

void MainWindow::switchToLoginPage()
{
    ui->stackedWidget->setCurrentIndex(PAGE_LOGIN);
    this->setWindowTitle("多人即时通讯系统 - 登录");
    clearInputFields();
}

void MainWindow::switchToRegisterPage()
{
    ui->stackedWidget->setCurrentIndex(PAGE_REGISTER);
    this->setWindowTitle("多人即时通讯系统 - 注册");
    clearInputFields();
}

void MainWindow::switchToChatPage()
{
    ui->stackedWidget->setCurrentIndex(PAGE_CHAT);
    this->setWindowTitle(QString("多人即时通讯系统 - %1（群聊）").arg(m_currentUsername));
    setWidgetEnabled(true, ui->sayLineEdit);
    setWidgetEnabled(true, ui->sayBtn);
    setWidgetEnabled(true, ui->logoutBtn);
    setWidgetEnabled(true, ui->contacts);
}

void MainWindow::switchToPrivateChatPage()
{
    ui->stackedWidget->setCurrentIndex(PAGE_PRIVATE_CHAT);
    this->setWindowTitle(QString("多人即时通讯系统 - %1（私聊）").arg(m_currentUsername));
    setWidgetEnabled(true, ui->sayLineEdit_2);
    setWidgetEnabled(true, ui->sayBtn_2);
    setWidgetEnabled(true, ui->logoutBtn_2);
    setWidgetEnabled(true, ui->contacts_2);
}

void MainWindow::switchToContactsPage()
{
    ui->stackedWidget->setCurrentIndex(PAGE_CONTACTS);
    this->setWindowTitle(QString("多人即时通讯系统 - %1（联系人）").arg(m_currentUsername));

    // 加载所有分组（去重）
    ui->Grouping->clear();
    QStringList groups = DBManager::getInstance()->getContactGroups();
    if (groups.isEmpty()) {
        DBManager::getInstance()->addContactGroup("默认分组");
        groups.append("默认分组");
    }
    ui->Grouping->addItems(groups);

    // 加载默认分组的联系人
    if (!groups.isEmpty()) {
        ui->Grouping->setCurrentRow(0);
        QStringList contacts = DBManager::getInstance()->getContactsByGroup(groups.first());
        ui->userListWidget_4->clear();
        ui->userListWidget_4->addItems(contacts);
    }
}

bool MainWindow::doLogin(const QString &serverAddr, const QString &username, const QString &password)
{
    if (serverAddr.isEmpty() || username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "服务器地址、用户名、密码不能为空！");
        return false;
    }

    if (!DBManager::getInstance()->validateUser(username, password)) {
        QMessageBox::critical(this, "登录失败", "用户名或密码错误！");
        return false;
    }

    QString addr = serverAddr;
    quint16 port = 1967;
    if (serverAddr.contains(":")) {
        QStringList parts = serverAddr.split(":");
        if (parts.size() != 2) {
            QMessageBox::warning(this, "输入错误", "服务器地址格式错误（示例：127.0.0.1:1967）");
            return false;
        }
        addr = parts[0].trimmed();
        bool portOk;
        port = parts[1].toUShort(&portOk);
        if (!portOk || port < 1 || port > 65535) {
            QMessageBox::warning(this, "输入错误", "端口号必须是1-65535之间的数字");
            return false;
        }
    }

    QHostAddress hostAddr;
    if (!hostAddr.setAddress(addr)) {
        int ret = QMessageBox::question(this, "地址校验",
                                        QString("地址%1不是合法IP，是否继续尝试连接？").arg(addr),
                                        QMessageBox::Yes | QMessageBox::No);
        if (ret != QMessageBox::Yes) {
            return false;
        }
    }

    QMessageBox connectingBox(this);
    connectingBox.setWindowTitle("连接中");
    connectingBox.setText(QString("正在连接服务器 %1:%2，请稍候...").arg(addr).arg(port));
    connectingBox.setStandardButtons(QMessageBox::NoButton);
    connectingBox.show();

    QString errorMsg;
    bool connectOk = m_chatClient->connectToServer(addr, port, 5000, 2, &errorMsg);

    connectingBox.close();

    if (!connectOk) {
        QMessageBox::StandardButton ret = QMessageBox::critical(this, "连接失败",
                                                                errorMsg + "\n\n是否重试？",
                                                                QMessageBox::Retry | QMessageBox::Cancel);
        if (ret == QMessageBox::Retry) {
            return doLogin(serverAddr, username, password);
        }
        return false;
    }

    if (!m_chatClient->sendLoginMessage(username)) {
        QMessageBox::critical(this, "登录失败", "登录消息发送失败！");
        m_chatClient->disconnectFromServer();
        return false;
    }

    m_currentUsername = username;
    m_currentServerAddr = serverAddr;
    m_isLoggedIn = true;

    const QList<MessageItem> history = DBManager::getInstance()->getChatRecords(
        username, ChatEnum::ChatType::Public, "all"
        );
    ui->roomTextEdit->clear();
    for (const MessageItem &item : history) {
        showPublicMessage(item);
    }

    QMessageBox::information(this, "登录成功", QString("欢迎 %1 登录！").arg(username));
    switchToChatPage();
    return true;
}

bool MainWindow::doRegister(const QString &serverAddr, const QString &username, const QString &password,
                            const QString &realName, const QString &phone)
{
    if (serverAddr.isEmpty() || username.isEmpty() || password.isEmpty() ||
        realName.isEmpty() || phone.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "所有注册信息不能为空！");
        return false;
    }

    QRegularExpression phoneReg("^1[3-9]\\d{9}$");
    if (!phoneReg.match(phone).hasMatch()) {
        QMessageBox::warning(this, "输入错误", "手机号格式不正确！请输入11位有效数字（如13812345678）");
        return false;
    }

    if (!DBManager::getInstance()->addUser(username, password, realName, phone)) {
        QMessageBox::critical(this, "注册失败", "用户注册失败（用户名可能已存在）！");
        return false;
    }

    QMessageBox::information(this, "注册成功", QString("用户 %1 注册成功，请登录！").arg(username));
    switchToLoginPage();
    ui->UserNameEdit->setText(username);
    return true;
}

void MainWindow::sendPublicMessage()
{
    const QString content = ui->sayLineEdit->text().trimmed();
    if (content.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "群聊消息内容不能为空！");
        return;
    }

    if (!m_chatClient->sendPublicChat(m_currentUsername, content)) {
        QMessageBox::critical(this, "发送失败", "群聊消息发送失败，请检查服务器连接！");
        return;
    }

    ui->sayLineEdit->clear();

    MessageItem item;
    item.sender = m_currentUsername;
    item.content = content;
    item.timestamp = getCurrentTimeString();
    item.messageType = ChatEnum::MessageType::PublicChat;
    showPublicMessage(item);

    ChatRecord record;
    record.sender = m_currentUsername;
    record.receiver = "all";
    record.content = content;
    record.timestamp = item.timestamp;
    record.chatType = ChatEnum::ChatType::Public;
    DBManager::getInstance()->saveChatRecord(m_currentUsername, record);
}

void MainWindow::sendPrivateMessage()
{
    if (m_currentPrivateTarget.isEmpty()) {
        QMessageBox::warning(this, "选择对象", "请先从右侧列表选择私聊对象！");
        return;
    }

    const QString content = ui->sayLineEdit_2->text().trimmed();
    if (content.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "私聊消息内容不能为空！");
        return;
    }

    if (!m_chatClient->sendPrivateChat(m_currentUsername, m_currentPrivateTarget, content)) {
        QMessageBox::critical(this, "发送失败", "私聊消息发送失败，请检查服务器连接！");
        return;
    }

    ui->sayLineEdit_2->clear();

    MessageItem item;
    item.sender = m_currentUsername;
    item.content = content;
    item.timestamp = getCurrentTimeString();
    item.messageType = ChatEnum::MessageType::PrivateChat;
    showPrivateMessage(item);

    ChatRecord record;
    record.sender = m_currentUsername;
    record.receiver = m_currentPrivateTarget;
    record.content = content;
    record.timestamp = item.timestamp;
    record.chatType = ChatEnum::ChatType::Private;
    DBManager::getInstance()->saveChatRecord(m_currentUsername, record);
}

void MainWindow::clearInputFields()
{
    ui->UserNameEdit->clear();
    ui->UserPasswordEdit->clear();
    ui->UserNameEdit_2->clear();
    ui->UserPasswordEdit_2->clear();
    ui->AddressNameEdit->clear();
    ui->TelephonenumberEdit->clear();
    ui->sayLineEdit->clear();
    ui->sayLineEdit_2->clear();
}

void MainWindow::showPublicMessage(const MessageItem &item)
{
    const QString msg = QString("[%1] <b>%2</b>：%3")
                            .arg(item.timestamp)
                            .arg(item.sender)
                            .arg(item.content);
    ui->roomTextEdit->append(msg);
}

void MainWindow::showPrivateMessage(const MessageItem &item)
{
    const QString color = (item.sender == m_currentUsername) ? "#2a5caa" : "#008000";
    const QString msg = QString("[%1] <font color='%2'><b>%3</b></font>：%4")
                            .arg(item.timestamp)
                            .arg(color)
                            .arg(item.sender)
                            .arg(item.content);
    ui->privateTextEdit->append(msg);
}

void MainWindow::setWidgetEnabled(bool isEnabled, QWidget *widget)
{
    if (widget) {
        widget->setEnabled(isEnabled);
    }
}

void MainWindow::updateUserList(const QStringList &users)
{
    ui->userListWidget->clear();
    ui->userListWidget->addItems(users);
    ui->userListWidget_2->clear();
    ui->userListWidget_2->addItems(users);
}

// ========== 按钮点击槽函数 ==========
void MainWindow::on_loginButton_clicked()
{
    const QString serverAddr = ui->ServerEdit->text().trimmed();
    const QString username = ui->UserNameEdit->text().trimmed();
    const QString password = ui->UserPasswordEdit->text().trimmed();
    doLogin(serverAddr, username, password);
}

void MainWindow::on_registerButton_clicked()
{
    switchToRegisterPage();
}

void MainWindow::on_Register_clicked()
{
    const QString serverAddr = ui->ServerEdit_2->text().trimmed();
    const QString username = ui->UserNameEdit_2->text().trimmed();
    const QString password = ui->UserPasswordEdit_2->text().trimmed();
    const QString realName = ui->AddressNameEdit->text().trimmed();
    const QString phone = ui->TelephonenumberEdit->text().trimmed();
    doRegister(serverAddr, username, password, realName, phone);
}

void MainWindow::on_returnButton_clicked()
{
    switchToLoginPage();
}

void MainWindow::on_sayBtn_clicked()
{
    sendPublicMessage();
}

void MainWindow::on_logoutBtn_clicked()
{
    if (QMessageBox::question(this, "退出确认", "确定要退出登录吗？") == QMessageBox::Yes) {
        m_chatClient->disconnectFromServer();
        m_isLoggedIn = false;
        m_currentUsername.clear();
        m_currentPrivateTarget.clear();
        switchToLoginPage();
    }
}

void MainWindow::on_contacts_clicked()
{
    switchToContactsPage();
}

void MainWindow::on_sayBtn_2_clicked()
{
    sendPrivateMessage();
}

void MainWindow::on_logoutBtn_2_clicked()
{
    on_logoutBtn_clicked();
}

void MainWindow::on_contacts_2_clicked()
{
    switchToContactsPage();
}

void MainWindow::on_Return_clicked()
{
    switchToChatPage();
}

void MainWindow::on_AddGroup_clicked()
{
    bool ok;
    const QString groupName = QInputDialog::getText(this, "添加分组", "请输入分组名称：",
                                                    QLineEdit::Normal, "", &ok);
    if (ok && !groupName.isEmpty()) {
        if (DBManager::getInstance()->addContactGroup(groupName)) {
            ui->Grouping->addItem(groupName);
            QMessageBox::information(this, "成功", QString("分组 %1 添加成功！").arg(groupName));
        } else {
            QMessageBox::warning(this, "失败", QString("分组 %1 添加失败！").arg(groupName));
        }
    }
}

void MainWindow::on_Addcontact_clicked()
{
    QListWidgetItem *currentGroup = ui->Grouping->currentItem();
    if (!currentGroup) {
        QMessageBox::warning(this, "选择分组", "请先选择一个联系人分组！");
        return;
    }
    const QString groupName = currentGroup->text().trimmed();

    bool ok;
    const QString contactName = QInputDialog::getText(this, "添加联系人", "请输入联系人用户名：",
                                                      QLineEdit::Normal, "", &ok);
    if (ok && !contactName.isEmpty()) {
        if (DBManager::getInstance()->addContact(groupName, contactName)) {
            ui->userListWidget_4->addItem(contactName);
            QMessageBox::information(this, "成功", QString("联系人 %1 添加成功！").arg(contactName));
        } else {
            QMessageBox::warning(this, "失败", QString("联系人 %1 添加失败！").arg(contactName));
        }
    }
}

void MainWindow::on_userListWidget_itemDoubleClicked(QListWidgetItem *item)
{
    if (!item || !m_isLoggedIn) return;

    m_currentPrivateTarget = item->text().trimmed();
    switchToPrivateChatPage();

    const QList<MessageItem> history = DBManager::getInstance()->getChatRecords(
        m_currentUsername, ChatEnum::ChatType::Private, m_currentPrivateTarget
        );
    ui->privateTextEdit->clear();
    for (const MessageItem &item : history) {
        showPrivateMessage(item);
    }
}

void MainWindow::on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item)
{
    if (!item || !m_isLoggedIn) return;

    m_currentPrivateTarget = item->text().trimmed();

    const QList<MessageItem> history = DBManager::getInstance()->getChatRecords(
        m_currentUsername, ChatEnum::ChatType::Private, m_currentPrivateTarget
        );
    ui->privateTextEdit->clear();
    for (const MessageItem &item : history) {
        showPrivateMessage(item);
    }
}

void MainWindow::on_Grouping_itemClicked(QListWidgetItem *item)
{
    if (!item) return;

    const QString groupName = item->text().trimmed();
    QStringList contacts = DBManager::getInstance()->getContactsByGroup(groupName);
    ui->userListWidget_4->clear();
    ui->userListWidget_4->addItems(contacts);
}

// ========== 客户端信号处理 ==========
void MainWindow::onJsonMessageReceived(const QJsonObject &msg)
{
    const QString msgType = msg["type"].toString().trimmed();

    if (msgType == "public_chat") {
        MessageItem item;
        item.sender = msg["sender"].toString().trimmed();
        item.content = msg["content"].toString().trimmed();
        item.timestamp = msg["timestamp"].toString().trimmed();
        item.messageType = ChatEnum::MessageType::PublicChat;

        if (item.sender == m_currentUsername) return;

        showPublicMessage(item);

        ChatRecord record;
        record.sender = item.sender;
        record.receiver = "all";
        record.content = item.content;
        record.timestamp = item.timestamp;
        record.chatType = ChatEnum::ChatType::Public;
        DBManager::getInstance()->saveChatRecord(m_currentUsername, record);
    }

    if (msgType == "private_chat") {
        const QString sender = msg["sender"].toString().trimmed();
        const QString receiver = msg["receiver"].toString().trimmed();

        if (receiver != m_currentUsername) return;

        MessageItem item;
        item.sender = sender;
        item.content = msg["content"].toString().trimmed();
        item.timestamp = msg["timestamp"].toString().trimmed();
        item.messageType = ChatEnum::MessageType::PrivateChat;

        if (m_currentPrivateTarget.isEmpty()) {
            m_currentPrivateTarget = sender;
        }

        showPrivateMessage(item);

        ChatRecord record;
        record.sender = sender;
        record.receiver = receiver;
        record.content = item.content;
        record.timestamp = item.timestamp;
        record.chatType = ChatEnum::ChatType::Private;
        DBManager::getInstance()->saveChatRecord(m_currentUsername, record);
    }

    if (msgType == "user_list") {
        const QStringList users = msg["users"].toString().split(",", Qt::SkipEmptyParts);
        updateUserList(users);
    }
}

void MainWindow::onConnectionStatusChanged(bool isConnected)
{
    const QString status = isConnected ? "已连接到服务器" : "与服务器断开连接";
    this->setStatusTip(status);

    if (!isConnected && m_isLoggedIn) {
        QMessageBox::warning(this, "连接断开", "与服务器的连接已断开，请重新登录！");
        m_isLoggedIn = false;
        switchToLoginPage();
    }
}

void MainWindow::onClientErrorOccurred(const QString &errorMsg)
{
    qWarning() << "客户端错误：" << errorMsg;
    ui->roomTextEdit->append(QString("<font color='red'>[系统错误] %1</font>").arg(errorMsg));
}
