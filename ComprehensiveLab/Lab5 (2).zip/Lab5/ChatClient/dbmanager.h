#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QList>
#include <QStringList>
#include "messageitem.h"
#include "chatenum.h"

class DBManager {
public:
    static DBManager* getInstance();
    static void destroyInstance();
    bool initDB(const QString &dbPath = "chat_history.db");

    // 聊天记录操作（适配chat_records表）
    bool saveChatRecord(const QString &localUser, const ChatRecord &record);
    QList<MessageItem> getChatRecords(const QString &localUser,
                                      ChatEnum::ChatType chatType,
                                      const QString &target);

    // 用户操作（适配users表）
    bool addUser(const QString &username, const QString &password,
                 const QString &name, const QString &phone);
    bool validateUser(const QString &username, const QString &password);

    // 联系人分组操作（适配contact_groups表）
    bool addContactGroup(const QString &groupName);
    bool addContact(const QString &groupName, const QString &username);
    QStringList getContactGroups();
    QStringList getContactsByGroup(const QString &groupName);

private:
    DBManager() = default;
    ~DBManager() = default;
    DBManager(const DBManager&) = delete;
    DBManager& operator=(const DBManager&) = delete;

    static DBManager* m_instance;
    QSqlDatabase m_db;
};

#endif // DBMANAGER_H
