#ifndef CHATENUM_H
#define CHATENUM_H

namespace ChatEnum {
enum class ChatType {
    Public,    // 群聊
    Private    // 私聊
};

enum class MessageType {
    PublicChat,  // 群聊消息
    PrivateChat, // 私聊消息
    Login,       // 登录消息
    UserList     // 用户列表消息
};
}

#endif // CHATENUM_H
