#ifndef MESSAGEITEM_H
#define MESSAGEITEM_H

#include <QString>
#include <QDateTime>
#include "chatenum.h"

struct MessageItem {
    QString sender;
    QString content;
    QString timestamp;
    ChatEnum::MessageType messageType;
};

struct ChatRecord {
    QString sender;
    QString receiver;
    QString content;
    QString timestamp;
    ChatEnum::ChatType chatType;
};

// 获取当前时间字符串（工具函数）
inline QString getCurrentTimeString() {
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
}

#endif // MESSAGEITEM_H
