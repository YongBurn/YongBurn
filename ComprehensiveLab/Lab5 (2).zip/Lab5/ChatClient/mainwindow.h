#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QScopedPointer>
#include <QString>
#include <QListWidgetItem>
#include <QInputDialog>
#include <QRegularExpression>
#include "chatclient.h"
#include "messageitem.h"
#include "chatenum.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    void on_loginButton_clicked();
    void on_registerButton_clicked();
    void on_Register_clicked();
    void on_returnButton_clicked();
    void on_sayBtn_clicked();
    void on_logoutBtn_clicked();
    void on_contacts_clicked();
    void on_sayBtn_2_clicked();
    void on_logoutBtn_2_clicked();
    void on_contacts_2_clicked();
    void on_Return_clicked();
    void on_AddGroup_clicked();
    void on_Addcontact_clicked();
    void on_userListWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item);
    void on_Grouping_itemClicked(QListWidgetItem *item);

    void onJsonMessageReceived(const QJsonObject &msg);
    void onConnectionStatusChanged(bool isConnected);
    void onClientErrorOccurred(const QString &errorMsg);

private:
    void initUI();
    void initConnections();
    void initPageIndex();

    void switchToLoginPage();
    void switchToRegisterPage();
    void switchToChatPage();
    void switchToPrivateChatPage();
    void switchToContactsPage();

    bool doLogin(const QString &serverAddr, const QString &username, const QString &password);
    bool doRegister(const QString &serverAddr, const QString &username, const QString &password,
                    const QString &realName, const QString &phone);
    void sendPublicMessage();
    void sendPrivateMessage();
    void updateUserList(const QStringList &users);
    void clearInputFields();

    void showPublicMessage(const MessageItem &item);
    void showPrivateMessage(const MessageItem &item);
    void setWidgetEnabled(bool isEnabled, QWidget *widget);

    Ui::MainWindow *ui;
    QScopedPointer<ChatClient> m_chatClient;

    int PAGE_CHAT = 0;
    int PAGE_PRIVATE_CHAT = 1;
    int PAGE_CONTACTS = 2;
    int PAGE_LOGIN = 3;
    int PAGE_REGISTER = 4;

    QString m_currentUsername;
    QString m_currentPrivateTarget;
    QString m_currentServerAddr;
    bool m_isLoggedIn = false;
};

#endif // MAINWINDOW_H
