#include "dbmanager.h"
#include <QDir>
#include <QFileInfo>
#include <QDebug>
#include <QSqlError>
#include <QDateTime>

DBManager* DBManager::m_instance = nullptr;

DBManager* DBManager::getInstance()
{
    if (!m_instance) {
        m_instance = new DBManager();
    }
    return m_instance;
}

void DBManager::destroyInstance()
{
    if (m_instance) {
        delete m_instance;
        m_instance = nullptr;
    }
}

bool DBManager::initDB(const QString &dbPath)
{
    // 固定数据库路径（转义反斜杠）
    QString fixedDbPath = "D:\\qt\\task\\Lab5\\Lab5\\Lab4a\\Lab4a.db";

    // 确保目录存在
    QFileInfo dbFileInfo(fixedDbPath);
    QDir dbDir = dbFileInfo.absoluteDir();
    if (!dbDir.exists()) {
        bool dirCreated = dbDir.mkpath(".");
        if (!dirCreated) {
            qCritical() << "数据库目录创建失败：" << dbDir.absolutePath();
            return false;
        }
    }

    // 连接数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE", "chat_db");
    m_db.setDatabaseName(fixedDbPath);

    if (!m_db.open()) {
        qCritical() << "数据库打开失败：" << m_db.lastError().text() << "，路径：" << fixedDbPath;
        return false;
    }

    // 创建users表
    QSqlQuery userQuery(m_db);
    const QString userTableSql = R"(
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            phone TEXT NOT NULL,
            create_time TEXT NOT NULL
        )
    )";
    if (!userQuery.exec(userTableSql)) {
        qCritical() << "创建users表失败：" << userQuery.lastError().text();
    }

    // 创建chat_records表
    QSqlQuery chatQuery(m_db);
    const QString chatTableSql = R"(
        CREATE TABLE IF NOT EXISTS chat_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_type INTEGER NOT NULL,
            sender TEXT NOT NULL,
            receiver TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            local_user TEXT NOT NULL
        )
    )";
    if (!chatQuery.exec(chatTableSql)) {
        qCritical() << "创建chat_records表失败：" << chatQuery.lastError().text();
    }

    // 创建contact_groups表
    QSqlQuery groupQuery(m_db);
    const QString groupTableSql = R"(
        CREATE TABLE IF NOT EXISTS contact_groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT NOT NULL,
            username TEXT NOT NULL
        )
    )";
    if (!groupQuery.exec(groupTableSql)) {
        qCritical() << "创建contact_groups表失败：" << groupQuery.lastError().text();
    }

    qInfo() << "数据库初始化成功，路径：" << fixedDbPath;
    return true;
}

// 以下原有函数保持不变（saveChatRecord/getChatRecords/addUser/validateUser等）
bool DBManager::saveChatRecord(const QString &localUser, const ChatRecord &record)
{
    if (!m_db.isOpen()) {
        if (!initDB()) return false;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT INTO chat_records (chat_type, sender, receiver, content, timestamp, local_user)
        VALUES (:chat_type, :sender, :receiver, :content, :timestamp, :local_user)
    )");

    query.bindValue(":chat_type", static_cast<int>(record.chatType));
    query.bindValue(":sender", record.sender);
    query.bindValue(":receiver", record.receiver);
    query.bindValue(":content", record.content);
    query.bindValue(":timestamp", record.timestamp);
    query.bindValue(":local_user", localUser);

    if (!query.exec()) {
        qCritical() << "保存聊天记录失败：" << query.lastError().text();
        return false;
    }
    return true;
}

QList<MessageItem> DBManager::getChatRecords(const QString &localUser,
                                             ChatEnum::ChatType chatType,
                                             const QString &target)
{
    QList<MessageItem> records;
    if (!m_db.isOpen()) {
        if (!initDB()) return records;
    }

    QSqlQuery query(m_db);
    QString sql = R"(
        SELECT sender, content, timestamp FROM chat_records
        WHERE local_user = :local_user AND chat_type = :chat_type
    )";

    if (chatType == ChatEnum::ChatType::Public) {
        sql += " AND receiver = 'all'";
    } else {
        sql += " AND (sender = :target OR receiver = :target)";
    }
    sql += " ORDER BY timestamp ASC";

    query.prepare(sql);
    query.bindValue(":local_user", localUser);
    query.bindValue(":chat_type", static_cast<int>(chatType));
    if (chatType == ChatEnum::ChatType::Private) {
        query.bindValue(":target", target);
    }

    if (!query.exec()) {
        qCritical() << "查询聊天记录失败：" << query.lastError().text();
        return records;
    }

    while (query.next()) {
        MessageItem item;
        item.sender = query.value(0).toString();
        item.content = query.value(1).toString();
        item.timestamp = query.value(2).toString();
        item.messageType = (chatType == ChatEnum::ChatType::Public)
                               ? ChatEnum::MessageType::PublicChat
                               : ChatEnum::MessageType::PrivateChat;
        records.append(item);
    }
    return records;
}

bool DBManager::addUser(const QString &username, const QString &password,
                        const QString &name, const QString &phone)
{
    if (!m_db.isOpen()) {
        if (!initDB()) return false;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT INTO users (username, password, name, phone, create_time)
        VALUES (:username, :password, :name, :phone, :create_time)
    )");

    query.bindValue(":username", username);
    query.bindValue(":password", password);
    query.bindValue(":name", name);
    query.bindValue(":phone", phone);
    query.bindValue(":create_time", QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));

    if (!query.exec()) {
        qCritical() << "注册用户失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBManager::validateUser(const QString &username, const QString &password)
{
    if (!m_db.isOpen()) {
        if (!initDB()) return false;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        SELECT COUNT(*) FROM users
        WHERE username = :username AND password = :password
    )");

    query.bindValue(":username", username);
    query.bindValue(":password", password);

    if (!query.exec() || !query.next()) {
        qCritical() << "验证用户失败：" << query.lastError().text();
        return false;
    }
    return query.value(0).toInt() > 0;
}

bool DBManager::addContactGroup(const QString &groupName)
{
    if (!m_db.isOpen()) {
        if (!initDB()) return false;
    }

    QSqlQuery checkQuery(m_db);
    checkQuery.prepare("SELECT COUNT(*) FROM contact_groups WHERE group_name = :group_name");
    checkQuery.bindValue(":group_name", groupName);
    if (checkQuery.exec() && checkQuery.next() && checkQuery.value(0).toInt() > 0) {
        return true;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT INTO contact_groups (group_name, username)
        VALUES (:group_name, :username)
    )");
    query.bindValue(":group_name", groupName);
    query.bindValue(":username", groupName);

    if (!query.exec()) {
        qCritical() << "添加分组失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBManager::addContact(const QString &groupName, const QString &username)
{
    if (!m_db.isOpen()) {
        if (!initDB()) return false;
    }

    QSqlQuery checkQuery(m_db);
    checkQuery.prepare("SELECT COUNT(*) FROM contact_groups WHERE group_name = :group_name AND username = :username");
    checkQuery.bindValue(":group_name", groupName);
    checkQuery.bindValue(":username", username);
    if (checkQuery.exec() && checkQuery.next() && checkQuery.value(0).toInt() > 0) {
        return true;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT INTO contact_groups (group_name, username)
        VALUES (:group_name, :username)
    )");
    query.bindValue(":group_name", groupName);
    query.bindValue(":username", username);

    if (!query.exec()) {
        qCritical() << "添加联系人失败：" << query.lastError().text();
        return false;
    }
    return true;
}

QStringList DBManager::getContactGroups()
{
    QStringList groups;
    if (!m_db.isOpen()) {
        if (!initDB()) return groups;
    }

    QSqlQuery query(m_db);
    if (!query.exec("SELECT DISTINCT group_name FROM contact_groups ORDER BY group_name ASC")) {
        qCritical() << "查询分组失败：" << query.lastError().text();
        return groups;
    }

    while (query.next()) {
        groups.append(query.value(0).toString());
    }
    return groups;
}

QStringList DBManager::getContactsByGroup(const QString &groupName)
{
    QStringList contacts;
    if (!m_db.isOpen()) {
        if (!initDB()) return contacts;
    }

    QSqlQuery query(m_db);
    query.prepare("SELECT username FROM contact_groups WHERE group_name = :group_name AND username != group_name ORDER BY username ASC");
    query.bindValue(":group_name", groupName);

    if (!query.exec()) {
        qCritical() << "查询联系人失败：" << query.lastError().text();
        return contacts;
    }

    while (query.next()) {
        contacts.append(query.value(0).toString());
    }
    return contacts;
}
