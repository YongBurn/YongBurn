#include "chatclient.h"
#include <QDebug>
#include <QThread>

ChatClient::ChatClient(QObject *parent)
    : QObject(parent)
{
    m_socket = new QTcpSocket(this);
    // 绑定信号槽
    connect(m_socket, &QTcpSocket::connected, this, &ChatClient::onConnected);
    connect(m_socket, &QTcpSocket::disconnected, this, &ChatClient::onDisconnected);
    connect(m_socket, &QTcpSocket::readyRead, this, &ChatClient::onReadyRead);
    connect(m_socket, QOverload<QAbstractSocket::SocketError>::of(&QTcpSocket::errorOccurred),
            this, &ChatClient::onSocketError);
}

ChatClient::~ChatClient()
{
    disconnectFromServer();
}

// 修正：支持重试次数+错误信息输出（匹配mainwindow调用）
bool ChatClient::connectToServer(const QString &host, quint16 port,
                                 int timeout, int retryCount,
                                 QString *errorMsg)
{
    if (isConnected()) {
        if (errorMsg) *errorMsg = "已连接到服务器，无需重复连接";
        emit errorOccurred(*errorMsg);
        return true;
    }

    int retry = 0;
    while (retry < retryCount) {
        m_socket->connectToHost(host, port);
        if (m_socket->waitForConnected(timeout)) {
            if (errorMsg) *errorMsg = "连接服务器成功";
            return true;
        }

        retry++;
        QString err = QString("第%1次连接失败：%2").arg(retry).arg(m_socket->errorString());
        if (errorMsg) *errorMsg = err;
        QThread::msleep(500); // 重试前等待500ms
    }

    if (errorMsg) *errorMsg = QString("重试%1次后仍连接失败：%2")
                        .arg(retryCount).arg(m_socket->errorString());
    return false;
}

void ChatClient::disconnectFromServer()
{
    if (isConnected()) {
        m_socket->disconnectFromHost();
    }
}

// 新增：发送登录消息
bool ChatClient::sendLoginMessage(const QString &username)
{
    if (!isConnected()) {
        emit errorOccurred("未连接到服务器，无法发送登录消息");
        return false;
    }

    QJsonObject json;
    json["type"] = "login";          // 登录消息类型
    json["username"] = username;     // 登录用户名
    json["timestamp"] = getCurrentTimeString();

    return sendJsonMessage(json);
}

// 新增：发送私聊消息
bool ChatClient::sendPrivateChat(const QString &sender, const QString &receiver, const QString &content)
{
    if (!isConnected()) {
        emit errorOccurred("未连接到服务器，无法发送私聊消息");
        return false;
    }

    QJsonObject json;
    json["type"] = "private_chat";   // 私聊消息类型
    json["sender"] = sender;         // 发送者
    json["receiver"] = receiver;     // 接收者
    json["content"] = content;       // 消息内容
    json["timestamp"] = getCurrentTimeString();

    return sendJsonMessage(json);
}

// 原有：发送群聊消息
bool ChatClient::sendPublicChat(const QString &sender, const QString &content)
{
    if (!isConnected()) {
        emit errorOccurred("未连接到服务器，无法发送群聊消息");
        return false;
    }

    QJsonObject json;
    json["type"] = "public_chat";    // 群聊消息类型（严格匹配服务器）
    json["sender"] = sender;
    json["content"] = content;
    json["timestamp"] = getCurrentTimeString();

    return sendJsonMessage(json);
}

// 通用：发送JSON消息（内部复用）
bool ChatClient::sendJsonMessage(const QJsonObject &json)
{
    QJsonDocument doc(json);
    QByteArray data = doc.toJson(QJsonDocument::Compact); // 紧凑格式，无多余字符

    // 校验JSON合法性
    QJsonParseError error;
    QJsonDocument::fromJson(data, &error);
    if (error.error != QJsonParseError::NoError) {
        QString err = "JSON生成错误：" + error.errorString();
        emit errorOccurred(err);
        return false;
    }

    // 添加唯一分隔符（\x00），避免拆包/粘包
    data += '\x00';
    qint64 bytes = m_socket->write(data);
    m_socket->flush();

    bool success = (bytes == data.size());
    if (!success) {
        emit errorOccurred("消息发送失败，字节数不匹配");
    }
    return success;
}

void ChatClient::onConnected()
{
    emit connected();
    emit connectionStatusChanged(true); // 发送连接状态变化信号
    emit errorOccurred("成功连接到服务器");
}

void ChatClient::onDisconnected()
{
    emit disconnected();
    emit connectionStatusChanged(false); // 发送连接状态变化信号
    emit errorOccurred("与服务器断开连接");
}

void ChatClient::onReadyRead()
{
    QByteArray newData = m_socket->readAll();
    m_recvBuffer.append(newData);

    // 按分隔符(\x00)提取完整JSON
    int delimiterPos = -1;
    while ((delimiterPos = m_recvBuffer.indexOf('\x00')) != -1) {
        QByteArray jsonData = m_recvBuffer.left(delimiterPos);
        m_recvBuffer.remove(0, delimiterPos + 1);

        if (jsonData.isEmpty()) continue;

        // 解析JSON
        QJsonParseError jsonError;
        QJsonDocument doc = QJsonDocument::fromJson(jsonData, &jsonError);
        if (jsonError.error != QJsonParseError::NoError) {
            QString err = QString("JSON解析错误：%1，原始数据：%2")
                              .arg(jsonError.errorString()).arg(QString(jsonData));
            emit errorOccurred(err);
            continue;
        }

        if (doc.isObject()) {
            emit jsonMessageReceived(doc.object());
        } else {
            emit errorOccurred("收到非JSON对象数据：" + QString(jsonData));
        }
    }
}

void ChatClient::onSocketError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError)
    QString err = "Socket错误：" + m_socket->errorString();
    emit errorOccurred(err);
}
