#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDateTime>
#include <QScrollBar>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_chatServer(new ChatServer(this))
{
    ui->setupUi(this);

    // 初始化UI
    ui->logEditer->setReadOnly(true);
    ui->startStopButton->setText("启动服务器");

    // 绑定服务器信号
    connect(m_chatServer, &ChatServer::serverStarted, this, &MainWindow::onServerStarted);
    connect(m_chatServer, &ChatServer::serverStopped, this, &MainWindow::onServerStopped);
    connect(m_chatServer, &ChatServer::clientConnected, this, &MainWindow::onClientConnected);
    connect(m_chatServer, &ChatServer::clientDisconnected, this, &MainWindow::onClientDisconnected);
    connect(m_chatServer, &ChatServer::messageReceived, this, &MainWindow::onMessageReceived);
    connect(m_chatServer, &ChatServer::errorOccurred, this, &MainWindow::onErrorOccurred);

    log("服务器初始化完成");
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 启动/停止服务器按钮
void MainWindow::on_startStopButton_clicked()
{
    if (m_chatServer->isRunning()) {
        // 停止服务器
        m_chatServer->stop();
    } else {
        // 启动服务器（端口1967）
        if (m_chatServer->start(1967)) {
            log("服务器启动成功，监听端口：1967");
        } else {
            log("服务器启动失败");
        }
    }
}

// 服务器启动成功
void MainWindow::onServerStarted()
{
    ui->startStopButton->setText("停止服务器");
    log("服务器已启动");
}

// 服务器停止
void MainWindow::onServerStopped()
{
    ui->startStopButton->setText("启动服务器");
    log("服务器已停止");
}

// 客户端连接
void MainWindow::onClientConnected(const QString &ip, quint16 port)
{
    log(QString("客户端连接：%1:%2").arg(ip).arg(port));
}

// 客户端断开
void MainWindow::onClientDisconnected(const QString &ip, quint16 port)
{
    log(QString("客户端断开：%1:%2").arg(ip).arg(port));
}

// 收到消息
void MainWindow::onMessageReceived(const QString &sender, const QString &receiver, const QString &msg)
{
    if (receiver == "all") {
        log(QString("[公聊] %1 -> 所有人：%2").arg(sender).arg(msg));
    } else {
        log(QString("[私聊] %1 -> %2：%3").arg(sender).arg(receiver).arg(msg));
    }
}

// 错误发生
void MainWindow::onErrorOccurred(const QString &error)
{
    log(QString("[错误] %1").arg(error));
}

// 日志输出
void MainWindow::log(const QString &msg)
{
    QString time = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    ui->logEditer->appendPlainText(QString("[%1] %2").arg(time).arg(msg));

    // 滚动到日志底部
    QScrollBar *scrollBar = ui->logEditer->verticalScrollBar();
    if (scrollBar) {
        scrollBar->setValue(scrollBar->maximum());
    }
}
