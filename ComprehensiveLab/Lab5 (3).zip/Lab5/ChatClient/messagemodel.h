#ifndef MESSAGEMODEL_H
#define MESSAGEMODEL_H

#include <QAbstractListModel>
#include <QList>
#include <QString>
#include "common.h"

// 消息数据结构
struct MessageItem {
    QString sender;
    QString receiver;
    QString content;
    QString timestamp;
    MessageType type;
    bool isSelf; // 是否是自己发送的
};

class MessageModel : public QAbstractListModel
{
    Q_OBJECT
public:
    enum MessageRoles {
        SenderRole = Qt::UserRole + 1,
        ReceiverRole,
        ContentRole,
        TimestampRole,
        TypeRole,
        IsSelfRole
    };

    explicit MessageModel(QObject *parent = nullptr);

    // 重写Model接口
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    // 自定义接口
    void addMessage(const MessageItem &item);
    void clearMessages();
    const QList<MessageItem>& getMessages() const;
    void loadHistoryMessages(const QList<MessageItem> &history);

private:
    QList<MessageItem> m_messages;
};

#endif // MESSAGEMODEL_H
