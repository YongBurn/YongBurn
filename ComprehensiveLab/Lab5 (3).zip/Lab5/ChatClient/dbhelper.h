#ifndef DBHELPER_H
#define DBHELPER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QString>

// 地址数据结构
struct AddressData {
    int id;             // 主键ID
    QString username;   // 关联用户名
    QString address;    // 地址内容
    QString phone;      // 联系电话
};

class DBHelper : public QObject
{
    Q_OBJECT
public:
    explicit DBHelper(QObject *parent = nullptr);
    ~DBHelper() override;

    // 初始化数据库（检查表结构，不存在则创建）
    bool initDB();

    // 地址数据操作
    bool addAddress(const AddressData &addr);       // 添加地址
    bool updateAddress(const AddressData &addr);    // 更新地址
    bool deleteAddress(int id);                     // 删除地址
    AddressData getAddressByUsername(const QString &username); // 根据用户名查地址
    QList<AddressData> getAllAddresses();           // 获取所有地址

private:
    QSqlDatabase m_db;  // SQLite数据库对象
};

#endif // DBHELPER_H
