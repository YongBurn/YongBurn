#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QJsonDocument>
#include <QTimer>
#include <QListWidgetItem>
#include <QScrollBar>
#include <QInputDialog>
#include <QMessageBox>
#include <QDateTime>
#include <QDebug>
#include "dbhelper.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // 登录页按钮槽函数
    void on_loginButton_clicked();          // 登录按钮
    void on_registerButton_clicked();       // 切换到注册页

    // 注册页按钮槽函数
    void on_returnButton_clicked();         // 注册页返回登录页
    void on_Register_clicked();             // 提交注册

    // 群聊页按钮槽函数
    void on_sayBtn_clicked();               // 群聊发送
    void on_logoutBtn_clicked();            // 退出登录
    void on_contacts_clicked();             // 打开联系人页

    // 私聊页按钮槽函数
    void on_sayBtn_2_clicked();             // 私聊发送
    void on_logoutBtn_2_clicked();          // 私聊页退出
    void on_contacts_2_clicked();           // 私聊页打开联系人

    // 联系人页按钮槽函数
    void on_Return_clicked();               // 联系人页返回群聊页
    void on_AddGroup_clicked();             // 添加分组
    void on_Addcontact_clicked();           // 添加联系人

    // 列表双击事件（触发私聊）
    void on_userListWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item);

    // 网络相关槽函数
    void onConnected();                     // 连接服务器成功
    void onDisconnected();                  // 断开连接
    void onReadyRead();                     // 接收服务器数据
    void onSocketError(QAbstractSocket::SocketError error); // 网络错误
    void sendHeartbeat();                   // 发送心跳包

    // 新增：展示当前用户地址
    void showUserAddress();

private:
    // 核心工具函数
    void connectToServer(const QString &serverIp); // 连接服务器
    void sendJsonToServer(const QJsonObject &json); // 发送JSON数据
    void handleServerResponse(const QJsonObject &response); // 处理服务器响应
    void updateOnlineUserList(const QJsonArray &userArray); // 更新在线用户列表
    void switchToPage(int index);           // 切换StackedWidget页面
    void clearChatInput();                  // 清空聊天输入框
    void logout();                          // 退出登录

    Ui::MainWindow *ui;                     // UI对象
    QTcpSocket *m_tcpSocket;                // TCP套接字
    QTimer *m_heartbeatTimer;               // 心跳定时器
    QString m_currentUsername;              // 当前登录用户名
    QString m_privateChatTarget;            // 私聊目标用户名
    bool m_isConnected;                     // 是否连接服务器
    DBHelper *m_dbHelper;                   // 数据库操作工具类
};

#endif // MAINWINDOW_H
