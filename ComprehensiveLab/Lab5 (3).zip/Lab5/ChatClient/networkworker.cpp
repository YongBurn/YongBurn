#include "networkworker.h"
#include <QHostAddress>
#include <QThread>
#include <QDebug>

NetworkWorker::NetworkWorker(QObject *parent) : QObject(parent)
    , m_socket(nullptr)
    , m_reconnectTimer(nullptr)
    , m_serverPort(0)
    , m_reconnectAttempts(0)
    , m_maxReconnectAttempts(10)
    , m_autoReconnect(false)
    , m_manualDisconnect(false)
{
    setupSocket();

    m_reconnectTimer = new QTimer(this);
    m_reconnectTimer->setSingleShot(true);
    connect(m_reconnectTimer, &QTimer::timeout, this, &NetworkWorker::onReconnectTimeout);
}

NetworkWorker::~NetworkWorker()
{
    stopReconnectTimer();
    cleanupSocket();
}

void NetworkWorker::setupSocket()
{
    QMutexLocker locker(&m_socketMutex);

    if (m_socket) {
        cleanupSocket();
    }

    m_socket = new QTcpSocket(this);

    connect(m_socket, &QTcpSocket::connected, this, &NetworkWorker::onConnected);
    connect(m_socket, &QTcpSocket::disconnected, this, &NetworkWorker::onDisconnected);
    connect(m_socket, &QTcpSocket::readyRead, this, &NetworkWorker::onReadyRead);
    connect(m_socket, &QTcpSocket::errorOccurred, this, &NetworkWorker::onErrorOccurred);
}

void NetworkWorker::cleanupSocket()
{
    if (m_socket) {
        m_socket->disconnect();
        m_socket->deleteLater();
        m_socket = nullptr;
    }
}

bool NetworkWorker::isConnected() const
{
    QMutexLocker locker(&m_socketMutex);
    return m_socket && m_socket->state() == QAbstractSocket::ConnectedState;
}

QString NetworkWorker::lastError() const
{
    return m_lastError;
}

void NetworkWorker::connectToServer(const QString &address, quint16 port)
{
    QMutexLocker locker(&m_socketMutex);

    m_serverAddress = address;
    m_serverPort = port;
    m_manualDisconnect = false;
    m_reconnectAttempts = 0;

    if (m_socket->state() != QAbstractSocket::UnconnectedState) {
        m_socket->abort();
    }

    m_socket->connectToHost(address, port);
}

void NetworkWorker::sendData(const QByteArray &data)
{
    QMutexLocker locker(&m_socketMutex);

    if (m_socket && m_socket->state() == QAbstractSocket::ConnectedState) {
        m_socket->write(data);
    } else {
        emit errorOccurred("Socket is not connected");
    }
}

void NetworkWorker::disconnectFromHost()
{
    QMutexLocker locker(&m_socketMutex);

    m_manualDisconnect = true;
    stopReconnectTimer();

    if (m_socket && m_socket->state() != QAbstractSocket::UnconnectedState) {
        m_socket->disconnectFromHost();
    }
}

void NetworkWorker::setAutoReconnect(bool enabled, int interval, int maxAttempts)
{
    m_autoReconnect = enabled;
    m_maxReconnectAttempts = maxAttempts;

    if (m_reconnectTimer) {
        m_reconnectTimer->setInterval(interval);
    }
}

void NetworkWorker::onConnected()
{
    m_reconnectAttempts = 0;
    stopReconnectTimer();
    emit connected();
    emit connectionStatusChanged(true);
}

void NetworkWorker::onDisconnected()
{
    emit disconnected();
    emit connectionStatusChanged(false);

    if (m_autoReconnect && !m_manualDisconnect && m_reconnectAttempts < m_maxReconnectAttempts) {
        startReconnectTimer();
    } else if (!m_manualDisconnect && m_reconnectAttempts >= m_maxReconnectAttempts) {
        emit reconnectFailed();
    }
}

void NetworkWorker::onReadyRead()
{
    QMutexLocker locker(&m_socketMutex);

    if (m_socket) {
        QByteArray data = m_socket->readAll();
        if (!data.isEmpty()) {
            emit dataReceived(data);
        }
    }
}

void NetworkWorker::onErrorOccurred(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError)

    QMutexLocker locker(&m_socketMutex);

    if (m_socket) {
        m_lastError = m_socket->errorString();
        emit errorOccurred(m_lastError);
    }
}

void NetworkWorker::onReconnectTimeout()
{
    if (!m_manualDisconnect && m_reconnectAttempts < m_maxReconnectAttempts) {
        m_reconnectAttempts++;
        emit reconnectAttempt(m_reconnectAttempts, m_maxReconnectAttempts);

        QMutexLocker locker(&m_socketMutex);
        if (m_socket) {
            m_socket->connectToHost(m_serverAddress, m_serverPort);
        }
    }
}

void NetworkWorker::startReconnectTimer()
{
    if (m_reconnectTimer && !m_reconnectTimer->isActive()) {
        m_reconnectTimer->start();
    }
}

void NetworkWorker::stopReconnectTimer()
{
    if (m_reconnectTimer && m_reconnectTimer->isActive()) {
        m_reconnectTimer->stop();
    }
}
