#include "chatdatabase.h"
#include <QStandardPaths>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QCryptographicHash>
#include <QDateTime>
#include <QRandomGenerator>
#include <QSqlDriver>
#include <QSqlRecord>
#include <QDebug>

ChatDatabase::ChatDatabase(QObject *parent) : QObject(parent)
    , m_currentUser("")
    , m_databasePath("")
{
}

ChatDatabase::~ChatDatabase()
{
    closeDatabase();
}

bool ChatDatabase::openDatabase(const QString &userName, const QString &password)
{
    if (m_db.isOpen()) {
        closeDatabase();
    }

    m_currentUser = userName;

    // 创建应用数据目录
    QString dataDir = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir dir(dataDir);
    if (!dir.exists()) {
        if (!dir.mkpath(dataDir)) {
            emit databaseError("无法创建数据目录: " + dataDir);
            return false;
        }
    }

    // 创建数据库文件路径
    m_databasePath = dataDir + "/" + userName + ".db";

    // 打开数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE", userName);
    m_db.setDatabaseName(m_databasePath);

    // 设置数据库连接参数
    m_db.setConnectOptions("QSQLITE_ENABLE_REGEXP;QSQLITE_ENABLE_FTS3;QSQLITE_ENABLE_FTS4");

    if (!m_db.open()) {
        emit databaseError("无法打开数据库: " + m_db.lastError().text());
        return false;
    }

    // 设置外键约束
    QSqlQuery query(m_db);
    if (!query.exec("PRAGMA foreign_keys = ON")) {
        qWarning() << "无法启用外键约束:" << query.lastError();
    }

    // 设置WAL模式以提高并发性能
    if (!query.exec("PRAGMA journal_mode = WAL")) {
        qWarning() << "无法设置WAL模式:" << query.lastError();
    }

    // 设置同步模式
    if (!query.exec("PRAGMA synchronous = NORMAL")) {
        qWarning() << "无法设置同步模式:" << query.lastError();
    }

    // 设置缓存大小
    if (!query.exec("PRAGMA cache_size = 2000")) {
        qWarning() << "无法设置缓存大小:" << query.lastError();
    }

    // 创建表结构
    if (!createTables()) {
        emit databaseError("创建表失败");
        return false;
    }

    // 创建索引
    if (!createIndexes()) {
        emit databaseError("创建索引失败");
        return false;
    }

    // 创建触发器
    if (!createTriggers()) {
        emit databaseError("创建触发器失败");
        return false;
    }

    // 初始化数据
    if (!initData()) {
        emit databaseError("初始化数据失败");
        return false;
    }

    emit databaseOpened(true);
    return true;
}

void ChatDatabase::closeDatabase()
{
    if (m_db.isOpen()) {
        // 执行数据库维护
        compactDatabase();
        m_db.close();
    }

    m_currentUser.clear();
    m_databasePath.clear();
}

bool ChatDatabase::isOpen() const
{
    return m_db.isOpen();
}

bool ChatDatabase::createTables()
{
    if (!m_db.isOpen()) {
        return false;
    }

    QSqlQuery query(m_db);

    // 用户表
    QString userTableSql = R"(
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            nickname TEXT,
            phone TEXT,
            email TEXT,
            avatar TEXT,
            gender TEXT DEFAULT 'unknown',
            birthday TEXT,
            signature TEXT,
            salt TEXT NOT NULL,
            created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP,
            status TEXT DEFAULT 'offline',
            is_online BOOLEAN DEFAULT 0,
            is_deleted BOOLEAN DEFAULT 0
        )
    )";

    if (!query.exec(userTableSql)) {
        qWarning() << "创建users表失败:" << query.lastError();
        return false;
    }

    // 联系人表
    QString contactTableSql = R"(
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            contact_name TEXT NOT NULL,
            nickname TEXT,
            remark TEXT,
            contact_group TEXT DEFAULT '默认分组',
            status TEXT DEFAULT 'offline',
            is_online BOOLEAN DEFAULT 0,
            last_seen TIMESTAMP,
            avatar TEXT,
            created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(username, contact_name)
        )
    )";

    if (!query.exec(contactTableSql)) {
        qWarning() << "创建contacts表失败:" << query.lastError();
        return false;
    }

    // 消息表
    QString messageTableSql = R"(
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender TEXT NOT NULL,
            receiver TEXT NOT NULL,
            msg_type TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_read BOOLEAN DEFAULT 0,
            sync_status INTEGER DEFAULT 0,
            extra_data TEXT,
            INDEX idx_sender_receiver (sender, receiver),
            INDEX idx_timestamp (timestamp),
            INDEX idx_is_read (is_read)
        )
    )";

    if (!query.exec(messageTableSql)) {
        qWarning() << "创建messages表失败:" << query.lastError();
        return false;
    }

    // 群组表
    QString groupTableSql = R"(
        CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT UNIQUE NOT NULL,
            owner TEXT NOT NULL,
            description TEXT,
            avatar TEXT,
            max_members INTEGER DEFAULT 500,
            created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1
        )
    )";

    if (!query.exec(groupTableSql)) {
        qWarning() << "创建groups表失败:" << query.lastError();
        return false;
    }

    // 群组成员表
    QString groupMemberTableSql = R"(
        CREATE TABLE IF NOT EXISTS group_members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT NOT NULL,
            username TEXT NOT NULL,
            role TEXT DEFAULT 'member',
            join_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_active TIMESTAMP,
            UNIQUE(group_name, username)
        )
    )";

    if (!query.exec(groupMemberTableSql)) {
        qWarning() << "创建group_members表失败:" << query.lastError();
        return false;
    }

    // 系统配置表
    QString configTableSql = R"(
        CREATE TABLE IF NOT EXISTS system_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            config_key TEXT UNIQUE NOT NULL,
            config_value TEXT,
            description TEXT,
            updated_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    )";

    if (!query.exec(configTableSql)) {
        qWarning() << "创建system_config表失败:" << query.lastError();
        return false;
    }

    return true;
}

bool ChatDatabase::createIndexes()
{
    QSqlQuery query(m_db);

    // 为messages表创建更多索引以提高查询性能
    QStringList indexQueries = {
        "CREATE INDEX IF NOT EXISTS idx_messages_sender_timestamp ON messages (sender, timestamp)",
        "CREATE INDEX IF NOT EXISTS idx_messages_receiver_timestamp ON messages (receiver, timestamp)",
        "CREATE INDEX IF NOT EXISTS idx_messages_type ON messages (msg_type)",
        "CREATE INDEX IF NOT EXISTS idx_contacts_group ON contacts (username, contact_group)",
        "CREATE INDEX IF NOT EXISTS idx_contacts_status ON contacts (username, is_online)",
        "CREATE INDEX IF NOT EXISTS idx_groups_owner ON groups (owner)",
        "CREATE INDEX IF NOT EXISTS idx_group_members_user ON group_members (username)",
        "CREATE INDEX IF NOT EXISTS idx_users_status ON users (status, is_online)"
    };

    for (const QString &sql : indexQueries) {
        if (!query.exec(sql)) {
            qWarning() << "创建索引失败:" << query.lastError();
            return false;
        }
    }

    return true;
}

bool ChatDatabase::createTriggers()
{
    QSqlQuery query(m_db);

    // 触发器：当用户表更新时，自动更新联系人表中的相关信息
    QString triggerSql = R"(
        CREATE TRIGGER IF NOT EXISTS update_contact_from_user
        AFTER UPDATE ON users
        FOR EACH ROW
        BEGIN
            UPDATE contacts
            SET nickname = NEW.nickname,
                avatar = NEW.avatar,
                status = NEW.status,
                is_online = NEW.is_online
            WHERE contact_name = NEW.username;
        END
    )";

    if (!query.exec(triggerSql)) {
        qWarning() << "创建触发器失败:" << query.lastError();
        return false;
    }

    return true;
}

bool ChatDatabase::initData()
{
    if (!m_db.isOpen()) {
        return false;
    }

    // 检查当前用户是否存在
    QSqlQuery query(m_db);
    query.prepare("SELECT COUNT(*) FROM users WHERE username = :username");
    query.bindValue(":username", m_currentUser);

    if (!query.exec()) {
        qWarning() << "查询用户失败:" << query.lastError();
        return false;
    }

    if (query.next() && query.value(0).toInt() == 0) {
        // 用户不存在，插入当前用户
        QString salt = generateSalt();
        QString passwordHash = hashPassword("", salt); // 空密码

        query.prepare(R"(
            INSERT INTO users (username, password, nickname, salt)
            VALUES (:username, :password, :nickname, :salt)
        )");
        query.bindValue(":username", m_currentUser);
        query.bindValue(":password", passwordHash);
        query.bindValue(":nickname", m_currentUser);
        query.bindValue(":salt", salt);

        if (!query.exec()) {
            qWarning() << "插入用户失败:" << query.lastError();
            return false;
        }
    }

    // 创建默认分组
    if (!createDefaultGroups()) {
        qWarning() << "创建默认分组失败";
        return false;
    }

    return true;
}

bool ChatDatabase::createDefaultGroups()
{
    QSqlQuery query(m_db);

    // 添加默认分组
    QStringList defaultGroups = {"好友", "家人", "同事", "同学", "群聊"};

    for (const QString &group : defaultGroups) {
        query.prepare("INSERT OR IGNORE INTO contacts (username, contact_name, contact_group) "
                      "SELECT username, :contact_name, :group FROM users WHERE username = :username");
        query.bindValue(":contact_name", m_currentUser);
        query.bindValue(":group", group);
        query.bindValue(":username", m_currentUser);

        if (!query.exec()) {
            qWarning() << "添加默认分组失败:" << query.lastError();
            return false;
        }
    }

    return true;
}

QString ChatDatabase::generateSalt()
{
    const QString possibleCharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const int saltLength = 16;

    QString salt;
    salt.reserve(saltLength);

    for (int i = 0; i < saltLength; ++i) {
        int index = QRandomGenerator::global()->bounded(possibleCharacters.length());
        salt.append(possibleCharacters.at(index));
    }

    return salt;
}

QString ChatDatabase::hashPassword(const QString &password, const QString &salt)
{
    QCryptographicHash hash(QCryptographicHash::Sha256);
    hash.addData((salt + password).toUtf8());
    return hash.result().toHex();
}

bool ChatDatabase::addUser(const QString &username, const QString &password,
                           const QString &nickname, const QString &phone,
                           const QString &email)
{
    if (!m_db.isOpen() || username.isEmpty() || password.isEmpty()) {
        return false;
    }

    QSqlQuery query(m_db);

    // 生成盐值和密码哈希
    QString salt = generateSalt();
    QString passwordHash = hashPassword(password, salt);

    query.prepare(R"(
        INSERT INTO users (username, password, nickname, phone, email, salt)
        VALUES (:username, :password, :nickname, :phone, :email, :salt)
    )");
    query.bindValue(":username", username);
    query.bindValue(":password", passwordHash);
    query.bindValue(":nickname", nickname.isEmpty() ? username : nickname);
    query.bindValue(":phone", phone);
    query.bindValue(":email", email);
    query.bindValue(":salt", salt);

    if (!query.exec()) {
        emit databaseError("添加用户失败: " + query.lastError().text());
        return false;
    }

    return true;
}

bool ChatDatabase::authenticateUser(const QString &username, const QString &password)
{
    if (!m_db.isOpen() || username.isEmpty() || password.isEmpty()) {
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare("SELECT password, salt FROM users WHERE username = :username AND is_deleted = 0");
    query.bindValue(":username", username);

    if (!query.exec() || !query.next()) {
        return false;
    }

    QString storedHash = query.value(0).toString();
    QString salt = query.value(1).toString();
    QString inputHash = hashPassword(password, salt);

    return (storedHash == inputHash);
}

qint64 ChatDatabase::saveMessage(const MessageInfo &message)
{
    if (!m_db.isOpen()) {
        return 0;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT INTO messages (sender, receiver, msg_type, content, timestamp, is_read, sync_status, extra_data)
        VALUES (:sender, :receiver, :type, :content, :timestamp, :is_read, :sync_status, :extra_data)
    )");

    query.bindValue(":sender", message.sender);
    query.bindValue(":receiver", message.receiver);
    query.bindValue(":type", message.type);
    query.bindValue(":content", message.content);
    query.bindValue(":timestamp", message.timestamp.toString("yyyy-MM-dd HH:mm:ss"));
    query.bindValue(":is_read", message.isRead ? 1 : 0);
    query.bindValue(":sync_status", message.isSync ? 1 : 0);
    query.bindValue(":extra_data", message.extraData);

    if (!query.exec()) {
        emit databaseError("保存消息失败: " + query.lastError().text());
        return 0;
    }

    qint64 messageId = query.lastInsertId().toLongLong();
    emit messageSaved(messageId);

    return messageId;
}

QList<MessageInfo> ChatDatabase::getMessages(const QString &targetUser, int limit,
                                             int offset, bool unreadOnly)
{
    QList<MessageInfo> messages;

    if (!m_db.isOpen() || targetUser.isEmpty()) {
        return messages;
    }

    QSqlQuery query(m_db);

    QString sql = R"(
        SELECT id, sender, receiver, msg_type, content, timestamp, is_read, sync_status, extra_data
        FROM messages
        WHERE ((sender = :user AND receiver = :target) OR (sender = :target AND receiver = :user))
    )";

    if (unreadOnly) {
        sql += " AND is_read = 0";
    }

    sql += " ORDER BY timestamp DESC LIMIT :limit OFFSET :offset";

    query.prepare(sql);
    query.bindValue(":user", m_currentUser);
    query.bindValue(":target", targetUser);
    query.bindValue(":limit", limit);
    query.bindValue(":offset", offset);

    if (!query.exec()) {
        emit databaseError("获取消息失败: " + query.lastError().text());
        return messages;
    }

    while (query.next()) {
        MessageInfo message;
        message.id = query.value(0).toLongLong();
        message.sender = query.value(1).toString();
        message.receiver = query.value(2).toString();
        message.type = query.value(3).toString();
        message.content = query.value(4).toString();
        message.timestamp = QDateTime::fromString(query.value(5).toString(), "yyyy-MM-dd HH:mm:ss");
        message.isRead = query.value(6).toBool();
        message.isSync = query.value(7).toBool();
        message.extraData = query.value(8).toString();

        messages.append(message);
    }

    return messages;
}

bool ChatDatabase::addContact(const QString &username, const QString &nickname,
                              const QString &group, const QString &remark)
{
    if (!m_db.isOpen() || username.isEmpty()) {
        return false;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT OR REPLACE INTO contacts (username, contact_name, nickname, remark, contact_group)
        VALUES (:username, :contact_name, :nickname, :remark, :group)
    )");

    query.bindValue(":username", m_currentUser);
    query.bindValue(":contact_name", username);
    query.bindValue(":nickname", nickname.isEmpty() ? username : nickname);
    query.bindValue(":remark", remark);
    query.bindValue(":group", group.isEmpty() ? "默认分组" : group);

    if (!query.exec()) {
        emit databaseError("添加联系人失败: " + query.lastError().text());
        return false;
    }

    emit contactAdded(username);
    return true;
}

QList<ContactInfo> ChatDatabase::getContacts()
{
    QList<ContactInfo> contacts;

    if (!m_db.isOpen()) {
        return contacts;
    }

    QSqlQuery query(m_db);
    query.prepare(R"(
        SELECT contact_name, nickname, remark, contact_group, status, is_online,
               last_seen, avatar
        FROM contacts
        WHERE username = :username
        ORDER BY contact_group, contact_name
    )");
    query.bindValue(":username", m_currentUser);

    if (!query.exec()) {
        emit databaseError("获取联系人失败: " + query.lastError().text());
        return contacts;
    }

    while (query.next()) {
        ContactInfo contact;
        contact.username = query.value(0).toString();
        contact.nickname = query.value(1).toString();
        contact.group = query.value(3).toString();
        contact.status = query.value(4).toString();
        contact.isOnline = query.value(5).toBool();
        contact.lastSeen = QDateTime::fromString(query.value(6).toString(), "yyyy-MM-dd HH:mm:ss");
        contact.avatar = query.value(7).toString();

        contacts.append(contact);
    }

    return contacts;
}

void ChatDatabase::compactDatabase()
{
    if (m_db.isOpen()) {
        QSqlQuery query(m_db);
        query.exec("VACUUM");
        query.exec("ANALYZE");
    }
}

qint64 ChatDatabase::getDatabaseSize() const
{
    if (m_databasePath.isEmpty()) {
        return 0;
    }

    QFileInfo fileInfo(m_databasePath);
    return fileInfo.size();
}
