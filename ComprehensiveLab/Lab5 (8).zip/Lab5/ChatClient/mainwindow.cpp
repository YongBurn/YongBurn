#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QDateTime>
#include <QMessageBox>
#include <QHostAddress>
#include <QTimer>
#include <QInputDialog>

const QString MainWindow::JSON_KEY_TYPE = QStringLiteral("type");
const QString MainWindow::JSON_KEY_USERNAME = QStringLiteral("username");
const QString MainWindow::JSON_KEY_PASSWORD = QStringLiteral("password");
const QString MainWindow::JSON_KEY_SENDER = QStringLiteral("sender");
const QString MainWindow::JSON_KEY_RECEIVER = QStringLiteral("receiver");
const QString MainWindow::JSON_KEY_TEXT = QStringLiteral("text");
const QString MainWindow::JSON_KEY_USERLIST = QStringLiteral("userlist");
const QString MainWindow::JSON_KEY_REASON = QStringLiteral("reason");
const QString MainWindow::JSON_KEY_NAME = QStringLiteral("name");
const QString MainWindow::JSON_KEY_PHONE = QStringLiteral("phone");
const QString MainWindow::JSON_KEY_SERVER = QStringLiteral("server");

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_socket(new QTcpSocket(this))
    , m_heartbeatTimer(new QTimer(this))
    , m_dbHelper(this)
    , m_currentUsername(QString())
    , m_privateChatTargetUser(QString())
    , m_currentServerIp(QStringLiteral("127.0.0.1"))
    , m_isSendingPrivateMsg(false) // 初始化发送状态
{
    ui->setupUi(this);

    if (!m_dbHelper.initDB()) {
        QMessageBox::critical(this, QStringLiteral("错误"), QStringLiteral("数据库初始化失败！"));
    }

    ui->stackedWidget->setCurrentIndex(3);
    ui->privateTextEdit->setReadOnly(true);
    ui->roomTextEdit->setReadOnly(true);

    connect(ui->userListWidget, &QListWidget::itemDoubleClicked, this, &MainWindow::on_userListWidget_itemDoubleClicked);
    connect(ui->userListWidget_2, &QListWidget::itemDoubleClicked, this, &MainWindow::on_userListWidget_2_itemDoubleClicked);

    connect(m_socket, &QTcpSocket::connected, this, &MainWindow::onConnected);
    connect(m_socket, &QTcpSocket::disconnected, this, &MainWindow::onDisconnected);
    connect(m_socket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);
    connect(m_socket, &QTcpSocket::errorOccurred, this, &MainWindow::onSocketError);

    connect(m_heartbeatTimer, &QTimer::timeout, this, &MainWindow::sendHeartbeat);
    m_heartbeatTimer->setInterval(30000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::connectToServer(const QString& serverIp)
{
    m_currentServerIp = serverIp;
    quint16 serverPort = 1967;
    m_socket->connectToHost(QHostAddress(serverIp), serverPort);
}

void MainWindow::handleServerResponse(const QJsonObject& json)
{
    QString type = json[JSON_KEY_TYPE].toString();

    if (type == QStringLiteral("login_success")) {
        m_currentUsername = json[JSON_KEY_USERNAME].toString();
        ui->stackedWidget->setCurrentIndex(0);
        loadChatHistory();
        m_heartbeatTimer->start();
    } else if (type == QStringLiteral("login_failed")) {
        QMessageBox::warning(this, QStringLiteral("登录失败"), json[JSON_KEY_REASON].toString());
    } else if (type == QStringLiteral("register_success")) {
        QMessageBox::information(this, QStringLiteral("注册成功"), QStringLiteral("注册成功，请登录！"));
        ui->stackedWidget->setCurrentIndex(3);
    } else if (type == QStringLiteral("register_failed")) {
        QMessageBox::warning(this, QStringLiteral("注册失败"), json[JSON_KEY_REASON].toString());
    } else if (type == QStringLiteral("public_chat")) {
        QString sender = json[JSON_KEY_SENDER].toString();
        QString text = json[JSON_KEY_TEXT].toString();

        QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"));
        ui->roomTextEdit->append(QStringLiteral("[%1][%2]：%3").arg(time).arg(sender).arg(text));

        ChatRecord record;
        record.username = m_currentUsername;
        record.type = QStringLiteral("public");
        record.sender = sender;
        record.receiver = QStringLiteral("all");
        record.content = text;
        record.time = time;
        m_dbHelper.insertChatRecord(record);
    } else if (type == QStringLiteral("private_chat")) {
        QString sender = json[JSON_KEY_SENDER].toString();
        QString receiver = json[JSON_KEY_RECEIVER].toString();
        QString text = json[JSON_KEY_TEXT].toString();

        QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"));
        QString displayText;

        // 修复：只有当前私聊目标匹配时才显示消息
        if (m_privateChatTargetUser.isEmpty()) {
            // 未打开私聊页时，弹出新消息提示
            QMessageBox::information(this, QStringLiteral("新私聊消息"),
                                     QStringLiteral("收到%1的消息：%2").arg(sender).arg(text));
            return;
        }

        // 仅显示当前私聊会话的消息
        if ((sender == m_currentUsername && receiver == m_privateChatTargetUser) ||
            (sender == m_privateChatTargetUser && receiver == m_currentUsername)) {
            if (sender == m_currentUsername) {
                displayText = QStringLiteral("[%1][我→%2]：%3").arg(time).arg(receiver).arg(text);
            } else {
                displayText = QStringLiteral("[%1][%2→我]：%3").arg(time).arg(sender).arg(text);
            }
            ui->privateTextEdit->append(displayText);

            // 保存到数据库
            ChatRecord record;
            record.username = m_currentUsername;
            record.type = QStringLiteral("private");
            record.sender = sender;
            record.receiver = receiver;
            record.content = text;
            record.time = time;
            m_dbHelper.insertChatRecord(record);
        }
    } else if (type == QStringLiteral("private_chat_ack")) {
        // 收到服务端发送成功确认，恢复发送状态
        m_isSendingPrivateMsg = false;
        ui->SendprivateChat->setEnabled(true);
    } else if (type == QStringLiteral("userlist")) {
        ui->userListWidget->clear();
        ui->userListWidget_2->clear();
        QJsonArray userArray = json[JSON_KEY_USERLIST].toArray();
        for (const QJsonValue& val : userArray) {
            QString username = val.toString();
            if (username != m_currentUsername) {
                ui->userListWidget->addItem(username);
                ui->userListWidget_2->addItem(username);
            }
        }
    } else if (type == QStringLiteral("heartbeat_ack")) {
        // 心跳响应
    }
}

void MainWindow::loadChatHistory()
{
    QList<ChatRecord> records = m_dbHelper.queryAllChatRecords(m_currentUsername);
    for (const ChatRecord& record : records) {
        if (record.sender == m_currentUsername) {
            ui->roomTextEdit->append(QStringLiteral("[%1][我]：%2").arg(record.time).arg(record.content));
        } else {
            ui->roomTextEdit->append(QStringLiteral("[%1][%2]：%3").arg(record.time).arg(record.sender).arg(record.content));
        }
    }
}

void MainWindow::loadPrivateChatHistory(const QString& targetUser)
{
    m_privateChatTargetUser = targetUser;
    ui->privateTextEdit->clear();

    QList<ChatRecord> records = m_dbHelper.queryPrivateChat(m_currentUsername, targetUser);
    for (const ChatRecord& record : records) {
        QString displayText;
        if (record.sender == m_currentUsername) {
            displayText = QStringLiteral("[%1][我→%2]：%3").arg(record.time).arg(record.receiver).arg(record.content);
        } else {
            displayText = QStringLiteral("[%1][%2→我]：%3").arg(record.time).arg(record.sender).arg(record.content);
        }
        ui->privateTextEdit->append(displayText);
    }
}

void MainWindow::sendHeartbeat()
{
    QJsonObject json;
    json[JSON_KEY_TYPE] = QStringLiteral("heartbeat");
    json[JSON_KEY_USERNAME] = m_currentUsername;

    QJsonDocument doc(json);
    m_socket->write(doc.toJson(QJsonDocument::Compact) + QStringLiteral("\n").toUtf8());
}

void MainWindow::onConnected()
{
    qInfo() << QStringLiteral("已连接到服务器：%1").arg(m_currentServerIp);
}

void MainWindow::onDisconnected()
{
    qInfo() << QStringLiteral("与服务器断开连接");
    m_heartbeatTimer->stop();
    QMessageBox::information(this, QStringLiteral("提示"), QStringLiteral("已与服务器断开连接！"));
    ui->stackedWidget->setCurrentIndex(3);
}

void MainWindow::onSocketError(QAbstractSocket::SocketError error)
{
    qCritical() << QStringLiteral("Socket错误：%1").arg(m_socket->errorString());
    QMessageBox::critical(this, QStringLiteral("错误"),
                          QStringLiteral("连接服务器失败：%1").arg(m_socket->errorString()));
}

void MainWindow::onReadyRead()
{
    QByteArray data = m_socket->readAll();
    QStringList jsonStrList = QString::fromUtf8(data).split(QStringLiteral("\n"), Qt::SkipEmptyParts);

    for (const QString& jsonStr : jsonStrList) {
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(jsonStr.toUtf8(), &error);
        if (error.error != QJsonParseError::NoError) {
            qWarning() << QStringLiteral("JSON解析失败：%1").arg(error.errorString());
            continue;
        }
        handleServerResponse(doc.object());
    }
}

void MainWindow::on_loginButton_clicked()
{
    if (m_socket->state() == QTcpSocket::ConnectingState) {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("正在连接服务器，请稍后再试！"));
        return;
    }

    QString serverIp = ui->ServerEdit->text().trimmed();
    QString username = ui->UserNameEdit->text().trimmed();
    QString password = ui->UserPasswordEdit->text().trimmed();

    if (serverIp.isEmpty() || username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("警告"), QStringLiteral("服务器地址/用户名/密码不能为空！"));
        return;
    }

    connectToServer(serverIp);

    QJsonObject json;
    json[JSON_KEY_TYPE] = QStringLiteral("login");
    json[JSON_KEY_USERNAME] = username;
    json[JSON_KEY_PASSWORD] = password;

    QJsonDocument doc(json);
    m_socket->write(doc.toJson(QJsonDocument::Compact) + QStringLiteral("\n").toUtf8());
}

void MainWindow::on_registerButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
    ui->ServerEdit_2->setText(ui->ServerEdit->text());
}

void MainWindow::on_Register_clicked()
{
    QString serverIp = ui->ServerEdit_2->text().trimmed();
    QString username = ui->RegisterUserNameEdit->text().trimmed();
    QString password = ui->RegisterUserPasswordEdit->text().trimmed();
    QString name = ui->AddressNameEdit->text().trimmed();
    QString phone = ui->TelephonenumberEdit->text().trimmed();

    if (serverIp.isEmpty() || username.isEmpty() || password.isEmpty() ||
        name.isEmpty() || phone.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("警告"), QStringLiteral("请填写完整注册信息！"));
        return;
    }

    connectToServer(serverIp);

    QJsonObject json;
    json[JSON_KEY_TYPE] = QStringLiteral("register");
    json[JSON_KEY_USERNAME] = username;
    json[JSON_KEY_PASSWORD] = password;
    json[JSON_KEY_NAME] = name;
    json[JSON_KEY_PHONE] = phone;

    QJsonDocument doc(json);
    m_socket->write(doc.toJson(QJsonDocument::Compact) + QStringLiteral("\n").toUtf8());
}

void MainWindow::on_returnButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
    ui->RegisterUserNameEdit->clear();
    ui->RegisterUserPasswordEdit->clear();
    ui->AddressNameEdit->clear();
    ui->TelephonenumberEdit->clear();
}

void MainWindow::on_sayBtn_clicked()
{
    QString msg = ui->sayLineEdit->text().trimmed();
    if (msg.isEmpty()) return;

    QJsonObject json;
    json[JSON_KEY_TYPE] = QStringLiteral("public_chat");
    json[JSON_KEY_SENDER] = m_currentUsername;
    json[JSON_KEY_RECEIVER] = QStringLiteral("all");
    json[JSON_KEY_TEXT] = msg;

    QJsonDocument doc(json);
    m_socket->write(doc.toJson(QJsonDocument::Compact) + QStringLiteral("\n").toUtf8());

    QString time = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss"));
    ui->roomTextEdit->append(QStringLiteral("[%1][我]：%2").arg(time).arg(msg));
    ui->sayLineEdit->clear();

    ChatRecord record;
    record.username = m_currentUsername;
    record.type = QStringLiteral("public");
    record.sender = m_currentUsername;
    record.receiver = QStringLiteral("all");
    record.content = msg;
    record.time = time;
    m_dbHelper.insertChatRecord(record);
}

void MainWindow::on_logoutBtn_clicked()
{
    int ret = QMessageBox::question(this, QStringLiteral("确认退出"), QStringLiteral("确定要退出登录吗？"),
                                    QMessageBox::Yes | QMessageBox::No);
    if (ret == QMessageBox::Yes) {
        m_socket->disconnectFromHost();
        m_heartbeatTimer->stop();
        ui->stackedWidget->setCurrentIndex(3);
        m_currentUsername.clear();
        m_privateChatTargetUser.clear();
        ui->roomTextEdit->clear();
        ui->privateTextEdit->clear();
        ui->userListWidget->clear();
        ui->userListWidget_2->clear();
    }
}

void MainWindow::on_contacts_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
    QMap<QString, QList<QString>> groupContacts = m_dbHelper.queryAllGroupContacts();
    ui->Grouping->clear();
    ui->userListWidget_4->clear();
    ui->Grouping->addItems(groupContacts.keys());
}

// 核心修复：防重复发送+仅本地显示1次
void MainWindow::on_SendprivateChat_clicked()
{
    QString msg = ui->PrivateChatSayLineEdit->text().trimmed();
    if (msg.isEmpty() || m_privateChatTargetUser.isEmpty()) {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("请先选择私聊对象！"));
        return;
    }

    // 防重复发送：正在发送时直接返回
    if (m_isSendingPrivateMsg) {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("消息正在发送中，请稍后！"));
        return;
    }

    // 标记为发送中，禁用按钮
    m_isSendingPrivateMsg = true;
    ui->SendprivateChat->setEnabled(false);

    // 构造私聊消息
    QJsonObject json;
    json[JSON_KEY_TYPE] = QStringLiteral("private_chat");
    json[JSON_KEY_SENDER] = m_currentUsername;
    json[JSON_KEY_RECEIVER] = m_privateChatTargetUser;
    json[JSON_KEY_TEXT] = msg;

    QJsonDocument doc(json);
    m_socket->write(doc.toJson(QJsonDocument::Compact) + QStringLiteral("\n").toUtf8());

    // 清空输入框（不再本地显示，等待服务端确认后显示）
    ui->PrivateChatSayLineEdit->clear();

    // 兜底：3秒后恢复按钮（防止服务端未返回确认）
    QTimer::singleShot(3000, this, &MainWindow::restoreSendButton);
}

// 恢复发送按钮
void MainWindow::restoreSendButton()
{
    m_isSendingPrivateMsg = false;
    ui->SendprivateChat->setEnabled(true);
}

void MainWindow::on_PrivateChatreturn_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    m_privateChatTargetUser.clear();
    ui->privateTextEdit->clear();
}

void MainWindow::on_AddGroup_clicked()
{
    bool ok;
    QString groupName = QInputDialog::getText(this, QStringLiteral("添加分组"),
                                              QStringLiteral("请输入分组名称："),
                                              QLineEdit::Normal, QString(), &ok);
    if (ok && !groupName.isEmpty()) {
        m_dbHelper.insertGroup(groupName);
        ui->Grouping->addItem(groupName);
    }
}

void MainWindow::on_Addcontact_clicked()
{
    QListWidgetItem* currentGroup = ui->Grouping->currentItem();
    if (!currentGroup) {
        QMessageBox::warning(this, QStringLiteral("警告"), QStringLiteral("请先选择一个分组！"));
        return;
    }

    bool ok;
    QString contact = QInputDialog::getText(this, QStringLiteral("添加联系人"),
                                            QStringLiteral("请输入联系人用户名："),
                                            QLineEdit::Normal, QString(), &ok);
    if (ok && !contact.isEmpty()) {
        m_dbHelper.insertGroupContact(currentGroup->text(), contact);
        ui->userListWidget_4->addItem(contact);
    }
}

void MainWindow::on_Return_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_userListWidget_itemDoubleClicked(QListWidgetItem *item)
{
    if (!item) return;
    QString targetUser = item->text();

    if (targetUser == m_currentUsername) {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("无法与自己发起私聊！"));
        return;
    }

    m_privateChatTargetUser = targetUser;
    loadPrivateChatHistory(targetUser);
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item)
{
    if (!item) return;
    QString targetUser = item->text();

    if (targetUser == m_currentUsername) {
        QMessageBox::warning(this, QStringLiteral("提示"), QStringLiteral("无法与自己发起私聊！"));
        return;
    }

    m_privateChatTargetUser = targetUser;
    loadPrivateChatHistory(targetUser);
}
