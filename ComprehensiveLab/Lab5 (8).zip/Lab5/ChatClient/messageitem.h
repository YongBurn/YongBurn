#ifndef MESSAGEITEM_H
#define MESSAGEITEM_H

#include <QString>
#include <QDateTime>
#include "chatenum.h"

struct MessageItem {
    QString sender;
    QString content;
    QString timestamp;
    ChatEnum::MessageType messageType;

    MessageItem() : messageType(ChatEnum::MessageType::PublicChat) {}
};

struct ChatRecord {
    QString sender;
    QString receiver;
    QString content;
    QString timestamp;
    ChatEnum::ChatType chatType;

    ChatRecord() : chatType(ChatEnum::ChatType::Public) {}
};

// 获取当前时间字符串
inline QString getCurrentTimeString() {
    return QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
}

#endif // MESSAGEITEM_H
