#ifndef CHATRECORD_H
#define CHATRECORD_H

#include <QString>

/**
 * @brief 聊天记录结构体
 * @details 存储单条聊天记录的所有信息，支持群聊和私聊
 */
struct ChatRecord {
    QString username;  // 当前登录用户（用于数据库关联）
    QString type;      // 消息类型：public(群聊)/private(私聊)
    QString sender;    // 发送者用户名
    QString receiver;  // 接收者（群聊为"all"，私聊为目标用户名）
    QString content;   // 消息内容
    QString time;      // 消息时间（格式：HH:mm:ss）
};

#endif // CHATRECORD_H
