#include "dbhelper.h"
#include <QCoreApplication>
#include <QStandardPaths>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

DBHelper::DBHelper(QObject *parent)
    : QObject(parent)
    , DB_CONN_NAME(QStringLiteral("ChatClient_DB_Connection"))
    , DB_FILE_NAME(QStringLiteral("chat.db")) // 该变量不再使用，仅保留兼容
{
}

DBHelper::~DBHelper()
{
    if (m_db.isOpen()) {
        m_db.close();
    }
}

bool DBHelper::initDB()
{
    // ========== 核心修改：替换为指定的绝对数据库路径 ==========
    // 注意：C++中反斜杠需要双写（转义）
    QString dbPath = QStringLiteral("D:\\qt\\task\\Lab5\\Lab5\\Lab4a\\Lab4a.db");

    // 检查连接是否存在
    if (QSqlDatabase::contains(DB_CONN_NAME)) {
        m_db = QSqlDatabase::database(DB_CONN_NAME);
    } else {
        m_db = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), DB_CONN_NAME);
        m_db.setDatabaseName(dbPath); // 使用指定路径
    }

    // 打开数据库
    if (!m_db.open()) {
        qCritical() << "打开数据库失败：" << m_db.lastError().text();
        return false;
    }

    // 创建表（逻辑不变）
    if (!createChatRecordsTable()) {
        return false;
    }
    if (!createGroupsTable()) {
        return false;
    }
    if (!createGroupContactsTable()) {
        return false;
    }

    qInfo() << "数据库初始化成功，路径：" << dbPath;
    return true;
}

// 以下函数逻辑完全不变，无需修改
bool DBHelper::createChatRecordsTable()
{
    QString sql = QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS chat_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            type TEXT NOT NULL,
            sender TEXT NOT NULL,
            receiver TEXT NOT NULL,
            content TEXT NOT NULL,
            time TEXT NOT NULL
        )
    )");

    QSqlQuery query(m_db);
    if (!query.exec(sql)) {
        qCritical() << "创建聊天记录表失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBHelper::createGroupsTable()
{
    QString sql = QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT UNIQUE NOT NULL
        )
    )");

    QSqlQuery query(m_db);
    if (!query.exec(sql)) {
        qCritical() << "创建群组表失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBHelper::createGroupContactsTable()
{
    QString sql = QStringLiteral(R"(
        CREATE TABLE IF NOT EXISTS group_contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT NOT NULL,
            contact TEXT NOT NULL,
            UNIQUE(group_name, contact)
        )
    )");

    QSqlQuery query(m_db);
    if (!query.exec(sql)) {
        qCritical() << "创建群组成员表失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBHelper::insertChatRecord(const ChatRecord& record)
{
    QSqlQuery query(m_db);
    query.prepare(QStringLiteral(R"(
        INSERT INTO chat_records (username, type, sender, receiver, content, time)
        VALUES (:username, :type, :sender, :receiver, :content, :time)
    )"));

    query.bindValue(QStringLiteral(":username"), record.username);
    query.bindValue(QStringLiteral(":type"), record.type);
    query.bindValue(QStringLiteral(":sender"), record.sender);
    query.bindValue(QStringLiteral(":receiver"), record.receiver);
    query.bindValue(QStringLiteral(":content"), record.content);
    query.bindValue(QStringLiteral(":time"), record.time);

    if (!query.exec()) {
        qCritical() << "插入聊天记录失败：" << query.lastError().text();
        return false;
    }
    return true;
}

QList<ChatRecord> DBHelper::queryAllChatRecords(const QString& username)
{
    QList<ChatRecord> records;

    QSqlQuery query(m_db);
    query.prepare(QStringLiteral(R"(
        SELECT type, sender, receiver, content, time
        FROM chat_records
        WHERE username = :username AND type = 'public'
        ORDER BY time ASC
    )"));

    query.bindValue(QStringLiteral(":username"), username);
    if (!query.exec()) {
        qCritical() << "查询公共聊天记录失败：" << query.lastError().text();
        return records;
    }

    while (query.next()) {
        ChatRecord record;
        record.username = username;
        record.type = query.value(0).toString();
        record.sender = query.value(1).toString();
        record.receiver = query.value(2).toString();
        record.content = query.value(3).toString();
        record.time = query.value(4).toString();
        records.append(record);
    }

    return records;
}

QList<ChatRecord> DBHelper::queryPrivateChat(const QString& username, const QString& target)
{
    QList<ChatRecord> records;

    QSqlQuery query(m_db);
    query.prepare(QStringLiteral(R"(
        SELECT type, sender, receiver, content, time
        FROM chat_records
        WHERE username = :username
        AND type = 'private'
        AND (
            (sender = :username AND receiver = :target)
            OR (sender = :target AND receiver = :username)
        )
        ORDER BY time ASC
    )"));

    query.bindValue(QStringLiteral(":username"), username);
    query.bindValue(QStringLiteral(":target"), target);
    if (!query.exec()) {
        qCritical() << "查询私聊记录失败：" << query.lastError().text();
        return records;
    }

    while (query.next()) {
        ChatRecord record;
        record.username = username;
        record.type = query.value(0).toString();
        record.sender = query.value(1).toString();
        record.receiver = query.value(2).toString();
        record.content = query.value(3).toString();
        record.time = query.value(4).toString();
        records.append(record);
    }

    return records;
}

bool DBHelper::insertGroup(const QString& groupName)
{
    QSqlQuery query(m_db);
    query.prepare(QStringLiteral(R"(
        INSERT OR IGNORE INTO groups (group_name)
        VALUES (:group_name)
    )"));

    query.bindValue(QStringLiteral(":group_name"), groupName);
    if (!query.exec()) {
        qCritical() << "插入群组失败：" << query.lastError().text();
        return false;
    }
    return true;
}

QMap<QString, QList<QString>> DBHelper::queryAllGroupContacts()
{
    QMap<QString, QList<QString>> groupContacts;

    QSqlQuery groupQuery(m_db);
    if (!groupQuery.exec(QStringLiteral("SELECT group_name FROM groups ORDER BY id ASC"))) {
        qCritical() << "查询群组列表失败：" << groupQuery.lastError().text();
        return groupContacts;
    }

    while (groupQuery.next()) {
        QString groupName = groupQuery.value(0).toString();
        QList<QString> contacts;

        QSqlQuery contactQuery(m_db);
        contactQuery.prepare(QStringLiteral(R"(
            SELECT contact FROM group_contacts WHERE group_name = :group_name ORDER BY id ASC
        )"));
        contactQuery.bindValue(QStringLiteral(":group_name"), groupName);

        if (!contactQuery.exec()) {
            qCritical() << "查询群组成员失败：" << contactQuery.lastError().text();
            continue;
        }

        while (contactQuery.next()) {
            contacts.append(contactQuery.value(0).toString());
        }

        groupContacts.insert(groupName, contacts);
    }

    return groupContacts;
}

bool DBHelper::insertGroupContact(const QString& groupName, const QString& contact)
{
    QSqlQuery query(m_db);
    query.prepare(QStringLiteral(R"(
        INSERT OR IGNORE INTO group_contacts (group_name, contact)
        VALUES (:group_name, :contact)
    )"));

    query.bindValue(QStringLiteral(":group_name"), groupName);
    query.bindValue(QStringLiteral(":contact"), contact);
    if (!query.exec()) {
        qCritical() << "插入群组成员失败：" << query.lastError().text();
        return false;
    }
    return true;
}
