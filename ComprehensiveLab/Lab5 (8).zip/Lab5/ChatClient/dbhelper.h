#ifndef DBHELPER_H
#define DBHELPER_H

#include <QObject>
#include <QSqlDatabase>
#include <QString>
#include <QList>
#include <QMap>

// 聊天记录结构体
struct ChatRecord {
    QString username;
    QString type;
    QString sender;
    QString receiver;
    QString content;
    QString time;
};

class DBHelper : public QObject
{
    Q_OBJECT

public: // 构造函数设为public，允许外部实例化
    explicit DBHelper(QObject *parent = nullptr);
    ~DBHelper();

    // 核心功能函数声明
    bool initDB(); // 初始化数据库（必须调用）
    bool insertChatRecord(const ChatRecord& record); // 插入聊天记录
    QList<ChatRecord> queryAllChatRecords(const QString& username); // 查询公共聊天记录
    QList<ChatRecord> queryPrivateChat(const QString& username, const QString& target); // 查询私聊记录
    bool insertGroup(const QString& groupName); // 插入分组
    QMap<QString, QList<QString>> queryAllGroupContacts(); // 查询所有群组成员
    bool insertGroupContact(const QString& groupName, const QString& contact); // 插入群组成员

private: // 补充缺失的私有函数声明
    bool createChatRecordsTable(); // 创建聊天记录表
    bool createGroupsTable(); // 创建群组表
    bool createGroupContactsTable(); // 创建群组成员表

private:
    QSqlDatabase m_db; // 数据库连接对象
    const QString DB_CONN_NAME; // 连接名
    const QString DB_FILE_NAME; // 数据库文件名
};

#endif // DBHELPER_H
