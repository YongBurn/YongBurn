#ifndef DBMANAGER_H
#define DBMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QList>
#include <QString>
#include <QDebug>
#include <QMutex>
#include <QDateTime>

// 聊天类型枚举
enum class ChatType {
    Public,  // 群聊
    Private  // 单聊
};

// 聊天记录结构体
struct ChatRecord {
    QString sender;       // 发送者
    QString receiver;     // 接收者（群聊=all，单聊=用户名）
    QString content;      // 消息内容
    QString timestamp;    // 时间戳（yyyy-MM-dd HH:mm:ss）
    ChatType chatType;    // 聊天类型
};

class DBManager : public QObject
{
    Q_OBJECT
public:
    // 单例模式（线程安全）
    static DBManager* getInstance(QObject *parent = nullptr);

    // 初始化数据库（连接指定路径）
    bool initDatabase();

    // 用户信息操作（线程安全）
    bool saveUserInfo(const QString &username, const QString &password, const QString &name = "", const QString &phone = "");
    bool checkUserPassword(const QString &username, const QString &password);
    bool checkUserExists(const QString &username);

    // 联系人操作（线程安全）
    bool addContact(const QString &groupName, const QString &username);
    bool deleteContact(const QString &groupName, const QString &username);
    bool deleteGroup(const QString &groupName);
    QStringList getAllGroups();
    QStringList getContactsByGroup(const QString &groupName);
    bool contactExists(const QString &groupName, const QString &username);

    // 聊天记录操作（线程安全）
    bool saveChatRecord(const QString &localUsername, const ChatRecord &record);
    QList<ChatRecord> getChatRecords(const QString &localUsername, ChatType chatType, const QString &target);
    bool deleteChatRecords(const QString &localUsername, ChatType chatType, const QString &target);

private:
    explicit DBManager(QObject *parent = nullptr);
    ~DBManager() override;

    // 禁止拷贝赋值
    DBManager(const DBManager&) = delete;
    DBManager& operator=(const DBManager&) = delete;

    // 创建表（兼容空库）
    bool createTables();

    // 成员变量
    static DBManager *m_instance;
    static QMutex m_instanceMutex; // 单例锁
    QMutex m_dbMutex;              // 数据库操作锁
    QSqlDatabase m_db;
    const QString m_dbPath = "D:/qt/task/Lab5/Lab5/Lab4a/Lab4a.db"; // 最终数据库路径
};

#endif // DBMANAGER_H
