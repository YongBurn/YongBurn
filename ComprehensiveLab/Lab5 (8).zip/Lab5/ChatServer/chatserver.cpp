#include "chatserver.h"

// 初始化静态用户列表（默认管理员账号）
QMap<QString, UserData> ChatServer::m_allUsers;

ChatServer::ChatServer(QObject *parent)
    : QObject(parent)
    , m_tcpServer(new QTcpServer(this))
{
    // 添加默认用户：admin/admin123
    UserData admin;
    admin.password = "admin123";
    admin.name = "管理员";
    admin.phone = "12345678901";
    m_allUsers["admin"] = admin;

    // 绑定新连接信号
    connect(m_tcpServer, &QTcpServer::newConnection, this, &ChatServer::onNewConnection);
}

ChatServer::~ChatServer()
{
    stop();
}

// 启动服务器
bool ChatServer::start(quint16 port)
{
    if (m_tcpServer->listen(QHostAddress::Any, port)) {
        emit serverStarted();
        qDebug() << "服务器启动成功，监听端口：" << port;
        return true;
    } else {
        emit errorOccurred(m_tcpServer->errorString());
        return false;
    }
}

// 停止服务器
void ChatServer::stop()
{
    if (m_tcpServer->isListening()) {
        // 断开所有客户端
        for (QTcpSocket *socket : m_clientMap.keys()) {
            socket->disconnectFromHost();
            socket->deleteLater();
        }
        m_clientMap.clear();
        m_onlineUsers.clear();

        // 停止监听
        m_tcpServer->close();
        emit serverStopped();
        qDebug() << "服务器已停止";
    }
}

// 新客户端连接
void ChatServer::onNewConnection()
{
    QTcpSocket *socket = m_tcpServer->nextPendingConnection();
    if (!socket) return;

    // 绑定客户端信号
    connect(socket, &QTcpSocket::disconnected, this, &ChatServer::onClientDisconnected);
    connect(socket, &QTcpSocket::readyRead, this, &ChatServer::onReadyRead);

    // 记录客户端信息
    QString clientIp = socket->peerAddress().toString();
    quint16 clientPort = socket->peerPort();
    m_clientMap[socket] = ""; // 初始未登录，用户名为空

    emit clientConnected(clientIp, clientPort);
    qDebug() << "新客户端连接：" << clientIp << ":" << clientPort;
}

// 客户端断开连接
void ChatServer::onClientDisconnected()
{
    QTcpSocket *socket = qobject_cast<QTcpSocket*>(sender());
    if (!socket) return;

    // 获取客户端信息
    QString clientIp = socket->peerAddress().toString();
    quint16 clientPort = socket->peerPort();
    QString username = m_clientMap.value(socket, "");

    // 移除在线用户
    if (!username.isEmpty()) {
        m_onlineUsers.remove(username);
        updateOnlineUserList(); // 广播更新用户列表
        emit messageReceived("系统", "all", username + " 已退出");
    }

    // 清理资源
    m_clientMap.remove(socket);
    socket->deleteLater();

    emit clientDisconnected(clientIp, clientPort);
    qDebug() << "客户端断开：" << clientIp << ":" << clientPort;
}

// 读取客户端数据
void ChatServer::onReadyRead()
{
    QTcpSocket *socket = qobject_cast<QTcpSocket*>(sender());
    if (!socket) return;

    // 读取所有数据
    QByteArray data = socket->readAll();
    QStringList messages = QString(data).split("\n", Qt::SkipEmptyParts);

    // 解析每条消息
    for (const QString &msg : messages) {
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(msg.toUtf8(), &error);
        if (error.error != QJsonParseError::NoError) {
            qDebug() << "JSON解析错误：" << error.errorString();
            continue;
        }

        QJsonObject json = doc.object();
        QString type = json["type"].toString();

        // 根据消息类型处理
        if (type == "login") {
            handleLogin(socket, json);
        } else if (type == "register") {
            handleRegister(socket, json);
        } else if (type == "public_chat") {
            handlePublicChat(socket, json);
        } else if (type == "private_chat") {
            handlePrivateChat(socket, json);
        } else if (type == "heartbeat") {
            handleHeartbeat(socket, json);
        } else if (type == "logout") {
            handleLogout(socket, json);
        }
    }
}

// 处理登录请求
void ChatServer::handleLogin(QTcpSocket *socket, const QJsonObject &msg)
{
    QString username = msg["username"].toString();
    QString password = msg["password"].toString();

    QJsonObject response;
    // 校验用户
    if (checkUser(username, password)) {
        // 检查是否已在线
        if (m_onlineUsers.contains(username)) {
            response["type"] = "login_failed";
            response["reason"] = "该用户已在线";
        } else {
            // 登录成功
            m_clientMap[socket] = username;
            m_onlineUsers.insert(username);

            response["type"] = "login_success";
            response["username"] = username;

            // 广播在线用户列表
            updateOnlineUserList();
            emit messageReceived("系统", "all", username + " 已登录");
        }
    } else {
        response["type"] = "login_failed";
        response["reason"] = "用户名或密码错误";
    }

    // 发送响应
    sendJsonToClient(socket, response);
}//构造用户列表

// 处理注册请求
void ChatServer::handleRegister(QTcpSocket *socket, const QJsonObject &msg)
{
    QString username = msg["username"].toString();
    QString password = msg["password"].toString();
    QString name = msg["name"].toString();
    QString phone = msg["phone"].toString();

    QJsonObject response;
    // 校验输入
    if (username.isEmpty() || password.isEmpty()) {
        response["type"] = "register_failed";
        response["reason"] = "用户名/密码不能为空";
    } else if (m_allUsers.contains(username)) {
        response["type"] = "register_failed";
        response["reason"] = "用户名已存在";
    } else if (addUser(username, password, name, phone)) {
        // 注册成功
        response["type"] = "register_success";
        response["username"] = username;
    } else {
        response["type"] = "register_failed";
        response["reason"] = "注册失败";
    }

    // 发送响应
    sendJsonToClient(socket, response);
}

// 处理公聊消息
void ChatServer::handlePublicChat(QTcpSocket *socket, const QJsonObject &msg)
{
    QString sender = m_clientMap.value(socket, "");
    if (sender.isEmpty()) return;

    QString text = msg["text"].toString();
    emit messageReceived(sender, "all", text);

    // 构造广播消息
    QJsonObject response;
    response["type"] = "public_chat";
    response["sender"] = sender;
    response["receiver"] = "all";
    response["text"] = text;
    response["timestamp"] = QDateTime::currentDateTime().toString("HH:mm:ss");

    // 广播给所有在线用户（排除自己）
    broadcastJson(response, socket);
}

// 处理私聊消息
void ChatServer::handlePrivateChat(QTcpSocket *socket, const QJsonObject &msg)
{
    QString sender = m_clientMap.value(socket, "");
    if (sender.isEmpty()) return;

    QString receiver = msg["receiver"].toString();
    QString text = msg["text"].toString();
    emit messageReceived(sender, receiver, text);

    // 构造私聊消息
    QJsonObject response;
    response["type"] = "private_chat";
    response["sender"] = sender;
    response["receiver"] = receiver;
    response["text"] = text;
    response["timestamp"] = QDateTime::currentDateTime().toString("HH:mm:ss");

    // 发送给接收者
    for (auto it = m_clientMap.begin(); it != m_clientMap.end(); ++it) {
        if (it.value() == receiver) {
            sendJsonToClient(it.key(), response);
            break;
        }
    }

    // 发送给发送者（确认）
    sendJsonToClient(socket, response);
}

// 处理心跳包
void ChatServer::handleHeartbeat(QTcpSocket *socket, const QJsonObject &msg)
{
    QString username = msg["username"].toString();
    qDebug() << "收到心跳包：" << username;

    // 发送心跳确认
    QJsonObject response;
    response["type"] = "heartbeat_ack";
    response["timestamp"] = QDateTime::currentDateTime().toString("HH:mm:ss");
    sendJsonToClient(socket, response);
}

// 处理退出请求
void ChatServer::handleLogout(QTcpSocket *socket, const QJsonObject &msg)
{
    QString username = m_clientMap.value(socket, "");
    if (!username.isEmpty()) {
        m_onlineUsers.remove(username);
        updateOnlineUserList();
        emit messageReceived("系统", "all", username + " 已退出");
    }

    // 发送退出成功响应
    QJsonObject response;
    response["type"] = "logout_success";
    sendJsonToClient(socket, response);

    // 断开客户端
    socket->disconnectFromHost();
}

// 发送JSON给客户端
void ChatServer::sendJsonToClient(QTcpSocket *socket, const QJsonObject &json)
{
    if (!socket || socket->state() != QTcpSocket::ConnectedState) return;

    QJsonDocument doc(json);
    QByteArray data = doc.toJson(QJsonDocument::Compact) + "\n";
    socket->write(data);
}

// 广播JSON给所有客户端
void ChatServer::broadcastJson(const QJsonObject &json, QTcpSocket *exclude)
{
    QJsonDocument doc(json);
    QByteArray data = doc.toJson(QJsonDocument::Compact) + "\n";

    for (QTcpSocket *socket : m_clientMap.keys()) {
        if (socket == exclude || socket->state() != QTcpSocket::ConnectedState) continue;
        socket->write(data);
    }
}

// 广播在线用户列表
void ChatServer::updateOnlineUserList()
{
    QJsonObject response;
    response["type"] = "userlist";

    QJsonArray userArray;
    for (const QString &username : m_onlineUsers) {
        userArray.append(username);
    }
    response["userlist"] = userArray;

    // 广播给所有客户端
    broadcastJson(response);
}

// 校验用户
bool ChatServer::checkUser(const QString &username, const QString &password)
{
    if (m_allUsers.contains(username)) {
        return m_allUsers[username].password == password;
    }
    return false;
}

// 添加新用户
bool ChatServer::addUser(const QString &username, const QString &password, const QString &name, const QString &phone)
{
    if (m_allUsers.contains(username)) return false;

    UserData user;
    user.password = password;
    user.name = name;
    user.phone = phone;
    m_allUsers[username] = user;

    return true;
}
