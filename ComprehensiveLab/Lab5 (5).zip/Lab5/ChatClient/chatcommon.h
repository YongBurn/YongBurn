#ifndef CHATCOMMON_H
#define CHATCOMMON_H

#include <QString>
#include <QMetaType>

// 聊天类型枚举（全局公共类型）
enum class ChatType {
    Public,  // 群聊
    Private  // 单聊
};

// 聊天记录结构体（全局公共类型）
struct ChatRecord {
    QString sender;       // 发送者
    QString receiver;     // 接收者（群聊为all，单聊为用户名）
    QString content;      // 消息内容
    QString timestamp;    // 时间戳
    ChatType chatType;    // 聊天类型
};

// 注册元类型，支持跨线程传递
Q_DECLARE_METATYPE(ChatType)
Q_DECLARE_METATYPE(ChatRecord)

#endif // CHATCOMMON_H
