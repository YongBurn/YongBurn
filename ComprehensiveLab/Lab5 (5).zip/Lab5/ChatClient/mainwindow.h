#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTimer>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QMessageBox>
#include <QDateTime>
#include <QListWidgetItem>
#include <QInputDialog>
#include <QMap>
#include <QList>
// 引入DBHelper头文件
#include "dbhelper.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // 原有槽函数不变...
    void on_loginButton_clicked();
    void on_registerButton_clicked();
    void on_returnButton_clicked();
    void on_Register_clicked();
    void on_sayBtn_clicked();
    void on_logoutBtn_clicked();
    void on_contacts_clicked();
    void on_sayBtn_2_clicked();
    void on_logoutBtn_2_clicked();
    void on_contacts_2_clicked();
    void on_Return_clicked();
    void on_AddGroup_clicked();
    void on_Addcontact_clicked();
    void on_Grouping_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous);
    void on_userListWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item);
    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onSocketError(QAbstractSocket::SocketError error);

private:
    Ui::MainWindow *ui;

    // 网络相关
    QTcpSocket *m_tcpSocket;
    QTimer *m_heartbeatTimer;
    bool m_isConnected;

    // 用户状态
    QString m_currentUsername;
    QString m_privateChatTarget; // 私聊目标用户名

    // 数据库相关（恢复DBHelper）
    DBHelper *m_dbHelper;

    // 分组-联系人关联
    QMap<QString, QList<QString>> m_groupContactMap;
    QString m_currentSelectedGroup;

    // 核心函数
    void connectToServer(const QString &serverIp);
    void sendJsonToServer(const QJsonObject &json);
    void handleServerResponse(const QJsonObject &response);
    void sendHeartbeat();
    void logout();
    void switchToPage(int index);
    void clearChatInput();
    void updateOnlineUserList(const QJsonArray &userArray);

    // 新增：加载本地缓存数据
    void loadLocalChatRecords();          // 加载历史聊天记录
    void loadLocalGroupContacts();        // 加载联系人分组
    void loadPrivateChatRecords(const QString &target); // 加载指定私聊对象的记录
};

#endif // MAINWINDOW_H
