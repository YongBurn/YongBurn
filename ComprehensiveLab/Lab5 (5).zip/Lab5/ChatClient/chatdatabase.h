#ifndef CHATDATABASE_H
#define CHATDATABASE_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QMap>
#include <QVariant>

struct ContactInfo {
    QString username;
    QString nickname;
    QString group;
    QString status;
    QDateTime lastSeen;
    QString avatar;
    bool isOnline;

    ContactInfo() : isOnline(false) {}
};

struct MessageInfo {
    qint64 id;
    QString sender;
    QString receiver;
    QString type;
    QString content;
    QDateTime timestamp;
    bool isRead;
    bool isSync;
    QString extraData;

    MessageInfo() : id(0), isRead(false), isSync(false) {}
};

struct GroupInfo {
    QString name;
    QString owner;
    QString description;
    QDateTime created;
    QString avatar;
    QStringList members;

    GroupInfo() {}
};

class ChatDatabase : public QObject
{
    Q_OBJECT

public:
    explicit ChatDatabase(QObject *parent = nullptr);
    ~ChatDatabase();

    bool openDatabase(const QString &userName, const QString &password = "");
    void closeDatabase();
    bool isOpen() const;

    // 用户相关操作
    bool addUser(const QString &username, const QString &password,
                 const QString &nickname = "", const QString &phone = "",
                 const QString &email = "");
    bool updateUserInfo(const QString &username, const QMap<QString, QVariant> &info);
    bool authenticateUser(const QString &username, const QString &password);
    bool changePassword(const QString &username, const QString &oldPassword,
                        const QString &newPassword);
    QMap<QString, QVariant> getUserInfo(const QString &username);

    // 联系人相关操作
    bool addContact(const QString &username, const QString &nickname = "",
                    const QString &group = "默认分组", const QString &remark = "");
    bool removeContact(const QString &username);
    bool updateContact(const QString &username, const QMap<QString, QVariant> &info);
    QList<ContactInfo> getContacts();
    QList<ContactInfo> getContactsByGroup(const QString &group);
    bool setContactStatus(const QString &username, const QString &status, bool online);
    bool updateLastSeen(const QString &username, const QDateTime &time);

    // 消息相关操作
    qint64 saveMessage(const MessageInfo &message);
    bool saveMessages(const QList<MessageInfo> &messages);
    QList<MessageInfo> getMessages(const QString &targetUser, int limit = 100,
                                   int offset = 0, bool unreadOnly = false);
    QList<MessageInfo> getGroupMessages(const QString &groupName, int limit = 100,
                                        int offset = 0);
    bool markMessagesAsRead(const QString &sender, const QString &receiver);
    bool markMessageAsRead(qint64 messageId);
    bool deleteMessage(qint64 messageId);
    bool clearChatHistory(const QString &targetUser);
    int getUnreadCount(const QString &user = "");

    // 群组相关操作
    bool createGroup(const GroupInfo &group);
    bool joinGroup(const QString &groupName, const QString &username,
                   const QString &role = "member");
    bool leaveGroup(const QString &groupName, const QString &username);
    bool updateGroup(const GroupInfo &group);
    bool deleteGroup(const QString &groupName);
    GroupInfo getGroupInfo(const QString &groupName);
    QStringList getGroups(const QString &username = "");
    QStringList getGroupMembers(const QString &groupName);
    bool updateGroupMember(const QString &groupName, const QString &username,
                           const QString &role);
    bool removeGroupMember(const QString &groupName, const QString &username);

    // 系统相关操作
    bool backupDatabase(const QString &backupPath);
    bool restoreDatabase(const QString &backupPath);
    void compactDatabase();
    qint64 getDatabaseSize() const;
    QMap<QString, QVariant> getDatabaseInfo();

signals:
    void databaseOpened(bool success);
    void databaseError(const QString &error);
    void contactAdded(const QString &username);
    void contactRemoved(const QString &username);
    void contactUpdated(const QString &username);
    void messageSaved(qint64 messageId);
    void messagesRead(const QString &sender, const QString &receiver);

private:
    QSqlDatabase m_db;
    QString m_currentUser;
    QString m_databasePath;

    bool createTables();
    bool createIndexes();
    bool createTriggers();
    bool initData();
    bool createDefaultGroups();
    bool encryptPassword(const QString &password, QString &encrypted);
    bool verifyPassword(const QString &password, const QString &encrypted);
    QString generateSalt();
    QString hashPassword(const QString &password, const QString &salt);

    // 表结构版本管理
    int getSchemaVersion();
    bool updateSchema(int fromVersion, int toVersion);
    bool executeMigration(const QString &sql);

    // 数据库维护
    bool vacuumDatabase();
    bool analyzeDatabase();
    bool optimizeDatabase();

    // 事务处理
    bool beginTransaction();
    bool commitTransaction();
    bool rollbackTransaction();
};

#endif // CHATDATABASE_H
