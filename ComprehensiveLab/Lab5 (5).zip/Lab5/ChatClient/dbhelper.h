#ifndef DBHELPER_H
#define DBHELPER_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QString>
#include <QList>
#include <QMap>

// 聊天记录结构体
struct ChatRecord {
    int id;             // 主键
    QString username;   // 所属用户（当前登录用户）
    QString type;       // 类型：public/private
    QString sender;     // 发送者
    QString receiver;   // 接收者（私聊目标/all）
    QString content;    // 消息内容
    QString time;       // 发送时间
};

// 联系人分组结构体
struct GroupContact {
    QString groupName;  // 分组名
    QString contact;    // 联系人用户名
};

class DBHelper : public QObject
{
    Q_OBJECT
public:
    explicit DBHelper(QObject *parent = nullptr);
    ~DBHelper();

    // 初始化数据库（创建连接、表）
    bool initDB();

    // ========== 聊天记录操作 ==========
    // 插入聊天记录
    bool insertChatRecord(const ChatRecord &record);
    // 查询指定用户的所有聊天记录
    QList<ChatRecord> queryChatRecords(const QString &username);
    // 查询指定用户与目标的私聊记录
    QList<ChatRecord> queryPrivateChatRecords(const QString &username, const QString &target);

    // ========== 联系人分组操作 ==========
    // 插入分组
    bool insertGroup(const QString &groupName);
    // 插入分组-联系人关联
    bool insertGroupContact(const QString &groupName, const QString &contact);
    // 查询所有分组
    QList<QString> queryAllGroups();
    // 查询指定分组下的联系人
    QList<QString> queryContactsByGroup(const QString &groupName);
    // 查询所有分组-联系人关联
    QMap<QString, QList<QString>> queryAllGroupContacts();

private:
    QSqlDatabase m_db;  // 数据库连接对象

    // 创建表结构
    bool createTables();
};

#endif // DBHELPER_H
