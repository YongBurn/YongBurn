#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_tcpSocket(new QTcpSocket(this))
    , m_heartbeatTimer(new QTimer(this))
    , m_isConnected(false)
    , m_dbHelper(new DBHelper(this)) // 实例化DBHelper
{
    ui->setupUi(this);

    // 初始化数据库（必须先执行）
    if (!m_dbHelper->initDB()) {
        QMessageBox::warning(this, "数据库错误", "本地缓存初始化失败，聊天记录将无法保存！");
    }

    // 初始化UI状态
    switchToPage(3); // 初始显示登录页
    clearChatInput();
    ui->roomTextEdit->setReadOnly(true);
    ui->privateTextEdit->setReadOnly(true);

    // 绑定网络信号
    connect(m_tcpSocket, &QTcpSocket::connected, this, &MainWindow::onConnected);
    connect(m_tcpSocket, &QTcpSocket::disconnected, this, &MainWindow::onDisconnected);
    connect(m_tcpSocket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);
    connect(m_tcpSocket, &QTcpSocket::errorOccurred, this, &MainWindow::onSocketError);

    // 初始化心跳包（30秒一次）
    m_heartbeatTimer->setInterval(30000);
    connect(m_heartbeatTimer, &QTimer::timeout, this, &MainWindow::sendHeartbeat);

    qInfo() << "客户端初始化完成";
}

MainWindow::~MainWindow()
{
    logout();
    delete m_dbHelper; // 释放DBHelper
    delete ui;
}

// ===================== 新增：加载本地缓存数据 =====================
// 加载当前用户的所有历史聊天记录
void MainWindow::loadLocalChatRecords()
{
    if (m_currentUsername.isEmpty() || !m_dbHelper) return;

    // 清空当前聊天框
    ui->roomTextEdit->clear();

    // 查询所有聊天记录
    QList<ChatRecord> records = m_dbHelper->queryChatRecords(m_currentUsername);
    for (const ChatRecord &record : records) {
        if (record.type == "public") {
            // 公聊记录显示到群聊框
            if (record.sender == m_currentUsername) {
                ui->roomTextEdit->append(QString("[%1][我]：%2").arg(record.time).arg(record.content));
            } else {
                ui->roomTextEdit->append(QString("[%1][%2]：%3").arg(record.time).arg(record.sender).arg(record.content));
            }
        }
    }
    qInfo() << "加载本地公聊记录：" << records.size() << "条";
}

// 加载联系人分组（重启后恢复分组和联系人）
void MainWindow::loadLocalGroupContacts()
{
    if (!m_dbHelper) return;

    // 清空UI和内存中的分组数据
    ui->Grouping->clear();
    m_groupContactMap.clear();

    // 从数据库查询所有分组-联系人关联
    m_groupContactMap = m_dbHelper->queryAllGroupContacts();

    // 若没有默认分组，创建并插入数据库
    QString defaultGroup = "默认分组";
    if (m_groupContactMap.isEmpty()) {
        m_dbHelper->insertGroup(defaultGroup);
        m_groupContactMap[defaultGroup] = QList<QString>();
    }

    // 更新分组UI列表
    for (const QString &group : m_groupContactMap.keys()) {
        ui->Grouping->addItem(group);
    }

    // 默认选中第一个分组
    m_currentSelectedGroup = ui->Grouping->count() > 0 ? ui->Grouping->item(0)->text() : defaultGroup;
    // 刷新联系人列表
    ui->userListWidget_4->clear();
    QList<QString> contacts = m_groupContactMap[m_currentSelectedGroup];
    for (const QString &contact : contacts) {
        ui->userListWidget_4->addItem(contact);
    }

    qInfo() << "加载本地分组：" << m_groupContactMap.keys().size() << "个";
}

// 加载指定私聊对象的历史记录
void MainWindow::loadPrivateChatRecords(const QString &target)
{
    if (m_currentUsername.isEmpty() || target.isEmpty() || !m_dbHelper) return;

    // 清空私聊框
    ui->privateTextEdit->clear();
    ui->privateTextEdit->append(QString("=== 开始和 %1 私聊（历史记录）===").arg(target));

    // 查询与该目标的私聊记录
    QList<ChatRecord> records = m_dbHelper->queryPrivateChatRecords(m_currentUsername, target);
    for (const ChatRecord &record : records) {
        if (record.sender == m_currentUsername) {
            ui->privateTextEdit->append(QString("[%1][我->%2]：%3").arg(record.time).arg(target).arg(record.content));
        } else {
            ui->privateTextEdit->append(QString("[%1][%2->我]：%3").arg(record.time).arg(target).arg(record.content));
        }
    }
    qInfo() << "加载与" << target << "的私聊记录：" << records.size() << "条";
}

// ===================== 登录页核心功能（新增加载缓存） =====================
void MainWindow::on_loginButton_clicked()
{
    QString serverIp = ui->ServerEdit->text().trimmed();
    QString username = ui->UserNameEdit->text().trimmed();
    QString password = ui->UserPasswordEdit->text().trimmed();

    if (serverIp.isEmpty() || username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "服务器地址/用户名/密码不能为空！");
        return;
    }

    if (m_tcpSocket->state() != QTcpSocket::ConnectedState) {
        connect(m_tcpSocket, &QTcpSocket::connected, this, [=]() {
            QJsonObject loginJson;
            loginJson["type"] = "login";
            loginJson["username"] = username;
            loginJson["password"] = password;
            sendJsonToServer(loginJson);
            m_currentUsername = username;
            disconnect(m_tcpSocket, &QTcpSocket::connected, this, nullptr);
        });
        connectToServer(serverIp);
    } else {
        QJsonObject loginJson;
        loginJson["type"] = "login";
        loginJson["username"] = username;
        loginJson["password"] = password;
        sendJsonToServer(loginJson);
        m_currentUsername = username;
    }
}

// ===================== 群聊页（新增插入聊天记录到数据库） =====================
void MainWindow::on_sayBtn_clicked()
{
    QString message = ui->sayLineEdit->text().trimmed();
    if (message.isEmpty() || !m_isConnected) return;

    // 发送公聊消息
    QJsonObject chatJson;
    chatJson["type"] = "public_chat";
    chatJson["sender"] = m_currentUsername;
    chatJson["receiver"] = "all";
    chatJson["text"] = message;
    sendJsonToServer(chatJson);

    // 本地显示 + 插入数据库缓存
    QString time = QDateTime::currentDateTime().toString("HH:mm:ss");
    ui->roomTextEdit->append(QString("[%1][我]：%2").arg(time).arg(message));
    clearChatInput();

    // 插入到本地数据库
    ChatRecord record;
    record.username = m_currentUsername;
    record.type = "public";
    record.sender = m_currentUsername;
    record.receiver = "all";
    record.content = message;
    record.time = time;
    m_dbHelper->insertChatRecord(record);
}

// ===================== 私聊页（新增插入私聊记录到数据库） =====================
void MainWindow::on_sayBtn_2_clicked()
{
    QString message = ui->sayLineEdit_2->text().trimmed();
    if (message.isEmpty() || !m_isConnected || m_privateChatTarget.isEmpty()) return;

    if (m_privateChatTarget == m_currentUsername) {
        QMessageBox::information(this, "提示", "不能和自己私聊！");
        return;
    }

    // 发送私聊消息
    QJsonObject chatJson;
    chatJson["type"] = "private_chat";
    chatJson["sender"] = m_currentUsername;
    chatJson["receiver"] = m_privateChatTarget;
    chatJson["text"] = message;
    sendJsonToServer(chatJson);

    // 本地显示 + 插入数据库缓存
    QString time = QDateTime::currentDateTime().toString("HH:mm:ss");
    ui->privateTextEdit->append(QString("[%1][我->%2]：%3").arg(time).arg(m_privateChatTarget).arg(message));
    clearChatInput();

    // 插入到本地数据库
    ChatRecord record;
    record.username = m_currentUsername;
    record.type = "private";
    record.sender = m_currentUsername;
    record.receiver = m_privateChatTarget;
    record.content = message;
    record.time = time;
    m_dbHelper->insertChatRecord(record);
}

// ===================== 联系人页（新增插入分组/联系人到数据库） =====================
void MainWindow::on_AddGroup_clicked()
{
    QString groupName = QInputDialog::getText(this, "添加分组", "请输入分组名称：");
    if (groupName.isEmpty()) return;

    if (m_groupContactMap.contains(groupName)) {
        QMessageBox::information(this, "提示", QString("分组「%1」已存在！").arg(groupName));
        return;
    }

    // 插入到数据库 + 更新内存 + 更新UI
    m_dbHelper->insertGroup(groupName);
    m_groupContactMap[groupName] = QList<QString>();
    ui->Grouping->addItem(groupName);
    QMessageBox::information(this, "成功", QString("分组「%1」创建成功！").arg(groupName));
}

void MainWindow::on_Addcontact_clicked()
{
    if (m_currentSelectedGroup.isEmpty()) {
        QMessageBox::warning(this, "提示", "请先选中一个分组！");
        return;
    }

    QString contactName = QInputDialog::getText(this, "添加联系人", "请输入联系人用户名：");
    if (contactName.isEmpty()) return;

    QList<QString> contacts = m_groupContactMap[m_currentSelectedGroup];
    if (contacts.contains(contactName)) {
        QMessageBox::information(this, "提示", QString("分组「%1」中已存在联系人「%2」！").arg(m_currentSelectedGroup, contactName));
        return;
    }

    // 插入到数据库 + 更新内存 + 更新UI
    m_dbHelper->insertGroupContact(m_currentSelectedGroup, contactName);
    contacts.append(contactName);
    m_groupContactMap[m_currentSelectedGroup] = contacts;
    ui->userListWidget_4->addItem(contactName);
    QMessageBox::information(this, "成功", QString("联系人「%1」已添加到分组「%2」！").arg(contactName, m_currentSelectedGroup));
}

// ===================== 列表双击事件（新增加载私聊历史记录） =====================
void MainWindow::on_userListWidget_itemDoubleClicked(QListWidgetItem *item)
{
    QString targetUsername = item->text();
    if (targetUsername == m_currentUsername) {
        QMessageBox::information(this, "提示", "不能和自己发起私聊！");
        return;
    }

    m_privateChatTarget = targetUsername;
    switchToPage(1); // 切换到私聊页
    loadPrivateChatRecords(targetUsername); // 加载历史私聊记录
}

// ===================== 服务器响应处理（新增接收消息插入数据库） =====================
void MainWindow::handleServerResponse(const QJsonObject &response)
{
    QString type = response["type"].toString();

    if (type == "login_success") {
        QMessageBox::information(this, "登录成功", "欢迎使用聊天系统！");
        switchToPage(0);
        clearChatInput();
        ui->roomTextEdit->clear();

        // 登录成功后加载本地缓存
        loadLocalChatRecords();    // 加载历史聊天记录
        loadLocalGroupContacts();  // 加载联系人分组

        qInfo() << "登录成功，当前用户：" << m_currentUsername;
    }
    else if (type == "login_failed") {
        QMessageBox::warning(this, "登录失败", response["reason"].toString());
    }
    else if (type == "register_success") {
        QMessageBox::information(this, "注册成功", "注册成功，请返回登录页登录！");
        switchToPage(3);
    }
    else if (type == "register_failed") {
        QMessageBox::warning(this, "注册失败", response["reason"].toString());
    }
    else if (type == "public_chat") {
        // 接收公聊消息，插入数据库
        QString sender = response["sender"].toString();
        QString text = response["text"].toString();
        if (sender != m_currentUsername) {
            QString time = QDateTime::currentDateTime().toString("HH:mm:ss");
            ui->roomTextEdit->append(QString("[%1][%2]：%3").arg(time).arg(sender).arg(text));

            // 插入到本地数据库
            ChatRecord record;
            record.username = m_currentUsername;
            record.type = "public";
            record.sender = sender;
            record.receiver = "all";
            record.content = text;
            record.time = time;
            m_dbHelper->insertChatRecord(record);
        }
    }
    else if (type == "private_chat") {
        // 接收私聊消息，插入数据库
        QString sender = response["sender"].toString();
        QString text = response["text"].toString();
        QString time = QDateTime::currentDateTime().toString("HH:mm:ss");
        ui->privateTextEdit->append(QString("[%1][%2->我]：%3").arg(time).arg(sender).arg(text));

        // 插入到本地数据库
        ChatRecord record;
        record.username = m_currentUsername;
        record.type = "private";
        record.sender = sender;
        record.receiver = m_currentUsername;
        record.content = text;
        record.time = time;
        m_dbHelper->insertChatRecord(record);

        switchToPage(1);
        m_privateChatTarget = sender;
    }
    else if (type == "userlist") {
        QJsonArray userArray = response["userlist"].toArray();
        updateOnlineUserList(userArray);
    }
    else if (type == "heartbeat_ack") {
        qDebug() << "收到心跳包确认";
    }
}

// ===================== 原有核心函数（无修改） =====================
void MainWindow::connectToServer(const QString &serverIp)
{
    if (m_tcpSocket->state() == QTcpSocket::ConnectedState) {
        m_tcpSocket->disconnectFromHost();
    }
    m_tcpSocket->connectToHost(serverIp, 1967);
    qInfo() << "正在连接服务器：" << serverIp << ":1967";
}

void MainWindow::sendJsonToServer(const QJsonObject &json)
{
    if (!m_isConnected) return;
    QJsonDocument doc(json);
    QByteArray data = doc.toJson(QJsonDocument::Compact) + "\n";
    m_tcpSocket->write(data);
}

void MainWindow::onConnected()
{
    m_isConnected = true;
    m_heartbeatTimer->start();
    qInfo() << "已成功连接到服务器";
}

void MainWindow::onDisconnected()
{
    m_isConnected = false;
    m_heartbeatTimer->stop();
    QMessageBox::warning(this, "连接断开", "与服务器的连接已断开！");
    switchToPage(3);
}

void MainWindow::onReadyRead()
{
    QByteArray data = m_tcpSocket->readAll();
    QStringList messages = QString(data).split("\n", Qt::SkipEmptyParts);

    for (const QString &msg : messages) {
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(msg.toUtf8(), &error);
        if (error.error != QJsonParseError::NoError) {
            qWarning() << "JSON解析错误：" << error.errorString();
            continue;
        }
        handleServerResponse(doc.object());
    }
}

void MainWindow::onSocketError(QAbstractSocket::SocketError error)
{
    Q_UNUSED(error);
    QMessageBox::critical(this, "网络错误", QString("连接服务器失败：\n%1").arg(m_tcpSocket->errorString()));
    m_isConnected = false;
}

void MainWindow::sendHeartbeat()
{
    QJsonObject heartbeatJson;
    heartbeatJson["type"] = "heartbeat";
    heartbeatJson["username"] = m_currentUsername;
    sendJsonToServer(heartbeatJson);
}

void MainWindow::updateOnlineUserList(const QJsonArray &userArray)
{
    ui->userListWidget->clear();
    ui->userListWidget_2->clear();

    for (const QJsonValue &val : userArray) {
        QString username = val.toString();
        ui->userListWidget->addItem(username);
        ui->userListWidget_2->addItem(username);
    }
}

void MainWindow::switchToPage(int index)
{
    ui->stackedWidget->setCurrentIndex(index);
    qInfo() << "切换到页面索引：" << index;
}

void MainWindow::clearChatInput()
{
    ui->sayLineEdit->clear();
    ui->sayLineEdit_2->clear();
}

void MainWindow::logout()
{
    if (m_isConnected) {
        QJsonObject logoutJson;
        logoutJson["type"] = "logout";
        logoutJson["username"] = m_currentUsername;
        sendJsonToServer(logoutJson);
        m_tcpSocket->disconnectFromHost();
    }

    m_currentUsername.clear();
    m_privateChatTarget.clear();
    ui->roomTextEdit->clear();
    ui->privateTextEdit->clear();
    switchToPage(3);

    qInfo() << "已退出登录";
}

// 原有槽函数（无修改）
void MainWindow::on_registerButton_clicked() { switchToPage(4); }
void MainWindow::on_returnButton_clicked() { switchToPage(3); }
void MainWindow::on_Register_clicked()
{
    QString serverIp = ui->ServerEdit_2->text().trimmed();
    QString username = ui->UserNameEdit_2->text().trimmed();
    QString password = ui->UserPasswordEdit_2->text().trimmed();
    QString name = ui->AddressNameEdit->text().trimmed();
    QString phone = ui->TelephonenumberEdit->text().trimmed();

    if (serverIp.isEmpty() || username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "输入错误", "服务器地址/用户名/密码不能为空！");
        return;
    }

    if (m_tcpSocket->state() != QTcpSocket::ConnectedState) {
        connect(m_tcpSocket, &QTcpSocket::connected, this, [=]() {
            QJsonObject regJson;
            regJson["type"] = "register";
            regJson["username"] = username;
            regJson["password"] = password;
            regJson["name"] = name;
            regJson["phone"] = phone;
            sendJsonToServer(regJson);
            disconnect(m_tcpSocket, &QTcpSocket::connected, this, nullptr);
        });
        connectToServer(serverIp);
    } else {
        QJsonObject regJson;
        regJson["type"] = "register";
        regJson["username"] = username;
        regJson["password"] = password;
        regJson["name"] = name;
        regJson["phone"] = phone;
        sendJsonToServer(regJson);
    }
}

void MainWindow::on_logoutBtn_clicked() { logout(); }
void MainWindow::on_contacts_clicked() { switchToPage(2); }
void MainWindow::on_logoutBtn_2_clicked()
{
    m_privateChatTarget.clear();
    ui->privateTextEdit->append("=== 已退出私聊，返回群聊 ===");
    switchToPage(0);
    clearChatInput();
}

void MainWindow::on_contacts_2_clicked() { switchToPage(2); }
void MainWindow::on_Return_clicked() { switchToPage(0); }

void MainWindow::on_Grouping_currentItemChanged(QListWidgetItem *current, QListWidgetItem *previous)
{
    Q_UNUSED(previous);
    if (!current) {
        m_currentSelectedGroup = "";
        ui->userListWidget_4->clear();
        return;
    }
    m_currentSelectedGroup = current->text();
    ui->userListWidget_4->clear();
    QList<QString> contacts = m_groupContactMap[m_currentSelectedGroup];
    for (const QString &contact : contacts) {
        ui->userListWidget_4->addItem(contact);
    }
    ui->userListWidget_4->setToolTip(QString("当前分组：%1").arg(m_currentSelectedGroup));
}

void MainWindow::on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item)
{
    QString targetUsername = item->text();
    if (targetUsername == m_currentUsername) {
        QMessageBox::information(this, "提示", "不能和自己私聊！");
        return;
    }
    m_privateChatTarget = targetUsername;
    loadPrivateChatRecords(targetUsername); // 加载私聊历史记录
}
