#include "dbmanager.h"

DBManager* DBManager::m_instance = nullptr;
QMutex DBManager::m_instanceMutex;

DBManager::DBManager(QObject *parent) : QObject(parent)
{
    qDebug() << "[DB] 数据库路径：" << m_dbPath;
}

DBManager::~DBManager()
{
    QMutexLocker locker(&m_dbMutex);
    if (m_db.isOpen()) {
        m_db.close();
    }
}

DBManager *DBManager::getInstance(QObject *parent)
{
    QMutexLocker locker(&m_instanceMutex);
    if (!m_instance) {
        m_instance = new DBManager(parent);
    }
    return m_instance;
}

bool DBManager::initDatabase()
{
    QMutexLocker locker(&m_dbMutex);

    // 检查SQLite驱动
    if (!QSqlDatabase::isDriverAvailable("QSQLITE")) {
        qCritical() << "[DB] SQLite驱动不可用！";
        return false;
    }

    // 连接数据库
    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName(m_dbPath);

    // 打开数据库
    if (!m_db.open()) {
        qCritical() << "[DB] 打开数据库失败：" << m_db.lastError().text();
        return false;
    }

    // 创建表
    if (!createTables()) {
        qCritical() << "[DB] 创建表失败！";
        m_db.close();
        return false;
    }

    qDebug() << "[DB] 数据库初始化成功";
    return true;
}

bool DBManager::createTables()
{
    // 1. 用户表
    QSqlQuery userQuery(m_db);
    QString createUserTable = R"(
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            name TEXT,
            phone TEXT,
            create_time TEXT NOT NULL
        )
    )";
    if (!userQuery.exec(createUserTable)) {
        qCritical() << "[DB] 创建users表失败：" << userQuery.lastError().text();
        return false;
    }

    // 2. 联系人表
    QSqlQuery contactQuery(m_db);
    QString createContactTable = R"(
        CREATE TABLE IF NOT EXISTS contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT NOT NULL,
            username TEXT NOT NULL,
            UNIQUE(group_name, username)
        )
    )";
    if (!contactQuery.exec(createContactTable)) {
        qCritical() << "[DB] 创建contacts表失败：" << contactQuery.lastError().text();
        return false;
    }

    // 3. 聊天记录表
    QSqlQuery recordQuery(m_db);
    QString createRecordTable = R"(
        CREATE TABLE IF NOT EXISTS chat_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            local_username TEXT NOT NULL,
            chat_type TEXT NOT NULL,
            sender TEXT NOT NULL,
            receiver TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp TEXT NOT NULL
        )
    )";
    if (!recordQuery.exec(createRecordTable)) {
        qCritical() << "[DB] 创建chat_records表失败：" << recordQuery.lastError().text();
        return false;
    }

    // 4. 索引优化
    QSqlQuery indexQuery(m_db);
    indexQuery.exec("CREATE INDEX IF NOT EXISTS idx_chat_record ON chat_records (local_username, chat_type, timestamp)");

    return true;
}

// -------------------------- 用户信息操作 --------------------------
bool DBManager::saveUserInfo(const QString &username, const QString &password, const QString &name, const QString &phone)
{
    QMutexLocker locker(&m_dbMutex);
    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT OR REPLACE INTO users (username, password, name, phone, create_time)
        VALUES (:username, :password, :name, :phone, :create_time)
    )");
    query.bindValue(":username", username);
    query.bindValue(":password", password);
    query.bindValue(":name", name);
    query.bindValue(":phone", phone);
    query.bindValue(":create_time", QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));

    if (!query.exec()) {
        qCritical() << "[DB] 保存用户信息失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBManager::checkUserPassword(const QString &username, const QString &password)
{
    QMutexLocker locker(&m_dbMutex);
    QSqlQuery query(m_db);
    query.prepare("SELECT password FROM users WHERE username = :username LIMIT 1");
    query.bindValue(":username", username);

    if (!query.exec() || !query.next()) {
        return false;
    }
    return query.value(0).toString() == password;
}

bool DBManager::checkUserExists(const QString &username)
{
    QMutexLocker locker(&m_dbMutex);
    QSqlQuery query(m_db);
    query.prepare("SELECT 1 FROM users WHERE username = :username LIMIT 1");
    query.bindValue(":username", username);

    if (query.exec() && query.next()) {
        return true;
    }
    return false;
}

// -------------------------- 联系人操作 --------------------------
bool DBManager::addContact(const QString &groupName, const QString &username)
{
    QMutexLocker locker(&m_dbMutex);
    if (groupName.isEmpty()) return false;

    QSqlQuery query(m_db);
    if (username.isEmpty()) {
        query.prepare("INSERT OR IGNORE INTO contacts (group_name, username) VALUES (:group, '')");
    } else {
        query.prepare("INSERT OR IGNORE INTO contacts (group_name, username) VALUES (:group, :user)");
        query.bindValue(":user", username);
    }
    query.bindValue(":group", groupName);

    if (!query.exec()) {
        qCritical() << "[DB] 添加联系人失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBManager::deleteContact(const QString &groupName, const QString &username)
{
    QMutexLocker locker(&m_dbMutex);
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM contacts WHERE group_name = :group AND username = :user");
    query.bindValue(":group", groupName);
    query.bindValue(":user", username);

    if (!query.exec()) {
        qCritical() << "[DB] 删除联系人失败：" << query.lastError().text();
        return false;
    }
    return true;
}

bool DBManager::deleteGroup(const QString &groupName)
{
    QMutexLocker locker(&m_dbMutex);
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM contacts WHERE group_name = :group");
    query.bindValue(":group", groupName);

    if (!query.exec()) {
        qCritical() << "[DB] 删除分组失败：" << query.lastError().text();
        return false;
    }
    return true;
}

QStringList DBManager::getAllGroups()
{
    QMutexLocker locker(&m_dbMutex);
    QStringList groups;
    QSqlQuery query("SELECT DISTINCT group_name FROM contacts WHERE username = '' ORDER BY group_name", m_db);
    while (query.next()) {
        groups.append(query.value(0).toString());
    }
    return groups;
}

QStringList DBManager::getContactsByGroup(const QString &groupName)
{
    QMutexLocker locker(&m_dbMutex);
    QStringList contacts;
    QSqlQuery query(m_db);
    query.prepare("SELECT username FROM contacts WHERE group_name = :group AND username != '' ORDER BY username");
    query.bindValue(":group", groupName);

    if (query.exec()) {
        while (query.next()) {
            contacts.append(query.value(0).toString());
        }
    } else {
        qCritical() << "[DB] 查询联系人失败：" << query.lastError().text();
    }
    return contacts;
}

bool DBManager::contactExists(const QString &groupName, const QString &username)
{
    QMutexLocker locker(&m_dbMutex);
    QSqlQuery query(m_db);
    query.prepare("SELECT 1 FROM contacts WHERE group_name = :group AND username = :user LIMIT 1");
    query.bindValue(":group", groupName);
    query.bindValue(":user", username);

    if (query.exec() && query.next()) {
        return true;
    }
    return false;
}

// -------------------------- 聊天记录操作 --------------------------
bool DBManager::saveChatRecord(const QString &localUsername, const ChatRecord &record)
{
    QMutexLocker locker(&m_dbMutex);
    if (localUsername.isEmpty()) return false;

    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT INTO chat_records (
            local_username, chat_type, sender, receiver, content, timestamp
        ) VALUES (
            :local_user, :chat_type, :sender, :receiver, :content, :timestamp
        )
    )");
    query.bindValue(":local_user", localUsername);
    query.bindValue(":chat_type", record.chatType == ChatType::Public ? "public" : "private");
    query.bindValue(":sender", record.sender);
    query.bindValue(":receiver", record.receiver);
    query.bindValue(":content", record.content);
    query.bindValue(":timestamp", record.timestamp);

    if (!query.exec()) {
        qCritical() << "[DB] 保存聊天记录失败：" << query.lastError().text();
        return false;
    }
    return true;
}

QList<ChatRecord> DBManager::getChatRecords(const QString &localUsername, ChatType chatType, const QString &target)
{
    QMutexLocker locker(&m_dbMutex);
    QList<ChatRecord> records;
    QSqlQuery query(m_db);

    QString chatTypeStr = (chatType == ChatType::Public) ? "public" : "private";
    QString sql = R"(
        SELECT sender, receiver, content, timestamp
        FROM chat_records
        WHERE local_username = :local_user AND chat_type = :chat_type
    )";

    if (chatType == ChatType::Private && !target.isEmpty()) {
        sql += " AND (sender = :target OR receiver = :target)";
    }
    if (chatType == ChatType::Public) {
        sql += " AND receiver = 'all'";
    }
    sql += " ORDER BY timestamp ASC";

    query.prepare(sql);
    query.bindValue(":local_user", localUsername);
    query.bindValue(":chat_type", chatTypeStr);
    if (chatType == ChatType::Private && !target.isEmpty()) {
        query.bindValue(":target", target);
    }

    if (query.exec()) {
        while (query.next()) {
            ChatRecord record;
            record.sender = query.value(0).toString();
            record.receiver = query.value(1).toString();
            record.content = query.value(2).toString();
            record.timestamp = query.value(3).toString();
            record.chatType = chatType;
            records.append(record);
        }
    } else {
        qCritical() << "[DB] 查询聊天记录失败：" << query.lastError().text();
    }

    return records;
}

bool DBManager::deleteChatRecords(const QString &localUsername, ChatType chatType, const QString &target)
{
    QMutexLocker locker(&m_dbMutex);
    QSqlQuery query(m_db);
    QString chatTypeStr = (chatType == ChatType::Public) ? "public" : "private";
    QString sql = R"(
        DELETE FROM chat_records
        WHERE local_username = :local_user AND chat_type = :chat_type
    )";

    if (chatType == ChatType::Private && !target.isEmpty()) {
        sql += " AND (sender = :target OR receiver = :target)";
    }
    if (chatType == ChatType::Public) {
        sql += " AND receiver = 'all'";
    }

    query.prepare(sql);
    query.bindValue(":local_user", localUsername);
    query.bindValue(":chat_type", chatTypeStr);
    if (chatType == ChatType::Private && !target.isEmpty()) {
        query.bindValue(":target", target);
    }

    if (!query.exec()) {
        qCritical() << "[DB] 删除聊天记录失败：" << query.lastError().text();
        return false;
    }
    return true;
}
