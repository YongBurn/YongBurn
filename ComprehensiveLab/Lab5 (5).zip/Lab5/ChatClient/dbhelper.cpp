#include "dbhelper.h"
#include <QDir>
#include <QFileInfo>
DBHelper::DBHelper(QObject *parent) : QObject(parent)
{
    // 初始化数据库连接（SQLite）
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        m_db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        m_db = QSqlDatabase::addDatabase("QSQLITE");

        // ========== 核心修改：指定数据库绝对路径 ==========
        QString dbPath = "D:\\qt\\task\\Lab5\\Lab5\\Lab4a\\Lab4a.db"; // 反斜杠转义
        // 或用正斜杠（更推荐，避免转义问题）：
        // QString dbPath = "D:/qt/task/Lab5/Lab5/Lab4a/Lab4a.db";

        // 第一步：创建数据库所在目录（如果不存在）
        QFileInfo dbFileInfo(dbPath);
        QString dbDir = dbFileInfo.path(); // 获取目录路径：D:\qt\task\Lab5\Lab5\Lab4a
        QDir dir;
        if (!dir.exists(dbDir)) {
            // 递归创建目录（包括多级目录）
            bool dirCreated = dir.mkpath(dbDir);
            if (dirCreated) {
                qInfo() << "数据库目录创建成功：" << dbDir;
            } else {
                qCritical() << "数据库目录创建失败：" << dbDir;
            }
        }

        // 第二步：设置数据库文件路径
        m_db.setDatabaseName(dbPath);
        qInfo() << "数据库文件路径：" << dbPath;
    }
}


DBHelper::~DBHelper()
{
    // 关闭数据库连接
    if (m_db.isOpen()) {
        m_db.close();
    }
}

// 初始化数据库（打开+创建表）
bool DBHelper::initDB()
{
    // 打开数据库
    if (!m_db.open()) {
        qCritical() << "数据库打开失败：" << m_db.lastError().text();
        return false;
    }

    // 创建表结构
    if (!createTables()) {
        qCritical() << "表创建失败";
        return false;
    }

    qInfo() << "数据库初始化成功";
    return true;
}

// 创建表结构
bool DBHelper::createTables()
{
    QSqlQuery query;

    // 1. 聊天记录表：chat_records
    QString createChatTable = R"(
        CREATE TABLE IF NOT EXISTS chat_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,    -- 当前登录用户（区分不同用户的记录）
            type TEXT NOT NULL,        -- 消息类型：public/private
            sender TEXT NOT NULL,      -- 发送者
            receiver TEXT NOT NULL,    -- 接收者（all=公聊/用户名=私聊）
            content TEXT NOT NULL,     -- 消息内容
            time TEXT NOT NULL         -- 发送时间（HH:mm:ss）
        )
    )";
    if (!query.exec(createChatTable)) {
        qCritical() << "创建聊天记录表失败：" << query.lastError().text();
        return false;
    }

    // 2. 联系人分组表：contact_groups
    QString createGroupTable = R"(
        CREATE TABLE IF NOT EXISTS contact_groups (
            group_name TEXT PRIMARY KEY NOT NULL  -- 分组名（唯一）
        )
    )";
    if (!query.exec(createGroupTable)) {
        qCritical() << "创建分组表失败：" << query.lastError().text();
        return false;
    }

    // 3. 分组-联系人关联表：group_contacts
    QString createGroupContactTable = R"(
        CREATE TABLE IF NOT EXISTS group_contacts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_name TEXT NOT NULL,
            contact TEXT NOT NULL,
            -- 联合唯一索引（避免同一分组下重复添加联系人）
            UNIQUE(group_name, contact),
            FOREIGN KEY(group_name) REFERENCES contact_groups(group_name)
        )
    )";
    if (!query.exec(createGroupContactTable)) {
        qCritical() << "创建分组联系人表失败：" << query.lastError().text();
        return false;
    }

    return true;
}

// ========== 聊天记录操作 ==========
// 插入聊天记录
bool DBHelper::insertChatRecord(const ChatRecord &record)
{
    QSqlQuery query;
    query.prepare(R"(
        INSERT INTO chat_records (username, type, sender, receiver, content, time)
        VALUES (:username, :type, :sender, :receiver, :content, :time)
    )");
    query.bindValue(":username", record.username);
    query.bindValue(":type", record.type);
    query.bindValue(":sender", record.sender);
    query.bindValue(":receiver", record.receiver);
    query.bindValue(":content", record.content);
    query.bindValue(":time", record.time);

    if (!query.exec()) {
        qCritical() << "插入聊天记录失败：" << query.lastError().text();
        return false;
    }
    return true;
}

// 查询指定用户的所有聊天记录
QList<ChatRecord> DBHelper::queryChatRecords(const QString &username)
{
    QList<ChatRecord> records;
    QSqlQuery query;
    query.prepare("SELECT * FROM chat_records WHERE username = :username ORDER BY id ASC");
    query.bindValue(":username", username);

    if (query.exec()) {
        while (query.next()) {
            ChatRecord record;
            record.id = query.value("id").toInt();
            record.username = query.value("username").toString();
            record.type = query.value("type").toString();
            record.sender = query.value("sender").toString();
            record.receiver = query.value("receiver").toString();
            record.content = query.value("content").toString();
            record.time = query.value("time").toString();
            records.append(record);
        }
    } else {
        qCritical() << "查询聊天记录失败：" << query.lastError().text();
    }
    return records;
}

// 查询指定用户与目标的私聊记录
QList<ChatRecord> DBHelper::queryPrivateChatRecords(const QString &username, const QString &target)
{
    QList<ChatRecord> records;
    QSqlQuery query;
    // 私聊记录：接收者是target 或 发送者是target（双向）
    query.prepare(R"(
        SELECT * FROM chat_records
        WHERE username = :username AND type = 'private'
        AND (receiver = :target OR sender = :target)
        ORDER BY id ASC
    )");
    query.bindValue(":username", username);
    query.bindValue(":target", target);

    if (query.exec()) {
        while (query.next()) {
            ChatRecord record;
            record.id = query.value("id").toInt();
            record.username = query.value("username").toString();
            record.type = query.value("type").toString();
            record.sender = query.value("sender").toString();
            record.receiver = query.value("receiver").toString();
            record.content = query.value("content").toString();
            record.time = query.value("time").toString();
            records.append(record);
        }
    } else {
        qCritical() << "查询私聊记录失败：" << query.lastError().text();
    }
    return records;
}

// ========== 联系人分组操作 ==========
// 插入分组
bool DBHelper::insertGroup(const QString &groupName)
{
    QSqlQuery query;
    query.prepare("INSERT OR IGNORE INTO contact_groups (group_name) VALUES (:group_name)");
    query.bindValue(":group_name", groupName);

    if (!query.exec()) {
        qCritical() << "插入分组失败：" << query.lastError().text();
        return false;
    }
    return true;
}

// 插入分组-联系人关联
bool DBHelper::insertGroupContact(const QString &groupName, const QString &contact)
{
    QSqlQuery query;
    query.prepare(R"(
        INSERT OR IGNORE INTO group_contacts (group_name, contact)
        VALUES (:group_name, :contact)
    )");
    query.bindValue(":group_name", groupName);
    query.bindValue(":contact", contact);

    if (!query.exec()) {
        qCritical() << "插入分组联系人失败：" << query.lastError().text();
        return false;
    }
    return true;
}

// 查询所有分组
QList<QString> DBHelper::queryAllGroups()
{
    QList<QString> groups;
    QSqlQuery query("SELECT group_name FROM contact_groups ORDER BY group_name ASC");
    if (query.exec()) {
        while (query.next()) {
            groups.append(query.value("group_name").toString());
        }
    } else {
        qCritical() << "查询分组失败：" << query.lastError().text();
    }
    return groups;
}

// 查询指定分组下的联系人
QList<QString> DBHelper::queryContactsByGroup(const QString &groupName)
{
    QList<QString> contacts;
    QSqlQuery query;
    query.prepare("SELECT contact FROM group_contacts WHERE group_name = :group_name ORDER BY contact ASC");
    query.bindValue(":group_name", groupName);

    if (query.exec()) {
        while (query.next()) {
            contacts.append(query.value("contact").toString());
        }
    } else {
        qCritical() << "查询分组联系人失败：" << query.lastError().text();
    }
    return contacts;
}

// 查询所有分组-联系人关联（恢复m_groupContactMap）
QMap<QString, QList<QString>> DBHelper::queryAllGroupContacts()
{
    QMap<QString, QList<QString>> groupContactMap;
    // 先获取所有分组
    QList<QString> groups = queryAllGroups();
    // 遍历每个分组，获取对应联系人
    for (const QString &group : groups) {
        QList<QString> contacts = queryContactsByGroup(group);
        groupContactMap[group] = contacts;
    }
    return groupContactMap;
}
