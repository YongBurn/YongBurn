#include "chatclient.h"
#include <QDateTime>
#include <QDebug>

ChatClient::ChatClient(QObject *parent)
    : QObject(parent)
    , m_clientSocket(new QTcpSocket(this))
    , m_heartbeatTimer(new QTimer(this))
{
    connect(m_clientSocket, &QTcpSocket::connected, this, &ChatClient::onConnected);
    connect(m_clientSocket, &QTcpSocket::disconnected, this, &ChatClient::onDisconnected);
    connect(m_clientSocket, &QTcpSocket::readyRead, this, &ChatClient::onReadyRead);
    connect(m_clientSocket, QOverload<QAbstractSocket::SocketError>::of(&QTcpSocket::errorOccurred),
            this, &ChatClient::onSocketError);

    m_heartbeatTimer->setInterval(30000);
    connect(m_heartbeatTimer, &QTimer::timeout, this, &ChatClient::sendHeartbeat);
}

ChatClient::~ChatClient()
{
    m_heartbeatTimer->stop();
    if (m_clientSocket && m_clientSocket->state() == QAbstractSocket::ConnectedState) {
        m_clientSocket->disconnectFromHost();
    }
}

bool ChatClient::isConnected() const
{
    return m_clientSocket && m_clientSocket->state() == QAbstractSocket::ConnectedState;
}

void ChatClient::connectToServer(const QHostAddress &address, quint16 port)
{
    if (m_clientSocket->state() != QAbstractSocket::UnconnectedState) {
        m_clientSocket->abort();
    }

    m_clientSocket->connectToHost(address, port);
}

void ChatClient::disconnectFromHost()
{
    m_heartbeatTimer->stop();
    if (m_clientSocket && m_clientSocket->state() != QAbstractSocket::UnconnectedState) {
        m_clientSocket->disconnectFromHost();
    }
}

void ChatClient::onConnected()
{
    m_heartbeatTimer->start();
    qDebug() << "已连接到服务器";
    emit connected();
}

void ChatClient::onDisconnected()
{
    m_heartbeatTimer->stop();
    qDebug() << "与服务器断开连接";
    emit disconnected();
}

void ChatClient::onSocketError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError)
    qDebug() << "Socket错误:" << m_clientSocket->errorString();
    emit connectionError(m_clientSocket->errorString());
}

void ChatClient::onReadyRead()
{
    m_buffer.append(m_clientSocket->readAll());

    while (m_buffer.contains('\n')) {
        int newlinePos = m_buffer.indexOf('\n');
        QByteArray messageData = m_buffer.left(newlinePos);
        m_buffer = m_buffer.mid(newlinePos + 1);

        if (messageData.isEmpty())
            continue;

        QJsonParseError parseError;
        QJsonDocument jsonDoc = QJsonDocument::fromJson(messageData, &parseError);

        if (parseError.error != QJsonParseError::NoError) {
            qDebug() << "JSON解析错误:" << parseError.errorString()
                << "在位置:" << parseError.offset
                << "数据:" << messageData;
            continue;
        }

        if (jsonDoc.isObject()) {
            QJsonObject jsonObj = jsonDoc.object();
            qDebug() << "成功解析JSON:" << jsonObj;
            emit jsonReceived(jsonObj);
        }
    }
}

void ChatClient::sendPrivateMessage(const QString &receiver, const QString &text)
{
    if (!isConnected() || receiver.isEmpty() || text.isEmpty()) {
        return;
    }

    QJsonObject message;
    message["type"] = "private";
    message["receiver"] = receiver;
    message["text"] = text;
    message["sender"] = m_userName;
    message["timestamp"] = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");

    QByteArray data = QJsonDocument(message).toJson(QJsonDocument::Compact) + "\n";
    m_clientSocket->write(data);

    qDebug() << "发送私聊消息:" << m_userName << "->" << receiver << ":" << text;
}

void ChatClient::sendMessage(const QString &text, const QString &type)
{
    if (!isConnected() || text.isEmpty()) {
        qDebug() << "发送消息失败：连接断开或消息为空";
        return;
    }

    QJsonObject message;

    if (type == "login") {
        message["type"] = "login";
        message["username"] = m_userName;
        message["password"] = text;
    } else if (type == "message") {
        message["type"] = "message";
        message["text"] = text;
        message["sender"] = m_userName;
    } else if (type == "register") {
        message["type"] = "register";
        message["username"] = m_userName;
        message["password"] = text;
    } else {
        message["type"] = type;
        message["text"] = text;
    }

    message["timestamp"] = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");

    QByteArray data = QJsonDocument(message).toJson(QJsonDocument::Compact) + "\n";
    m_clientSocket->write(data);

    qDebug() << "发送消息:" << m_userName << ":" << text << "(类型:" << type << ")";
}

void ChatClient::sendHeartbeat()
{
    if (!isConnected()) {
        return;
    }

    QJsonObject heartbeat;
    heartbeat["type"] = "heartbeat";
    heartbeat["timestamp"] = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");

    QByteArray data = QJsonDocument(heartbeat).toJson(QJsonDocument::Compact) + "\n";
    m_clientSocket->write(data);
    qDebug() << "发送心跳包";
}
