#include "messagemodel.h"

MessageModel::MessageModel(QObject *parent)
    : QAbstractListModel(parent)
{
}

int MessageModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    return m_messages.count();
}

QVariant MessageModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_messages.count())
        return QVariant();

    const MessageItem &item = m_messages[index.row()];
    switch (role) {
    case SenderRole:
        return item.sender;
    case ReceiverRole:
        return item.receiver;
    case ContentRole:
        return item.content;
    case TimestampRole:
        return item.timestamp;
    case TypeRole:
        return static_cast<int>(item.type);
    case IsSelfRole:
        return item.isSelf;
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> MessageModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[SenderRole] = "sender";
    roles[ReceiverRole] = "receiver";
    roles[ContentRole] = "content";
    roles[TimestampRole] = "timestamp";
    roles[TypeRole] = "type";
    roles[IsSelfRole] = "isSelf";
    return roles;
}

void MessageModel::addMessage(const MessageItem &item)
{
    beginInsertRows(QModelIndex(), m_messages.count(), m_messages.count());
    m_messages.append(item);
    endInsertRows();
}

void MessageModel::clearMessages()
{
    beginResetModel();
    m_messages.clear();
    endResetModel();
}

const QList<MessageItem>& MessageModel::getMessages() const
{
    return m_messages;
}

void MessageModel::loadHistoryMessages(const QList<MessageItem> &history)
{
    beginResetModel();
    m_messages = history;
    endResetModel();
}
