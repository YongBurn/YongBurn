#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTimer>
#include <QJsonObject>
#include <QListWidgetItem>
#include "dbhelper.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    static const QString JSON_KEY_TYPE;
    static const QString JSON_KEY_USERNAME;
    static const QString JSON_KEY_PASSWORD;
    static const QString JSON_KEY_SENDER;
    static const QString JSON_KEY_RECEIVER;
    static const QString JSON_KEY_TEXT;
    static const QString JSON_KEY_USERLIST;
    static const QString JSON_KEY_REASON;
    static const QString JSON_KEY_NAME;
    static const QString JSON_KEY_PHONE;
    static const QString JSON_KEY_SERVER;

private slots:
    void connectToServer(const QString& serverIp);
    void handleServerResponse(const QJsonObject& json);
    void loadChatHistory();
    void loadPrivateChatHistory(const QString& targetUser);
    void sendHeartbeat();

    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void onSocketError(QAbstractSocket::SocketError error);

    void on_loginButton_clicked();
    void on_registerButton_clicked();
    void on_Register_clicked();
    void on_returnButton_clicked();
    void on_sayBtn_clicked();
    void on_logoutBtn_clicked();
    void on_contacts_clicked();
    void on_SendprivateChat_clicked();
    void on_PrivateChatreturn_clicked();
    void on_AddGroup_clicked();
    void on_Addcontact_clicked();
    void on_Return_clicked();

    void on_userListWidget_itemDoubleClicked(QListWidgetItem *item);
    void on_userListWidget_2_itemDoubleClicked(QListWidgetItem *item);

    // 新增：恢复发送按钮
    void restoreSendButton();

private:
    Ui::MainWindow *ui;
    QTcpSocket* m_socket;
    QTimer* m_heartbeatTimer;
    DBHelper m_dbHelper;

    QString m_currentUsername;
    QString m_privateChatTargetUser;
    QString m_currentServerIp;
    // 新增：标记是否正在发送私聊消息（防重复）
    bool m_isSendingPrivateMsg;
};

#endif // MAINWINDOW_H
