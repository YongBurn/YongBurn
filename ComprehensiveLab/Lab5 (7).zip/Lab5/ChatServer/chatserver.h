#ifndef CHATSERVER_H
#define CHATSERVER_H

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QMap>
#include <QSet>
#include <QDateTime>
#include <QDebug>

// 用户数据结构
struct UserData {
    QString password;
    QString name;
    QString phone;
};

class ChatServer : public QObject
{
    Q_OBJECT
public:
    explicit ChatServer(QObject *parent = nullptr);
    ~ChatServer() override;

    // 启动/停止服务器
    bool start(quint16 port);
    void stop();
    // 判断服务器是否运行
    bool isRunning() const { return m_tcpServer->isListening(); }

signals:
    void serverStarted();                  // 服务器启动成功
    void serverStopped();                  // 服务器停止
    void clientConnected(const QString &ip, quint16 port); // 客户端连接
    void clientDisconnected(const QString &ip, quint16 port); // 客户端断开
    void messageReceived(const QString &sender, const QString &receiver, const QString &msg); // 收到消息
    void errorOccurred(const QString &error); // 错误发生

private slots:
    void onNewConnection();                // 新客户端连接
    void onClientDisconnected();           // 客户端断开
    void onReadyRead();                    // 读取客户端数据

private:
    // 消息处理函数
    void handleLogin(QTcpSocket *socket, const QJsonObject &msg);      // 处理登录
    void handleRegister(QTcpSocket *socket, const QJsonObject &msg);   // 处理注册
    void handlePublicChat(QTcpSocket *socket, const QJsonObject &msg); // 处理公聊
    void handlePrivateChat(QTcpSocket *socket, const QJsonObject &msg);// 处理私聊
    void handleHeartbeat(QTcpSocket *socket, const QJsonObject &msg);  // 处理心跳
    void handleLogout(QTcpSocket *socket, const QJsonObject &msg);     // 处理退出

    // 辅助函数
    void sendJsonToClient(QTcpSocket *socket, const QJsonObject &json); // 发送JSON给客户端
    void broadcastJson(const QJsonObject &json, QTcpSocket *exclude = nullptr); // 广播JSON
    void updateOnlineUserList();           // 广播在线用户列表
    bool checkUser(const QString &username, const QString &password);  // 校验用户
    bool addUser(const QString &username, const QString &password, const QString &name, const QString &phone); // 添加用户

    QTcpServer *m_tcpServer;               // TCP服务器
    QMap<QTcpSocket*, QString> m_clientMap; // 客户端Socket -> 用户名
    QSet<QString> m_onlineUsers;           // 在线用户列表
    static QMap<QString, UserData> m_allUsers; // 所有注册用户（静态，全局共享）
};

#endif // CHATSERVER_H
